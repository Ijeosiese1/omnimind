import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Sidebar, MobileNav, MobileTopBar } from './components/Navigation';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SupportProvider } from './context/SupportContext';
import Dashboard from './pages/Dashboard';
import Assistant from './pages/Assistant';
import StudyHub from './pages/Study';
import CreativeStudio from './pages/Creative';
import Fitness from './pages/Fitness';
import Profile from './pages/Profile';
import ArticleWriter from './pages/ArticleWriter';
import ProjectWriter from './pages/ProjectWriter';
import PromptGenerator from './pages/PromptGenerator';
import { Loader2 } from 'lucide-react';

const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isLoading } = useAuth();

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-950"><Loader2 className="w-8 h-8 text-indigo-500 animate-spin" /></div>;
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col md:flex-row">
      <Sidebar />
      <MobileTopBar />
      {/* 
        Responsive Margins:
        md:ml-64 -> Pushes content right on desktop to account for Sidebar.
        pt-20 -> Pushes content down on mobile to account for MobileTopBar (16 * 4 = 64px + padding).
        md:pt-6 -> Resets top padding on desktop.
        pb-36 -> Pushes content up on mobile to avoid the taller MobileNav Grid (was pb-24).
      */}
      <main className="flex-1 md:ml-64 pt-20 pb-36 md:py-6 px-4 md:px-8 overflow-x-hidden">
        <div className="max-w-7xl mx-auto">
          {children}
        </div>
      </main>
      <MobileNav />
    </div>
  );
};

export default function App() {
  return (
    <HashRouter>
      <AuthProvider>
        <SupportProvider>
          <Routes>
            {/* All routes are accessible to the guest user */}
            <Route path="/" element={<AppLayout><Dashboard /></AppLayout>} />
            <Route path="/assistant" element={<AppLayout><Assistant /></AppLayout>} />
            <Route path="/prompts" element={<AppLayout><PromptGenerator /></AppLayout>} />
            <Route path="/study" element={<AppLayout><StudyHub /></AppLayout>} />
            <Route path="/creative" element={<AppLayout><CreativeStudio /></AppLayout>} />
            <Route path="/article-writer" element={<AppLayout><ArticleWriter /></AppLayout>} />
            <Route path="/project-writer" element={<AppLayout><ProjectWriter /></AppLayout>} />
            <Route path="/fitness" element={<AppLayout><Fitness /></AppLayout>} />
            <Route path="/profile" element={<AppLayout><Profile /></AppLayout>} />
            
            {/* Redirects - Removed Login/Register/Admin */}
            <Route path="/login" element={<Navigate to="/" replace />} />
            <Route path="/register" element={<Navigate to="/" replace />} />
            <Route path="/admin" element={<Navigate to="/" replace />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </SupportProvider>
      </AuthProvider>
    </HashRouter>
  );
}