import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  LayoutDashboard, 
  Bot, 
  GraduationCap, 
  PenTool, 
  Dumbbell, 
  UserCircle,
  Newspaper,
  Briefcase,
  Terminal,
  Menu
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { user } = useAuth();

  const navItems = [
    { name: 'Life OS', icon: LayoutDashboard, path: '/' },
    { name: 'AI Assistant', icon: Bot, path: '/assistant' },
    { name: 'Prompt Engine', icon: Terminal, path: '/prompts' },
    { name: 'Study Hub', icon: GraduationCap, path: '/study' },
    { name: 'Creative Studio', icon: PenTool, path: '/creative' },
    { name: 'Article Writer', icon: Newspaper, path: '/article-writer' },
    { name: 'Project Writer', icon: Briefcase, path: '/project-writer' },
    { name: 'Fitness Coach', icon: Dumbbell, path: '/fitness' },
  ];

  return (
    <div className="hidden md:flex flex-col w-64 bg-slate-950 border-r border-slate-800 h-screen fixed left-0 top-0 z-50">
      <div className="p-6 flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Bot className="text-white w-5 h-5" />
          </div>
          <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-purple-400">
            OmniMind
          </h1>
        </div>
        <p className="text-[10px] text-slate-500 font-bold tracking-tight mt-2 uppercase">
          Developed by <span className="text-indigo-400">Bamanosi Ijeosiese Ayomide</span>
        </p>
      </div>
      
      <nav className="flex-1 px-4 space-y-2 mt-2 overflow-y-auto custom-scrollbar">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                isActive 
                  ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 shadow-[0_0_15px_rgba(99,102,241,0.3)]' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
              }`
            }
          >
            <item.icon className="w-5 h-5" />
            <span className="font-medium">{item.name}</span>
          </NavLink>
        ))}
      </nav>

      <div className="p-4 mt-auto space-y-2">
        <NavLink to="/profile" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${isActive ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'}`}>
            <UserCircle className="w-5 h-5" />
            <span className="font-medium">Profile</span>
        </NavLink>
        
        <div className="bg-slate-900 rounded-xl p-4 border border-slate-800 mt-2">
            <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center font-bold text-emerald-400 text-xs border border-emerald-500/30">
                    {user?.name.charAt(0)}
                </div>
                <div className="text-xs text-slate-400 min-w-0">
                    <p className="text-slate-200 font-semibold truncate max-w-[100px]">{user?.name}</p>
                    <p className="text-emerald-400 text-[10px] font-bold">Free Forever</p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export const MobileTopBar: React.FC = () => {
  return (
    <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-slate-950/90 backdrop-blur-md border-b border-slate-800 z-50 flex items-center justify-between px-4">
       <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Bot className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white leading-none">OmniMind</h1>
            <p className="text-[8px] text-indigo-400 font-bold uppercase tracking-tighter leading-none mt-0.5">
              Dev by Bamanosi Ijeosiese Ayomide
            </p>
          </div>
       </div>
       <NavLink to="/profile">
         <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
            <UserCircle className="w-5 h-5" />
         </div>
       </NavLink>
    </div>
  );
};

export const MobileNav: React.FC = () => {
  // All 8 tools arranged in a Grid for better visibility
  const navItems = [
    { name: 'Life OS', icon: LayoutDashboard, path: '/' },
    { name: 'Assistant', icon: Bot, path: '/assistant' },
    { name: 'Prompts', icon: Terminal, path: '/prompts' },
    { name: 'Study', icon: GraduationCap, path: '/study' },
    { name: 'Studio', icon: PenTool, path: '/creative' },
    { name: 'Articles', icon: Newspaper, path: '/article-writer' },
    { name: 'Projects', icon: Briefcase, path: '/project-writer' },
    { name: 'Fitness', icon: Dumbbell, path: '/fitness' },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-950/95 backdrop-blur-lg border-t border-slate-800 z-50 pb-4 pt-2 rounded-t-2xl shadow-[0_-5px_20px_rgba(0,0,0,0.5)]">
      {/* Grid container for all items */}
      <div className="grid grid-cols-4 gap-y-2 gap-x-1 px-2 w-full">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center p-1.5 rounded-xl transition-all ${
                isActive ? 'text-indigo-400 bg-indigo-500/10' : 'text-slate-500 hover:text-slate-300'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <item.icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
                <span className={`text-[9px] font-medium mt-1 truncate w-full text-center ${isActive ? 'font-bold' : ''}`}>
                  {item.name}
                </span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </div>
  );
};