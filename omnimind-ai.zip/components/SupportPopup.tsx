
import React, { useState } from 'react';
import { Copy, Heart, CheckCircle2, X, Banknote } from 'lucide-react';

interface SupportPopupProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupportPopup: React.FC<SupportPopupProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState<string | null>('2000');
  const [showThankYou, setShowThankYou] = useState(false);

  if (!isOpen) return null;

  const accountDetails = {
    bankName: 'PALMPAY',
    accountName: 'BAMANOSI IJEOSIESE AYOMIDE',
    accountNumber: '9150719215'
  };

  const handleCopy = () => {
    // Copy only account number for ease of use in banking apps
    navigator.clipboard.writeText(accountDetails.accountNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSent = () => {
    setShowThankYou(true);
    // We don't permanently hide it because "Shows again after major actions"
    // But we can set a session flag if we wanted to be less aggressive.
    setTimeout(() => {
        onClose();
        setShowThankYou(false);
    }, 3000);
  };

  const handleClose = () => {
      onClose();
  }

  if (showThankYou) {
      return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
            <div className="bg-slate-900 border border-emerald-500/50 rounded-2xl p-8 text-center max-w-sm w-full shadow-2xl shadow-emerald-500/20">
                <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart className="w-8 h-8 text-emerald-500 fill-emerald-500 animate-pulse" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Thank You! ❤️</h2>
                <p className="text-slate-300">Your support keeps this app free and alive.</p>
            </div>
        </div>
      );
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900/95 border border-slate-700 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden relative">
        {/* Decorative Gradient Top */}
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-emerald-500 via-white to-emerald-500" />
        
        <button onClick={handleClose} className="absolute top-4 right-4 text-slate-500 hover:text-white p-2 rounded-full hover:bg-slate-800 transition-colors">
            <X className="w-5 h-5" />
        </button>

        <div className="p-6 sm:p-8">
          {/* Emotional Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center gap-2 bg-emerald-900/30 px-3 py-1 rounded-full border border-emerald-500/30 mb-4">
                <span className="text-lg">🇳🇬</span>
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Built with Love in Nigeria</span>
            </div>
            <h2 className="text-2xl font-black text-white mb-3 tracking-tight">Support the Developer</h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Hey! 👋 If this project has helped you, your support is what keeps it alive. It helps us add new AI tools, faster servers, and better user experience for everyone.
            </p>
          </div>

          {/* Bank Card */}
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-5 border border-slate-700 mb-6 relative group shadow-lg">
              <div className="flex justify-between items-start mb-4">
                  <div>
                      <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">Bank Name</p>
                      <p className="text-white font-bold tracking-wide text-lg flex items-center gap-2">
                          <Banknote className="w-4 h-4 text-purple-400" />
                          {accountDetails.bankName}
                      </p>
                  </div>
                  <div className="text-right">
                       <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">Currency</p>
                       <p className="text-emerald-400 font-bold bg-emerald-900/20 px-2 py-0.5 rounded">NGN (₦)</p>
                  </div>
              </div>
              
              <div className="mb-5 bg-black/20 p-3 rounded-xl border border-white/5">
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">Account Number</p>
                  <div className="flex items-center justify-between">
                      <p className="text-3xl font-mono font-bold text-white tracking-widest">{accountDetails.accountNumber}</p>
                      <button 
                        onClick={handleCopy}
                        className={`px-3 py-2 rounded-lg transition-all flex items-center gap-2 text-xs font-bold ${copied ? 'bg-emerald-500 text-white' : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-lg shadow-indigo-500/20'}`}
                      >
                          {copied ? <><CheckCircle2 className="w-3 h-3" /> Copied</> : <><Copy className="w-3 h-3" /> Copy</>}
                      </button>
                  </div>
              </div>

              <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">Account Name</p>
                  <p className="text-slate-300 text-sm font-medium truncate font-mono">{accountDetails.accountName}</p>
              </div>
          </div>

          {/* Amount Suggestions */}
          <div className="mb-6">
              <div className="flex justify-between items-end mb-3">
                  <p className="text-xs font-bold text-slate-500 uppercase">Select Amount</p>
                  {selectedAmount && selectedAmount !== 'Custom' && (
                    <span className="text-xs text-emerald-400 font-medium animate-fade-in">
                        Sending <span className="font-bold">₦{selectedAmount}</span>
                    </span>
                  )}
              </div>
              
              <div className="grid grid-cols-3 gap-2">
                  {['500', '1000', '2000', '5000', '10000', 'Custom'].map((amt) => (
                      <button
                        key={amt}
                        onClick={() => setSelectedAmount(amt)}
                        className={`py-2.5 px-1 rounded-xl text-sm font-bold border transition-all duration-200 ${
                            selectedAmount === amt 
                            ? 'bg-emerald-600 border-emerald-500 text-white shadow-lg shadow-emerald-500/30 transform scale-105' 
                            : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700 hover:text-white hover:border-slate-600'
                        }`}
                      >
                          {amt === 'Custom' ? 'Custom' : `₦${amt}`}
                      </button>
                  ))}
              </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
              <button 
                onClick={handleSent}
                className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold rounded-xl shadow-xl shadow-indigo-500/20 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2"
              >
                  <Heart className="w-5 h-5 fill-white/20 animate-pulse" /> I Have Sent The Support
              </button>
              <button 
                onClick={handleClose}
                className="w-full py-3 text-slate-500 hover:text-slate-300 text-sm font-medium transition-colors hover:underline"
              >
                  Support Later
              </button>
          </div>

        </div>
      </div>
    </div>
  );
};
