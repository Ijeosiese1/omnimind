
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserTier } from '../types';

interface AuthContextType {
  user: User | null;
  login: (u: User) => void;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType>(null!);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Automatically log in as Guest with full access
    const initGuest = async () => {
        // Short delay to allow app to mount smoothly
        setTimeout(() => {
            setUser({
                id: 'guest-user-' + Date.now(),
                name: 'Guest User',
                email: 'guest@omnimind.ai',
                role: 'user',
                tier: UserTier.ENTERPRISE, // Full Access for Free
                joinedAt: Date.now(),
                status: 'active'
            });
            setIsLoading(false);
        }, 100);
    };
    initGuest();
  }, []);

  const login = (u: User) => setUser(u);
  
  const logout = () => {
      // Essentially just resets the guest session
      window.location.reload();
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
