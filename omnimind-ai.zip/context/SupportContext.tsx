
import React, { createContext, useContext, useState, useEffect } from 'react';
import { SupportPopup } from '../components/SupportPopup';

interface SupportContextType {
  triggerSupport: () => void;
}

const SupportContext = createContext<SupportContextType>({ triggerSupport: () => {} });

export const SupportProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [actionCount, setActionCount] = useState(0);

  // Trigger popup automatically after 15 seconds of usage
  useEffect(() => {
    const timer = setTimeout(() => {
      const hasSupported = localStorage.getItem('omnimind_supported');
      if (!hasSupported) {
        setIsOpen(true);
      }
    }, 15000);
    return () => clearTimeout(timer);
  }, []);

  const triggerSupport = () => {
    // Trigger on every major action, unless they recently dismissed it (optional logic, sticking to prompt)
    const newCount = actionCount + 1;
    setActionCount(newCount);
    
    // Show on every action for maximum visibility as requested, or logic like every 2nd action
    // "Shows again after major actions"
    setIsOpen(true);
  };

  return (
    <SupportContext.Provider value={{ triggerSupport }}>
      {children}
      <SupportPopup isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </SupportContext.Provider>
  );
};

export const useSupport = () => useContext(SupportContext);
