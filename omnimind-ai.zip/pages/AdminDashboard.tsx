
import React from 'react';
import { Card, Button } from '../components/ui/Widgets';
import { ShieldAlert } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function AdminDashboard() {
  return (
    <div className="h-[calc(100vh-2rem)] flex items-center justify-center">
        <Card className="max-w-md text-center p-10 bg-slate-900 border-slate-800">
            <ShieldAlert className="w-16 h-16 text-red-500 mx-auto mb-6" />
            <h1 className="text-2xl font-bold text-white mb-2">Access Restricted</h1>
            <p className="text-slate-400 mb-6">The Admin Portal has been disabled in this version of the application.</p>
            <Link to="/">
                <Button className="w-full">Return Home</Button>
            </Link>
        </Card>
    </div>
  );
}
