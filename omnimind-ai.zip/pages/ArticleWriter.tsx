
import React, { useState, useEffect } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { 
    Newspaper, Sparkles, Search, Image as ImageIcon, 
    Share2, Download, Settings, PenTool, Save, Zap
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Backend } from '../services/backend';
import { 
    generateArticleResearch, 
    generateFullArticle, 
    generateSEOAnalysis, 
    generateArticleImage 
} from '../services/geminiService';
import { ArticleProject } from '../types';
import { jsPDF } from 'jspdf';
import { useSupport } from '../context/SupportContext';

export default function ArticleWriter() {
  const { user } = useAuth();
  const { triggerSupport } = useSupport();
  const [articles, setArticles] = useState<ArticleProject[]>([]);
  const [currentArticle, setCurrentArticle] = useState<ArticleProject | null>(null);
  
  // UI States
  const [activeTab, setActiveTab] = useState<'research' | 'write' | 'seo' | 'image'>('write');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'standard' | 'advanced'>('standard');
  
  // Inputs
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('Professional');
  const [length, setLength] = useState('Medium (1000 words)');
  const [type, setType] = useState('Blog Post');

  useEffect(() => {
      if (user) {
          Backend.getArticles(user.id).then(setArticles);
      }
  }, [user]);

  const createNewArticle = () => {
      if (!user) return;
      const newArticle: ArticleProject = {
          id: Date.now().toString(),
          userId: user.id,
          title: topic || 'Untitled Article',
          content: '',
          type: 'article',
          createdAt: Date.now()
      };
      setCurrentArticle(newArticle);
  };

  const handleSave = async () => {
      if (currentArticle && user) {
          await Backend.saveArticle(currentArticle);
          const updated = await Backend.getArticles(user.id);
          setArticles(updated);
          alert('Article saved successfully!');
          triggerSupport();
      }
  };

  const handleDownload = () => {
      if (!currentArticle) return;
      
      const doc = new jsPDF();
      
      // Title
      doc.setFontSize(22);
      doc.setFont("helvetica", "bold");
      const splitTitle = doc.splitTextToSize(currentArticle.title, 180);
      doc.text(splitTitle, 15, 20);
      
      // Metadata
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100);
      doc.text(`Type: ${currentArticle.type} | Date: ${new Date(currentArticle.createdAt).toLocaleDateString()}`, 15, 30);
      
      doc.setTextColor(0);
      doc.setFontSize(12);
      
      // Clean content (basic markdown stripping)
      let cleanContent = currentArticle.content
          .replace(/#{1,6}\s/g, '') // Remove headers
          .replace(/\*\*/g, '')     // Remove bold
          .replace(/\*/g, '')       // Remove italics
          .replace(/\[.*?\]\(.*?\)/g, ''); // Remove links
          
      const splitContent = doc.splitTextToSize(cleanContent, 180);
      
      // Add text with simple pagination
      let y = 40;
      splitContent.forEach((line: string) => {
          if (y > 280) {
              doc.addPage();
              y = 20;
          }
          doc.text(line, 15, y);
          y += 7;
      });
      
      doc.save(`${currentArticle.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.pdf`);
      triggerSupport();
  };

  const handleResearch = async () => {
      if (!topic || !currentArticle) return;
      setLoading(true);
      const research = await generateArticleResearch(topic);
      setCurrentArticle({ ...currentArticle, researchNotes: research });
      setLoading(false);
  };

  const handleWrite = async () => {
      if (!topic || !currentArticle) return;
      setLoading(true);
      const content = await generateFullArticle(topic, tone, length, type, mode);
      setCurrentArticle({ ...currentArticle, content });
      setLoading(false);
  };

  const handleSEO = async () => {
      if (!currentArticle?.content) return;
      setLoading(true);
      const seoData = await generateSEOAnalysis(currentArticle.content);
      setCurrentArticle({ ...currentArticle, seo: seoData });
      setLoading(false);
  };

  const handleGenerateImage = async () => {
      if (!topic || !currentArticle) return;
      setLoading(true);
      const imageUrl = await generateArticleImage(`A high quality, professional cover image for an article about ${topic}. Style: ${tone}`);
      if (imageUrl) {
          setCurrentArticle({ ...currentArticle, imageUrl });
      }
      setLoading(false);
  };

  if (!currentArticle) {
      return (
          <div className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center">
                  <div>
                      <h1 className="text-2xl font-bold text-white">AI Article Writer</h1>
                      <p className="text-slate-400">Professional content engine for creators.</p>
                  </div>
                  <Button onClick={createNewArticle}><Sparkles className="w-4 h-4 mr-2" /> New Article</Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {articles.map(a => (
                      <Card key={a.id} className="cursor-pointer hover:border-indigo-500 transition-colors relative group" onClick={() => setCurrentArticle(a)}>
                          {a.imageUrl && (
                              <div className="h-32 mb-4 rounded-lg overflow-hidden">
                                  <img src={a.imageUrl} alt="Cover" className="w-full h-full object-cover" />
                              </div>
                          )}
                          <h3 className="font-bold text-white mb-2 truncate">{a.title}</h3>
                          <p className="text-xs text-slate-400 mb-4">{new Date(a.createdAt).toLocaleDateString()}</p>
                          <div className="flex gap-2">
                              <Badge color="blue">{a.type}</Badge>
                              {a.seo && <Badge color="green">SEO Ready</Badge>}
                          </div>
                      </Card>
                  ))}
              </div>
          </div>
      );
  }

  return (
      <div className="h-[calc(100vh-2rem)] flex flex-col animate-fade-in">
          {/* Header */}
          <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-4">
                  <Button variant="outline" onClick={() => setCurrentArticle(null)}>Back</Button>
                  <input 
                      value={topic} 
                      onChange={e => setTopic(e.target.value)} 
                      className="bg-transparent border-none text-xl font-bold text-white focus:outline-none placeholder:text-slate-600"
                      placeholder="Enter Article Topic..."
                  />
              </div>
              <div className="flex gap-2">
                  <Button variant="secondary" onClick={handleSave}><Save className="w-4 h-4 mr-2" /> Save</Button>
                  <Button variant="outline" onClick={handleDownload}><Download className="w-4 h-4 mr-2" /> PDF</Button>
              </div>
          </div>

          <div className="flex-1 flex gap-6 overflow-hidden">
              {/* Sidebar Config */}
              <div className="w-64 shrink-0 space-y-6 overflow-y-auto pr-2">
                  <Card title="Settings">
                      <div className="space-y-4">
                          <div className="p-2 bg-slate-900 rounded-lg border border-slate-700 flex justify-between items-center">
                                <div className="text-xs font-medium text-slate-300 flex items-center gap-1">
                                    {mode === 'advanced' ? <Zap className="w-3 h-3 text-yellow-400" /> : <Sparkles className="w-3 h-3 text-slate-400" />}
                                    {mode === 'advanced' ? 'Advanced' : 'Standard'} Mode
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" className="sr-only peer" checked={mode === 'advanced'} onChange={() => setMode(mode === 'standard' ? 'advanced' : 'standard')} />
                                    <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                                </label>
                          </div>
                          <div>
                              <label className="text-xs text-slate-400 block mb-1">Type</label>
                              <select value={type} onChange={e => setType(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white">
                                  <option>Blog Post</option>
                                  <option>News Article</option>
                                  <option>Opinion Piece</option>
                                  <option>YouTube Script</option>
                              </select>
                          </div>
                          <div>
                              <label className="text-xs text-slate-400 block mb-1">Tone</label>
                              <select value={tone} onChange={e => setTone(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white">
                                  <option>Professional</option>
                                  <option>Casual</option>
                                  <option>Persuasive</option>
                                  <option>Academic</option>
                              </select>
                          </div>
                           <div>
                              <label className="text-xs text-slate-400 block mb-1">Length</label>
                              <select value={length} onChange={e => setLength(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white">
                                  <option>Short (500 words)</option>
                                  <option>Medium (1000 words)</option>
                                  <option>Long Form (2000+ words)</option>
                              </select>
                          </div>
                      </div>
                  </Card>

                  <div className="space-y-2">
                      {[
                          { id: 'research', label: 'Topic Research', icon: Search },
                          { id: 'write', label: 'Writer', icon: PenTool },
                          { id: 'seo', label: 'SEO Optimizer', icon: Settings },
                          { id: 'image', label: 'Cover Image', icon: ImageIcon },
                      ].map(item => (
                          <button 
                              key={item.id}
                              onClick={() => setActiveTab(item.id as any)}
                              className={`w-full flex items-center gap-3 p-3 rounded-xl transition-colors ${activeTab === item.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
                          >
                              <item.icon className="w-4 h-4" />
                              <span className="font-medium text-sm">{item.label}</span>
                          </button>
                      ))}
                  </div>
              </div>

              {/* Main Content Area */}
              <div className="flex-1 flex flex-col min-w-0 bg-slate-800/30 rounded-2xl border border-slate-700 overflow-hidden">
                  {/* WRITER TAB */}
                  {activeTab === 'write' && (
                      <div className="flex-1 flex flex-col">
                          <div className="p-4 border-b border-slate-700 flex justify-between items-center bg-slate-800/50">
                              <h3 className="font-bold text-white">Content Editor</h3>
                              <Button size="sm" onClick={handleWrite} disabled={loading}>
                                  {loading ? 'Writing...' : 'Auto-Write Article'} <Sparkles className="w-3 h-3 ml-2" />
                              </Button>
                          </div>
                          <textarea 
                              value={currentArticle.content}
                              onChange={e => setCurrentArticle({ ...currentArticle, content: e.target.value })}
                              className="flex-1 bg-slate-900 p-6 text-slate-200 resize-none focus:outline-none font-serif leading-relaxed text-lg"
                              placeholder="Article content will appear here..."
                          />
                      </div>
                  )}

                  {/* RESEARCH TAB */}
                  {activeTab === 'research' && (
                      <div className="flex-1 p-6 overflow-y-auto">
                          <div className="flex justify-between items-center mb-6">
                              <h3 className="text-xl font-bold text-white">AI Research Assistant</h3>
                              <Button onClick={handleResearch} disabled={loading}>{loading ? 'Researching...' : 'Analyze Topic'}</Button>
                          </div>
                          {currentArticle.researchNotes ? (
                              <div className="prose prose-invert max-w-none whitespace-pre-wrap">{currentArticle.researchNotes}</div>
                          ) : (
                              <div className="text-center text-slate-500 mt-20">
                                  <Search className="w-12 h-12 mx-auto mb-4 opacity-20" />
                                  <p>Click Analyze to find trends, keywords, and angles.</p>
                              </div>
                          )}
                      </div>
                  )}

                  {/* SEO TAB */}
                  {activeTab === 'seo' && (
                      <div className="flex-1 p-6 overflow-y-auto">
                          <div className="flex justify-between items-center mb-6">
                              <h3 className="text-xl font-bold text-white">SEO Optimization</h3>
                              <Button onClick={handleSEO} disabled={loading}>{loading ? 'Analyzing...' : 'Run Audit'}</Button>
                          </div>
                          {currentArticle.seo ? (
                              <div className="space-y-6">
                                  <Card>
                                      <h4 className="text-slate-400 text-sm mb-1">Meta Title</h4>
                                      <p className="text-white font-medium">{currentArticle.seo.metaTitle}</p>
                                      <div className="text-xs text-slate-500 mt-1">{currentArticle.seo.metaTitle.length}/60 chars</div>
                                  </Card>
                                  <Card>
                                      <h4 className="text-slate-400 text-sm mb-1">Meta Description</h4>
                                      <p className="text-white font-medium">{currentArticle.seo.metaDescription}</p>
                                      <div className="text-xs text-slate-500 mt-1">{currentArticle.seo.metaDescription.length}/160 chars</div>
                                  </Card>
                                  <div className="grid grid-cols-2 gap-4">
                                      <Card>
                                          <h4 className="text-slate-400 text-sm mb-2">Keywords</h4>
                                          <div className="flex flex-wrap gap-2">
                                              {currentArticle.seo.keywords.map(k => <Badge key={k} color="blue">{k}</Badge>)}
                                          </div>
                                      </Card>
                                      {/* Placeholder for score */}
                                      <Card className="flex items-center justify-center flex-col">
                                          <div className="text-4xl font-bold text-emerald-400">92</div>
                                          <div className="text-sm text-slate-500">SEO Score</div>
                                      </Card>
                                  </div>
                              </div>
                          ) : (
                              <div className="text-center text-slate-500 mt-20">
                                  <Settings className="w-12 h-12 mx-auto mb-4 opacity-20" />
                                  <p>Generate content first, then run SEO audit.</p>
                              </div>
                          )}
                      </div>
                  )}

                   {/* IMAGE TAB */}
                   {activeTab === 'image' && (
                      <div className="flex-1 p-6 flex flex-col">
                          <div className="flex justify-between items-center mb-6">
                              <h3 className="text-xl font-bold text-white">Cover Image</h3>
                              <Button onClick={handleGenerateImage} disabled={loading}>{loading ? 'Generating...' : 'Generate Image'}</Button>
                          </div>
                          <div className="flex-1 flex items-center justify-center bg-slate-900 rounded-xl border border-dashed border-slate-700">
                              {currentArticle.imageUrl ? (
                                  <img src={currentArticle.imageUrl} className="max-h-full max-w-full rounded shadow-2xl" alt="Generated Cover" />
                              ) : (
                                  <div className="text-slate-500 text-center">
                                      <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-20" />
                                      <p>No image generated yet.</p>
                                  </div>
                              )}
                          </div>
                      </div>
                  )}
              </div>
          </div>
      </div>
  );
}
