
import React, { useState, useRef, useEffect } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { 
    Send, Bot, User, PenTool, 
    MessageSquare, Copy, Paperclip, 
    Image as ImageIcon, X, 
    Wand2, FileUp, Eye, Code, 
    Terminal, Play, Maximize2, Folder, FileCode,
    ChevronRight, ChevronDown, Search, Settings, Minimize2,
    Zap, Sparkles, Coffee, Languages, FileText, BrainCircuit,
    Globe, ArrowRightLeft
} from 'lucide-react';
import { generateChatResponse, generateCreativeWriting, models } from '../services/geminiService';
import { ChatMessage } from '../types';

type Mode = 'chat' | 'writer' | 'editor';
type AssistantLevel = 'standard' | 'advanced';

// --- COMPONENTS FOR CHAT RENDERING ---

const CodeBlock: React.FC<{ language: string; code: string; onOpenEditor: (code: string, lang: string) => void }> = ({ language, code, onOpenEditor }) => {
    const [showPreview, setShowPreview] = useState(false);
    const isPreviewable = ['html', 'svg'].includes((language || '').toLowerCase());

    return (
        <div className="my-3 rounded-lg overflow-hidden border border-slate-700 bg-slate-950 w-full max-w-full shadow-lg group">
            <div className="flex justify-between items-center px-3 py-2 bg-slate-800/80 border-b border-slate-700 backdrop-blur-sm">
                <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-slate-400 uppercase font-bold">{language || 'text'}</span>
                </div>
                <div className="flex gap-2">
                    <button 
                        onClick={() => onOpenEditor(code, language)}
                        className="text-xs flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors px-2 py-1 hover:bg-slate-700 rounded font-medium"
                        title="Open in Code Editor"
                    >
                         <Terminal className="w-3 h-3" /> Open Editor
                    </button>
                    {isPreviewable && (
                        <button 
                            onClick={() => setShowPreview(!showPreview)}
                            className="text-xs flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 transition-colors font-medium bg-indigo-500/10 px-2 py-1 rounded"
                        >
                            {showPreview ? <Code className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                            {showPreview ? 'Show Code' : 'Preview'}
                        </button>
                    )}
                    <button 
                        onClick={() => navigator.clipboard.writeText(code)}
                        className="text-xs flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors px-2 py-1 hover:bg-slate-700 rounded"
                        title="Copy to Clipboard"
                    >
                         <Copy className="w-3 h-3" />
                    </button>
                </div>
            </div>
            {showPreview ? (
                 <div className="bg-white p-0 overflow-hidden resize-y min-h-[300px] relative">
                    <iframe 
                        srcDoc={code} 
                        className="w-full h-full min-h-[300px] border-0 absolute inset-0" 
                        title="Preview" 
                        sandbox="allow-scripts"
                    />
                 </div>
            ) : (
                <div className="overflow-x-auto custom-scrollbar p-4 bg-[#0d1117]">
                    <pre className="text-xs sm:text-sm font-mono text-slate-300 whitespace-pre">
                        <code>{code}</code>
                    </pre>
                </div>
            )}
        </div>
    );
};

const MessageContent = ({ text, onOpenEditor }: { text: string; onOpenEditor: (code: string, lang: string) => void }) => {
    const parts: React.ReactNode[] = [];
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = codeBlockRegex.exec(text)) !== null) {
        if (match.index > lastIndex) {
            parts.push(
                <span key={`text-${lastIndex}`} className="whitespace-pre-wrap leading-relaxed">
                    {text.substring(lastIndex, match.index)}
                </span>
            );
        }
        const language = match[1] || '';
        const code = match[2];
        parts.push(
            <CodeBlock 
                key={`code-${match.index}`} 
                language={language} 
                code={code} 
                onOpenEditor={onOpenEditor}
            />
        );
        lastIndex = match.index + match[0].length;
    }

    if (lastIndex < text.length) {
        parts.push(
            <span key={`text-${lastIndex}`} className="whitespace-pre-wrap leading-relaxed">
                {text.substring(lastIndex)}
            </span>
        );
    }

    return <div className="w-full overflow-hidden break-words">{parts}</div>;
};

// --- VS CODE STYLE EDITOR COMPONENT ---
const AdvancedCodeEditor = ({ 
    initialCode, 
    initialLang, 
    onClose 
}: { 
    initialCode: string, 
    initialLang: string, 
    onClose: () => void 
}) => {
    const [code, setCode] = useState(initialCode);
    return (
        <div className="fixed inset-0 z-50 bg-[#1e1e1e] text-[#d4d4d4] flex flex-col font-mono text-sm animate-fade-in">
             <div className="h-10 bg-[#2d2d2d] flex items-center justify-between px-4 border-b border-[#1e1e1e]">
                 <span className="font-bold text-indigo-400">OmniCode Pro</span>
                 <button onClick={onClose}><X className="w-4 h-4" /></button>
             </div>
             <textarea 
                value={code} 
                onChange={e => setCode(e.target.value)} 
                className="flex-1 bg-[#1e1e1e] text-slate-200 p-4 font-mono focus:outline-none" 
            />
        </div>
    )
};

export default function Assistant() {
  const [level, setLevel] = useState<AssistantLevel>('standard');
  const [mode, setMode] = useState<Mode>('chat'); // For Advanced tabs
  
  // --- CHAT MODE STATE ---
  const [input, setInput] = useState('');
  const [attachment, setAttachment] = useState<string | null>(null); 
  const [attachmentName, setAttachmentName] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- TRANSLATOR STATE ---
  const [showTranslate, setShowTranslate] = useState(false);
  const [transFrom, setTransFrom] = useState('Auto');
  const [transTo, setTransTo] = useState('English');
  const [transContent, setTransContent] = useState('');

  // --- WRITER MODE STATE ---
  const [writerConfig, setWriterConfig] = useState({
      format: 'Email', recipient: '', topic: '', tone: 'Professional', length: 'Medium'
  });
  const [generatedText, setGeneratedText] = useState('');
  const [isWriting, setIsWriting] = useState(false);

  // --- EDITOR MODE STATE ---
  const [editorCode, setEditorCode] = useState('');
  const [editorLang, setEditorLang] = useState('html');
  const [showAdvancedEditor, setShowAdvancedEditor] = useState(false);

  useEffect(() => {
      // Initial welcome message based on level
      setMessages([
          { 
              id: 'welcome', 
              role: 'model', 
              text: level === 'standard' 
                  ? "Hi there! I'm your standard assistant. I can help with quick tasks like drafting emails, summarizing text, or translating languages. What do you need?" 
                  : "Advanced AI Agent initialized. Accessing reasoning models (Gemini 3.0 Pro), code interpretation, and complex workflow capabilities. Awaiting your directive.", 
              timestamp: Date.now() 
          }
      ]);
  }, [level]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (mode === 'chat') scrollToBottom();
  }, [messages, mode]);

  const handleOpenEditor = (code: string, lang: string) => {
      setEditorCode(code);
      setEditorLang(lang || 'html');
      setShowAdvancedEditor(true);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const result = reader.result as string;
              setAttachment(result.split(',')[1]);
              setAttachmentName(file.name);
          };
          reader.readAsDataURL(file);
      }
  };

  const handleChatSend = async (overrideInput?: string) => {
    const textToSend = overrideInput || input;
    if ((!textToSend.trim() && !attachment)) return;

    const userMsg: ChatMessage = {
        id: Date.now().toString(),
        role: 'user',
        text: textToSend,
        timestamp: Date.now(),
        attachment: attachment || undefined
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    const currentAttachment = attachment;
    setAttachment(null); 
    setAttachmentName('');
    setIsChatLoading(true);

    try {
        const history = messages.slice(-10).map(m => ({
            role: m.role,
            text: m.text,
            attachment: m.attachment
        }));

        const systemInstruction = level === 'standard'
            ? "You are a friendly, concise Standard AI Assistant. Help with everyday tasks quickly and simply. Keep responses relatively short unless asked for detail."
            : "You are an Advanced AI Agent powered by Gemini 3.0 Pro. You are capable of complex reasoning, deep analysis, coding, and professional writing. Be thorough, accurate, and professional.";

        // Select model based on level
        const modelToUse = level === 'standard' ? models.text : models.reasoning;

        const responseText = await generateChatResponse(
            history, 
            userMsg.text, 
            currentAttachment,
            systemInstruction,
            modelToUse
        );

        const modelMsg: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: 'model',
            text: responseText,
            timestamp: Date.now()
        };
        setMessages(prev => [...prev, modelMsg]);
    } catch (error) {
        console.error(error);
    } finally {
        setIsChatLoading(false);
    }
  };

  const setInputAndFocus = (val: string) => {
      setInput(val);
      const inputEl = document.getElementById('standard-input') as HTMLInputElement;
      if(inputEl) {
          inputEl.focus();
      }
  };

  // --- WRITER FUNCTIONS ---
  const handleGenerateWriting = async () => {
      if (!writerConfig.topic) return;
      setIsWriting(true);
      const result = await generateCreativeWriting(
          writerConfig.format, writerConfig.recipient, writerConfig.topic, writerConfig.tone, writerConfig.length
      );
      setGeneratedText(result);
      setIsWriting(false);
  };

  // --- STANDARD QUICK ACTIONS ---
  const QuickAction = ({ icon: Icon, label, promptTemplate, isInputPrefill, onClick }: any) => (
      <button 
        onClick={() => {
            if (onClick) {
                onClick();
                return;
            }
            if(isInputPrefill) {
                setInputAndFocus(promptTemplate);
            } else {
                handleChatSend(promptTemplate);
            }
        }}
        className="bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-indigo-500 rounded-xl p-4 flex flex-col items-center gap-2 transition-all group"
      >
          <div className="p-2 bg-slate-900 rounded-full text-indigo-400 group-hover:text-white group-hover:bg-indigo-500 transition-colors">
              <Icon className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-slate-300 group-hover:text-white">{label}</span>
      </button>
  );

  return (
    <div className="h-[calc(100vh-2rem)] flex flex-col animate-fade-in">
      {showAdvancedEditor && (
          <AdvancedCodeEditor initialCode={editorCode} initialLang={editorLang} onClose={() => setShowAdvancedEditor(false)} />
      )}

      {/* TRANSLATION MODAL */}
      {showTranslate && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
              <Card className="w-full max-w-lg bg-slate-900 border-indigo-500/30 shadow-2xl">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold text-white flex items-center gap-2">
                          <Globe className="w-5 h-5 text-indigo-400" />
                          Universal Translator
                      </h3>
                      <button onClick={() => setShowTranslate(false)} className="text-slate-400 hover:text-white transition-colors">
                          <X className="w-5 h-5" />
                      </button>
                  </div>
                  
                  <div className="flex items-center gap-3 mb-4">
                      <div className="flex-1">
                          <label className="text-xs font-bold text-slate-500 mb-1.5 block uppercase">From</label>
                          <input 
                              value={transFrom}
                              onChange={(e) => setTransFrom(e.target.value)}
                              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm focus:border-indigo-500 outline-none"
                              placeholder="Language (e.g. Auto)"
                          />
                      </div>
                      <button 
                          onClick={() => {
                              const temp = transFrom;
                              setTransFrom(transTo);
                              setTransTo(temp);
                          }}
                          className="mt-6 p-2.5 rounded-full bg-slate-800 border border-slate-700 text-indigo-400 hover:bg-slate-700 hover:text-white transition-all"
                      >
                          <ArrowRightLeft className="w-4 h-4" />
                      </button>
                      <div className="flex-1">
                          <label className="text-xs font-bold text-slate-500 mb-1.5 block uppercase">To</label>
                          <input 
                              value={transTo}
                              onChange={(e) => setTransTo(e.target.value)}
                              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm focus:border-indigo-500 outline-none"
                              placeholder="Language (e.g. Spanish)"
                          />
                      </div>
                  </div>

                  <div className="mb-6">
                      <label className="text-xs font-bold text-slate-500 mb-1.5 block uppercase">Content</label>
                      <textarea 
                          value={transContent}
                          onChange={(e) => setTransContent(e.target.value)}
                          className="w-full h-32 bg-slate-800 border border-slate-700 rounded-xl p-4 text-white resize-none focus:border-indigo-500 outline-none custom-scrollbar leading-relaxed"
                          placeholder="Enter text to translate..."
                      />
                  </div>

                  <Button 
                      className="w-full py-3 bg-indigo-600 hover:bg-indigo-500"
                      onClick={() => {
                          if (!transContent.trim()) return;
                          handleChatSend(`Please translate the following text from ${transFrom} to ${transTo}:\n\n"${transContent}"`);
                          setShowTranslate(false);
                          setTransContent('');
                      }}
                      disabled={!transContent.trim()}
                  >
                      Translate Now
                  </Button>
              </Card>
          </div>
      )}

      {/* Top Toggle Switch */}
      <div className="flex justify-center mb-6">
          <div className="bg-slate-900 p-1 rounded-full border border-slate-800 flex relative">
               <button 
                   onClick={() => { setLevel('standard'); setMode('chat'); }}
                   className={`px-6 py-2 rounded-full text-sm font-bold flex items-center gap-2 transition-all relative z-10 ${level === 'standard' ? 'text-white' : 'text-slate-500 hover:text-slate-300'}`}
               >
                   <Zap className="w-4 h-4" /> Standard
               </button>
               <button 
                   onClick={() => setLevel('advanced')}
                   className={`px-6 py-2 rounded-full text-sm font-bold flex items-center gap-2 transition-all relative z-10 ${level === 'advanced' ? 'text-white' : 'text-slate-500 hover:text-slate-300'}`}
               >
                   <BrainCircuit className="w-4 h-4" /> Advanced
               </button>
               {/* Slider Background */}
               <div className={`absolute top-1 bottom-1 rounded-full bg-gradient-to-r transition-all duration-300 ${
                   level === 'standard' 
                   ? 'left-1 w-[115px] from-emerald-500 to-teal-500' 
                   : 'left-[120px] w-[125px] from-indigo-600 to-purple-600'
               }`} />
          </div>
      </div>

      {/* Header */}
      <div className="mb-4 flex justify-between items-end px-2">
        <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-2">
                {level === 'standard' ? 'Everyday Assistant' : 'OmniMind Pro'}
                {level === 'advanced' && <Badge color="purple" className="ml-2">PREMIUM</Badge>}
            </h1>
            <p className="text-slate-400 text-sm mt-1">
                {level === 'standard' ? 'Fast, simple, and helpful.' : 'Reasoning, Coding & Deep Research.'}
            </p>
        </div>
        {level === 'advanced' && (
            <div className="bg-slate-800 p-1 rounded-lg flex gap-1 border border-slate-700">
                {[
                    { id: 'chat', label: 'Agent Chat', icon: MessageSquare },
                    { id: 'editor', label: 'Dev Studio', icon: Terminal },
                    { id: 'writer', label: 'Pro Writer', icon: PenTool },
                ].map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => {
                            if(tab.id === 'editor') setShowAdvancedEditor(true);
                            else setMode(tab.id as Mode);
                        }}
                        className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-2 ${
                            mode === tab.id 
                            ? 'bg-indigo-600 text-white shadow-lg' 
                            : 'text-slate-400 hover:text-white hover:bg-slate-700'
                        }`}
                    >
                        <tab.icon className="w-3 h-3" />
                        {tab.label}
                    </button>
                ))}
            </div>
        )}
      </div>

      {/* STANDARD MODE UI */}
      {level === 'standard' && (
          <div className="flex-1 flex flex-col gap-4 overflow-hidden max-w-3xl mx-auto w-full">
               {/* Quick Actions Grid */}
               {messages.length <= 1 && (
                   <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                       <QuickAction icon={FileText} label="Summarize" promptTemplate="Summarize this text for me: " isInputPrefill={true} />
                       <QuickAction icon={Coffee} label="Draft Email" promptTemplate="Draft a professional email to: " isInputPrefill={true} />
                       <QuickAction icon={Languages} label="Translate" onClick={() => setShowTranslate(true)} />
                       <QuickAction icon={Sparkles} label="Explain" promptTemplate="Explain this concept simply: " isInputPrefill={true} />
                   </div>
               )}

               <Card className="flex-1 flex flex-col overflow-hidden bg-slate-900/80 border-slate-700 backdrop-blur-sm p-0">
                    <div className="flex-1 overflow-y-auto p-6 space-y-6">
                        {messages.map((msg) => (
                            <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                                    msg.role === 'user' ? 'bg-indigo-600' : 'bg-emerald-600'
                                }`}>
                                    {msg.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
                                </div>
                                <div className={`p-3 rounded-2xl text-sm leading-relaxed max-w-[80%] shadow-sm ${
                                    msg.role === 'user' 
                                    ? 'bg-indigo-600 text-white rounded-tr-none' 
                                    : 'bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700'
                                }`}>
                                    {msg.text}
                                </div>
                            </div>
                        ))}
                        {isChatLoading && <div className="text-slate-500 text-xs ml-12 flex items-center gap-2"><Sparkles className="w-3 h-3 animate-spin" /> Thinking...</div>}
                        <div ref={messagesEndRef} />
                    </div>
                    
                    {/* Simple Input */}
                    <div className="p-4 bg-slate-800/50 border-t border-slate-700">
                         <div className="flex gap-2">
                             <input 
                                id="standard-input"
                                value={input}
                                onChange={e => setInput(e.target.value)}
                                onKeyDown={e => e.key === 'Enter' && handleChatSend()}
                                className="flex-1 bg-slate-900 border border-slate-700 rounded-full px-4 py-3 text-white focus:border-emerald-500 outline-none"
                                placeholder="Message Standard Assistant..."
                             />
                             <button onClick={() => handleChatSend()} disabled={!input && !attachment} className="bg-emerald-600 hover:bg-emerald-500 text-white rounded-full p-3 transition-colors">
                                 <Send className="w-5 h-5" />
                             </button>
                         </div>
                    </div>
               </Card>
          </div>
      )}

      {/* ADVANCED MODE UI */}
      {level === 'advanced' && (
          <>
            {/* Chat Tab */}
            {mode === 'chat' && (
                <Card className="flex-1 flex flex-col overflow-hidden bg-slate-900/50 p-0 border-indigo-500/30 backdrop-blur-sm">
                    <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {messages.map((msg) => (
                        <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border ${
                            msg.role === 'user' 
                            ? 'bg-indigo-600 border-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.3)]' 
                            : 'bg-purple-600 border-purple-500 shadow-[0_0_15px_rgba(147,51,234,0.3)]'
                        }`}>
                            {msg.role === 'user' ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-white" />}
                        </div>
                        <div className={`flex flex-col gap-2 max-w-[85%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                            {msg.attachment && (
                                <div className="rounded-xl overflow-hidden border border-slate-600 max-w-[200px] bg-slate-800">
                                    <img src={`data:image/jpeg;base64,${msg.attachment}`} alt="attachment" className="w-full h-auto" />
                                </div>
                            )}
                            <div className={`p-4 rounded-2xl text-sm leading-relaxed shadow-md ${
                                msg.role === 'user' 
                                ? 'bg-indigo-600 text-white rounded-tr-none' 
                                : 'bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700 w-full'
                            }`}>
                                <MessageContent text={msg.text} onOpenEditor={handleOpenEditor} />
                            </div>
                        </div>
                        </div>
                    ))}
                    {isChatLoading && (
                         <div className="flex gap-4 animate-pulse">
                             <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center"><Bot className="w-5 h-5 text-white" /></div>
                             <div className="bg-slate-800 px-4 py-3 rounded-2xl rounded-tl-none border border-slate-700 text-slate-400 text-xs flex items-center">
                                 Running reasoning engine...
                             </div>
                         </div>
                    )}
                    <div ref={messagesEndRef} />
                    </div>
                    
                    {/* Advanced Input Area */}
                    <div className="p-4 bg-slate-900/80 border-t border-slate-800 backdrop-blur-md">
                        {attachment && (
                            <div className="mb-3 inline-flex items-center gap-3 bg-slate-800 pl-2 pr-4 py-2 rounded-xl border border-slate-700 animate-fade-in shadow-lg">
                                <div className="w-8 h-8 rounded bg-slate-900 overflow-hidden"><img src={`data:image/jpeg;base64,${attachment}`} className="w-full h-full object-cover" /></div>
                                <span className="text-xs text-slate-400">{attachmentName}</span>
                                <button onClick={() => setAttachment(null)}><X className="w-3 h-3 hover:text-white" /></button>
                            </div>
                        )}
                        <div className="flex gap-3 items-end">
                            <input type="file" ref={fileInputRef} className="hidden" accept="image/*,.pdf" onChange={handleFileUpload} />
                            <Button variant="secondary" className="h-12 px-3 bg-slate-800 border-slate-700 hover:bg-slate-700" onClick={() => fileInputRef.current?.click()}>
                                <Paperclip className="w-5 h-5" />
                            </Button>
                            <textarea
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleChatSend(); } }}
                                placeholder="Ask complex questions (e.g., 'Analyze this code', 'Write a business plan')..." 
                                className="flex-1 bg-slate-800 border border-slate-700 rounded-xl p-3 text-white focus:border-purple-500 outline-none resize-none h-12 custom-scrollbar"
                            />
                            <Button onClick={() => handleChatSend()} disabled={isChatLoading} className="h-12 bg-purple-600 hover:bg-purple-500 px-6">
                                <Send className="w-5 h-5" />
                            </Button>
                        </div>
                    </div>
                </Card>
            )}

            {/* Writer Tab */}
            {mode === 'writer' && (
                 <div className="flex-1 flex flex-col lg:flex-row gap-6 h-full overflow-hidden">
                      <Card title="Pro Writer Config" className="lg:w-1/3 flex flex-col gap-4 bg-slate-800/50 border-indigo-500/30">
                          {/* Reusing previous writer inputs but styled for 'Advanced' */}
                          <div>
                              <label className="text-xs font-bold text-slate-400 mb-1 uppercase">Format</label>
                              <select value={writerConfig.format} onChange={e => setWriterConfig({...writerConfig, format: e.target.value})} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white">
                                 {['Email', 'Report', 'Essay', 'Blog Post', 'Memo', 'Speech'].map(o => <option key={o}>{o}</option>)}
                              </select>
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-400 mb-1 uppercase">Topic</label>
                              <textarea value={writerConfig.topic} onChange={e => setWriterConfig({...writerConfig, topic: e.target.value})} className="w-full h-32 bg-slate-900 border border-slate-700 rounded-lg p-3 text-white resize-none" placeholder="Detailed description of what to write..." />
                          </div>
                          <Button onClick={handleGenerateWriting} disabled={isWriting} className="bg-gradient-to-r from-indigo-600 to-purple-600">
                              {isWriting ? 'Composing...' : 'Generate Content'} <Wand2 className="w-4 h-4 ml-2" />
                          </Button>
                      </Card>
                      <div className="flex-1 bg-slate-900 rounded-xl border border-slate-800 p-8 overflow-y-auto font-serif text-slate-300 leading-loose whitespace-pre-wrap">
                          {generatedText || <span className="text-slate-600 italic">Generated content will appear here...</span>}
                      </div>
                 </div>
            )}
          </>
      )}
    </div>
  );
}
