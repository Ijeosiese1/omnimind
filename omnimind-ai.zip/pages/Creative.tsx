
import React, { useState } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { 
    PenTool, BookOpen, Video, 
    Briefcase, Share2, Layout, Link as ChainIcon,
    CheckCircle2, Sparkles, Loader2, Download, Copy,
    ArrowRight, X, Palette, Image as ImageIcon, Grid
} from 'lucide-react';
import { runCreativeTool, runToolchain, CreativeToolType } from '../services/geminiService';
import { useSupport } from '../context/SupportContext';

// Added 'image_gen' to tools
const TOOLS = [
    { id: 'logo', label: 'Logo Generator', icon: PenTool, color: 'bg-emerald-500', category: 'Branding', desc: 'Create professional brand identities instantly.' },
    { id: 'image_gen', label: 'AI Image Generator', icon: ImageIcon, color: 'bg-orange-500', category: 'Media', desc: 'Generate high-quality custom images.' },
    { id: 'poster', label: 'Poster Design', icon: Palette, color: 'bg-purple-500', category: 'Design', desc: 'AI-driven layouts for events and promos.' },
    { id: 'ebook_cover', label: 'E-Book Cover', icon: BookOpen, color: 'bg-blue-500', category: 'Design', desc: 'Perfect covers for KDP & digital publishing.' },
    { id: 'thumbnail', label: 'Thumbnail Maker', icon: Video, color: 'bg-red-500', category: 'Media', desc: 'High-CTR YouTube thumbnails.' },
    { id: 'business_card', label: 'Business Card', icon: Briefcase, color: 'bg-indigo-500', category: 'Branding', desc: 'Print-ready professional cards.' },
    { id: 'social_post', label: 'Social Post', icon: Share2, color: 'bg-pink-500', category: 'Content', desc: 'Auto-generated captions & visuals.' },
    { id: 'landing_page', label: 'Web Builder', icon: Layout, color: 'bg-cyan-500', category: 'Web', desc: 'Full landing page code & copy.' },
];

const CATEGORIES = ['Branding', 'Design', 'Media', 'Content', 'Web'];

// --- SUB-COMPONENTS ---

const ToolCard = ({ tool, onClick }: { tool: any, onClick: () => void }) => (
    <div 
        onClick={onClick}
        className="group relative p-6 bg-slate-800 border border-slate-700 rounded-2xl transition-all hover:border-indigo-500 cursor-pointer hover:-translate-y-1 hover:shadow-xl flex flex-col h-full"
    >
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${tool.color}`}>
            <tool.icon className="w-6 h-6 text-white" />
        </div>
        <h3 className="text-lg font-bold text-white mb-1 flex items-center gap-2">
            {tool.label}
        </h3>
        <p className="text-sm text-slate-400 flex-1">{tool.desc}</p>
        <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
            <ArrowRight className="w-5 h-5 text-slate-300" />
        </div>
    </div>
);

const ResultView = ({ result, onClose }: { result: any, onClose: () => void }) => {
    if (!result) return null;

    return (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-lg flex items-center justify-center p-4">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full md:w-[90%] max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl animate-fade-in">
                {/* Header */}
                <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900">
                    <h3 className="font-bold text-white flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5 text-emerald-500" /> Creation Ready
                    </h3>
                    <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white">
                        <X className="w-5 h-5" />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar bg-slate-950">
                    
                    {/* IMAGE RESULT (Covers Logo, Poster, Image Gen etc) */}
                    {result.type === 'image' && (
                        <div className="flex flex-col items-center gap-6">
                            <div className="relative group rounded-xl overflow-hidden shadow-2xl w-full max-w-md border border-slate-700">
                                {result.url ? (
                                    <img src={result.url} alt="Generated" className="w-full h-auto" />
                                ) : (
                                    <div className="h-64 bg-slate-800 flex items-center justify-center text-slate-500">Image Generation Failed</div>
                                )}
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                                    <a href={result.url} download="generated_image.jpg" className="bg-white text-black px-4 py-2 rounded-lg flex items-center gap-2 font-bold">
                                        <Download className="w-4 h-4" /> Download
                                    </a>
                                </div>
                            </div>
                            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 w-full max-w-2xl">
                                <p className="text-xs text-slate-500 uppercase font-bold mb-2">Used Prompt</p>
                                <p className="text-slate-300 text-sm">{result.prompt}</p>
                            </div>
                        </div>
                    )}

                    {/* CODE RESULT (Landing Page) */}
                    {result.type === 'code' && (
                        <div className="flex flex-col lg:flex-row gap-6 h-full min-h-[400px]">
                            <div className="flex-1 space-y-4 min-w-0">
                                <div className="bg-slate-900 rounded-xl border border-slate-800 p-4">
                                    <div className="flex justify-between mb-2">
                                        <span className="text-xs font-bold text-indigo-400 uppercase">HTML / Tailwind</span>
                                        <button onClick={() => navigator.clipboard.writeText(result.html)} className="text-xs text-slate-400 hover:text-white flex gap-1"><Copy className="w-3 h-3" /> Copy</button>
                                    </div>
                                    <pre className="text-xs font-mono text-slate-300 overflow-x-auto p-2 bg-black rounded-lg h-64 md:h-96 custom-scrollbar whitespace-pre">
                                        {result.html}
                                    </pre>
                                </div>
                            </div>
                            <div className="w-full lg:w-64 space-y-4 shrink-0">
                                <div className="p-4 bg-slate-800 rounded-xl">
                                    <h4 className="font-bold text-white mb-2 text-sm">SEO Meta</h4>
                                    <p className="text-xs text-slate-400">{result.metaDescription}</p>
                                </div>
                                <div className="p-4 bg-slate-800 rounded-xl">
                                    <h4 className="font-bold text-white mb-2 text-sm">Sections</h4>
                                    <ul className="space-y-1">
                                        {result.sections?.map((s:string) => <li key={s} className="text-xs text-slate-300">• {s}</li>)}
                                    </ul>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* SOCIAL POST RESULT */}
                    {result.type === 'social' && (
                        <div className="max-w-md mx-auto bg-white text-black rounded-xl overflow-hidden shadow-2xl">
                             <div className="p-4 flex items-center gap-3 border-b border-gray-100">
                                 <div className="w-8 h-8 rounded-full bg-gray-200" />
                                 <div className="font-bold text-sm">Your Brand</div>
                             </div>
                             {result.imageUrl ? (
                                 <img src={result.imageUrl} className="w-full h-auto aspect-square object-cover" />
                             ) : (
                                 <div className="w-full aspect-square bg-gray-100 flex items-center justify-center text-gray-400">No Image</div>
                             )}
                             <div className="p-4">
                                 <div className="flex gap-4 mb-3">
                                     <div className="w-6 h-6 rounded-full border border-black" />
                                     <div className="w-6 h-6 rounded-full border border-black" />
                                     <div className="w-6 h-6 rounded-full border border-black" />
                                 </div>
                                 <p className="text-sm leading-relaxed">
                                     <span className="font-bold mr-2">Your Brand</span>
                                     {result.caption}
                                 </p>
                                 <div className="mt-2 text-blue-600 text-sm">
                                     {result.hashtags?.join(' ')}
                                 </div>
                             </div>
                        </div>
                    )}

                    {/* BUSINESS CARD RESULT */}
                    {result.type === 'data' && (
                        <div className="flex flex-col items-center gap-8">
                            <div className="w-full max-w-[400px] aspect-[1.8] bg-white rounded-xl shadow-2xl p-6 md:p-8 flex flex-col justify-between relative overflow-hidden">
                                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500 rounded-bl-full opacity-20" />
                                <div>
                                    <h3 className="text-xl md:text-2xl font-bold text-slate-900 truncate">{result.front.company}</h3>
                                    <p className="text-indigo-600 font-medium text-sm md:text-base truncate">{result.back.slogan}</p>
                                </div>
                                <div>
                                    <p className="text-lg md:text-xl font-bold text-slate-800 truncate">{result.front.name}</p>
                                    <p className="text-sm text-slate-500 truncate">{result.front.title}</p>
                                    <p className="text-xs text-slate-400 mt-2 truncate">{result.back.website}</p>
                                </div>
                            </div>
                            <div className="w-full max-w-[400px] aspect-[1.8] bg-slate-900 rounded-xl shadow-2xl p-6 md:p-8 flex items-center justify-center border border-slate-700">
                                <div className="text-center">
                                    <h3 className="text-2xl md:text-3xl font-bold text-white tracking-widest truncate px-4">{result.front.company}</h3>
                                </div>
                            </div>
                        </div>
                    )}

                </div>
            </div>
        </div>
    );
}

export default function CreativeStudio() {
  const { triggerSupport } = useSupport();
  const [activeToolId, setActiveToolId] = useState<string | null>(null);
  const [isToolchainMode, setIsToolchainMode] = useState(false);
  
  // Input State
  const [inputs, setInputs] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  
  // Toolchain State
  const [chainPrompt, setChainPrompt] = useState('');
  const [chainResults, setChainResults] = useState<any[]>([]);

  const activeTool = TOOLS.find(t => t.id === activeToolId);

  const handleGenerate = async () => {
      if (!activeToolId) return;
      setLoading(true);
      const typeToRun = activeToolId === 'image_gen' ? 'poster' : activeToolId as CreativeToolType;
      const finalInputs = activeToolId === 'image_gen' ? { title: 'Custom Image', details: inputs.description } : inputs;

      const res = await runCreativeTool(typeToRun, finalInputs);
      setResult(res);
      setLoading(false);
      triggerSupport(); // Show popup after generation
  };

  const handleChainRun = async () => {
      if (!chainPrompt) return;
      setLoading(true);
      const results = await runToolchain(chainPrompt);
      setChainResults(results);
      setLoading(false);
      triggerSupport(); // Show popup after chain run
  };

  const handleBack = () => {
      setActiveToolId(null);
      setInputs({});
      setResult(null);
  };

  return (
    <div className="h-[calc(100vh-6rem)] md:h-[calc(100vh-2rem)] flex flex-col animate-fade-in bg-[#0B0F19] overflow-hidden rounded-xl md:rounded-3xl border border-slate-800 shadow-2xl">
        {/* Result Modal */}
        <ResultView result={result} onClose={() => setResult(null)} />

        {/* Header */}
        <header className="shrink-0 p-4 md:p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800 bg-slate-900/50 backdrop-blur-md z-20">
            <div>
                <h1 className="text-xl md:text-2xl font-black text-white flex items-center gap-2 tracking-tight">
                    CREATIVE STUDIO
                </h1>
                <p className="text-[10px] md:text-xs text-slate-500 font-bold tracking-widest uppercase">
                    Free Unlimited Generation
                </p>
            </div>
            <div className="flex gap-2 w-full md:w-auto">
                <button 
                    onClick={() => { 
                        setIsToolchainMode(!isToolchainMode); 
                        setActiveToolId(null); 
                    }}
                    className={`flex-1 md:flex-none justify-center px-4 py-2 rounded-full text-xs font-bold border transition-all flex items-center gap-2 ${isToolchainMode ? 'bg-indigo-600 border-indigo-500 text-white shadow-[0_0_15px_rgba(99,102,241,0.4)]' : 'border-slate-700 text-slate-400 hover:text-white hover:border-white'}`}
                >
                    <ChainIcon className="w-3 h-3" /> <span className="hidden sm:inline">AI</span> Toolchain Mode
                </button>
            </div>
        </header>

        <main className="flex-1 overflow-hidden relative flex flex-col md:flex-row">
            
            {/* --- SIDEBAR (Categories) --- */}
            {!isToolchainMode && (
                <>
                    {/* Mobile Category Nav (Horizontal Scroll) */}
                    <div className="md:hidden w-full bg-slate-900/50 border-b border-slate-800 p-3 flex gap-2 overflow-x-auto scrollbar-hide shrink-0 items-center">
                         <button 
                             onClick={handleBack}
                             className={`px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap border transition-all flex items-center gap-2 ${!activeToolId ? 'bg-white text-black border-white' : 'bg-slate-800 text-slate-400 border-slate-700'}`}
                        >
                            <Grid className="w-3 h-3" /> All Tools
                        </button>
                        <div className="w-px h-6 bg-slate-700 mx-1 shrink-0" />
                        {TOOLS.map(tool => (
                             <button
                                key={tool.id}
                                onClick={() => { setActiveToolId(tool.id); setInputs({}); setResult(null); }}
                                className={`px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap border transition-all flex items-center gap-2 ${activeToolId === tool.id ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-slate-800 text-slate-400 border-slate-700'}`}
                            >
                                <tool.icon className="w-3 h-3" /> {tool.label}
                            </button>
                        ))}
                    </div>

                    {/* Desktop Sidebar (Vertical) */}
                    <div className="hidden md:flex w-64 bg-slate-900/50 border-r border-slate-800 p-4 flex-col gap-6 overflow-y-auto custom-scrollbar shrink-0">
                        {CATEGORIES.map(cat => (
                            <div key={cat}>
                                <h4 className="text-xs font-bold text-slate-500 uppercase mb-3 px-2">{cat}</h4>
                                <div className="space-y-1">
                                    {TOOLS.filter(t => t.category === cat).map(tool => {
                                        return (
                                            <button
                                                key={tool.id}
                                                onClick={() => { 
                                                    setActiveToolId(tool.id); 
                                                    setInputs({}); 
                                                    setResult(null); 
                                                }}
                                                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${activeToolId === tool.id ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
                                            >
                                                <tool.icon className="w-4 h-4" /> {tool.label}
                                            </button>
                                        );
                                    })}
                                </div>
                            </div>
                        ))}
                    </div>
                </>
            )}

            {/* --- MAIN AREA --- */}
            <div className="flex-1 bg-slate-950 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
                {/* Background Effect */}
                <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
                    <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-indigo-600/5 rounded-full blur-[100px]" />
                </div>

                {/* TOOLCHAIN MODE UI */}
                {isToolchainMode ? (
                    <div className="max-w-3xl mx-auto space-y-8 relative z-10">
                        <div className="text-center px-4">
                             <div className="inline-flex items-center justify-center p-4 bg-indigo-500/10 rounded-2xl mb-4 border border-indigo-500/20">
                                 <ChainIcon className="w-10 h-10 text-indigo-400" />
                             </div>
                             <h2 className="text-3xl md:text-4xl font-black text-white mb-2">AI Toolchain</h2>
                             <p className="text-slate-400">Chain multiple tools together. The AI will plan and execute the sequence.</p>
                        </div>

                        <div className="bg-slate-900/80 backdrop-blur-xl p-2 rounded-3xl border border-indigo-500/50 shadow-[0_0_50px_rgba(99,102,241,0.1)]">
                             <textarea 
                                value={chainPrompt}
                                onChange={e => setChainPrompt(e.target.value)}
                                placeholder='e.g. "Generate a modern logo for a coffee shop called Brew, then create a business card for it, and finally design a landing page."'
                                className="w-full bg-transparent border-none text-white text-lg p-6 resize-none focus:outline-none min-h-[120px] placeholder:text-slate-600"
                             />
                             <div className="px-4 pb-4 flex justify-end">
                                 <Button onClick={handleChainRun} disabled={loading || !chainPrompt} className="w-full sm:w-auto px-8 py-3 text-base bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500">
                                     {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Sparkles className="w-5 h-5 mr-2" />}
                                     Execute Chain
                                 </Button>
                             </div>
                        </div>

                        {/* Chain Results */}
                        <div className="space-y-6 pb-10">
                            {chainResults.map((item, idx) => (
                                <div key={idx} className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden">
                                    <div className="p-4 bg-slate-900 border-b border-slate-800 flex justify-between items-center">
                                        <h3 className="font-bold text-white capitalize flex items-center gap-2 text-sm md:text-base">
                                            <span className="bg-slate-700 text-xs px-2 py-1 rounded text-slate-300">Step {idx+1}</span>
                                            {item.tool.replace('_', ' ')}
                                        </h3>
                                        <Button size="sm" variant="outline" onClick={() => setResult(item.result)}>View Output</Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : (
                    /* STANDARD TOOL UI */
                    <>
                        {!activeToolId ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 relative z-10 pb-10">
                                {TOOLS.map(tool => {
                                    return <ToolCard key={tool.id} tool={tool} onClick={() => setActiveToolId(tool.id)} />;
                                })}
                            </div>
                        ) : (
                            <div className="max-w-2xl mx-auto space-y-6 md:space-y-8 relative z-10 pb-10">
                                <button onClick={handleBack} className="md:hidden flex items-center text-slate-400 mb-4 text-sm">
                                    <ArrowRight className="w-4 h-4 mr-1 rotate-180" /> Back to Tools
                                </button>

                                <div className="flex items-center gap-4 mb-8">
                                    <div className={`p-3 rounded-xl ${activeTool?.color}`}>
                                        {activeTool && <activeTool.icon className="w-6 h-6 text-white" />}
                                    </div>
                                    <div>
                                        <h2 className="text-2xl font-bold text-white">{activeTool?.label}</h2>
                                        <p className="text-slate-400 text-sm">{activeTool?.desc}</p>
                                    </div>
                                </div>

                                <div className="space-y-4 bg-slate-900/50 p-4 md:p-6 rounded-2xl border border-slate-800">
                                    {/* Dynamic Inputs based on tool */}
                                    {activeToolId === 'logo' && (
                                        <>
                                            <input placeholder="Brand Name" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, name: e.target.value})} />
                                            <input placeholder="Style (e.g. Minimalist, Retro)" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, style: e.target.value})} />
                                            <input placeholder="Industry" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, industry: e.target.value})} />
                                        </>
                                    )}
                                    {activeToolId === 'image_gen' && (
                                        <>
                                            <textarea placeholder="Describe the image you want to create in detail..." className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white h-40 resize-none focus:border-orange-500 focus:outline-none" onChange={e => setInputs({...inputs, description: e.target.value})} />
                                        </>
                                    )}
                                    {activeToolId === 'poster' && (
                                        <>
                                            <input placeholder="Event / Title" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, title: e.target.value})} />
                                            <textarea placeholder="Details (Date, Location, Theme)" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white h-24 resize-none" onChange={e => setInputs({...inputs, details: e.target.value})} />
                                        </>
                                    )}
                                    {activeToolId === 'ebook_cover' && (
                                        <>
                                            <input placeholder="Book Title" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, title: e.target.value})} />
                                            <input placeholder="Genre" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, genre: e.target.value})} />
                                            <textarea placeholder="Plot Summary" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white h-24 resize-none" onChange={e => setInputs({...inputs, summary: e.target.value})} />
                                        </>
                                    )}
                                    {activeToolId === 'thumbnail' && (
                                        <>
                                            <input placeholder="Video Title" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, title: e.target.value})} />
                                            <input placeholder="Emotion (e.g. Shocked, Happy)" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, emotion: e.target.value})} />
                                            <textarea placeholder="Visual Description" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white h-24 resize-none" onChange={e => setInputs({...inputs, description: e.target.value})} />
                                        </>
                                    )}
                                    {activeToolId === 'business_card' && (
                                        <>
                                            <input placeholder="Full Name" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, name: e.target.value})} />
                                            <input placeholder="Job Title" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, role: e.target.value})} />
                                            <input placeholder="Company Name" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, company: e.target.value})} />
                                        </>
                                    )}
                                    {activeToolId === 'social_post' && (
                                        <>
                                            <select className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, platform: e.target.value})}>
                                                <option value="Instagram">Instagram</option>
                                                <option value="Twitter">Twitter / X</option>
                                                <option value="LinkedIn">LinkedIn</option>
                                            </select>
                                            <textarea placeholder="What is this post about?" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white h-24 resize-none" onChange={e => setInputs({...inputs, topic: e.target.value})} />
                                        </>
                                    )}
                                    {activeToolId === 'landing_page' && (
                                        <>
                                            <input placeholder="Business Name" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white" onChange={e => setInputs({...inputs, businessName: e.target.value})} />
                                            <textarea placeholder="Product/Service Description" className="w-full bg-slate-800 border border-slate-700 rounded-xl p-4 text-white h-32 resize-none" onChange={e => setInputs({...inputs, description: e.target.value})} />
                                        </>
                                    )}

                                    <Button onClick={handleGenerate} disabled={loading || Object.keys(inputs).length === 0} className="w-full py-4 text-lg bg-indigo-600 hover:bg-indigo-500 shadow-lg shadow-indigo-500/20">
                                        {loading ? <><Loader2 className="w-5 h-5 animate-spin mr-2" /> Creating...</> : 'Generate Now'}
                                    </Button>
                                </div>
                            </div>
                        )}
                    </>
                )}
            </div>
        </main>
    </div>
  );
}
