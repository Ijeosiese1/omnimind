
import React, { useEffect, useState } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { Activity, Utensils, Dumbbell, Droplets, Zap, Scale, Calculator } from 'lucide-react';
import { generateMealPlan, generateWorkoutPlan, calculateMacros } from '../services/geminiService';
import { MealPlan, WorkoutDay, MacroPlan } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Mon', kcal: 2100, burn: 1800 },
  { name: 'Tue', kcal: 2300, burn: 2100 },
  { name: 'Wed', kcal: 1900, burn: 2300 },
  { name: 'Thu', kcal: 2000, burn: 1900 },
  { name: 'Fri', kcal: 2400, burn: 2500 },
  { name: 'Sat', kcal: 2600, burn: 2000 },
  { name: 'Sun', kcal: 2200, burn: 1800 },
];

export default function Fitness() {
  const [activeTab, setActiveTab] = useState<'overview' | 'meals' | 'workout' | 'macros'>('overview');
  
  // Meal Plan State
  const [mealPlan, setMealPlan] = useState<MealPlan | null>(null);
  const [loadingPlan, setLoadingPlan] = useState(false);
  
  // Workout Plan State
  const [workoutPlan, setWorkoutPlan] = useState<WorkoutDay[]>([]);
  const [wLoading, setWLoading] = useState(false);
  const [wLevel, setWLevel] = useState('Intermediate');
  const [wGoal, setWGoal] = useState('Muscle Gain');
  const [wEquipment, setWEquipment] = useState('Full Gym');
  const [wDays, setWDays] = useState(4);

  // Macros State
  const [macroPlan, setMacroPlan] = useState<MacroPlan | null>(null);
  const [mLoading, setMLoading] = useState(false);
  const [mAge, setMAge] = useState(25);
  const [mWeight, setMWeight] = useState(75); // kg
  const [mHeight, setMHeight] = useState(175); // cm
  const [mGender, setMGender] = useState('Male');
  const [mActivity, setMActivity] = useState('Moderate');
  const [mGoal, setMGoal] = useState('Maintenance');

  const createPlan = async () => {
    setLoadingPlan(true);
    const plan = await generateMealPlan("weight loss and muscle gain");
    setMealPlan(plan);
    setLoadingPlan(false);
  };

  const handleGenerateWorkout = async () => {
      setWLoading(true);
      const plan = await generateWorkoutPlan(wLevel, wGoal, wEquipment, wDays);
      setWorkoutPlan(plan);
      setWLoading(false);
  };

  const handleCalculateMacros = async () => {
      setMLoading(true);
      const result = await calculateMacros(mAge, mWeight, mHeight, mGender, mActivity, mGoal);
      setMacroPlan(result);
      setMLoading(false);
  };

  return (
    <div className="space-y-6 animate-fade-in">
        {/* Header & Nav */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 className="text-2xl font-bold text-white">Advanced Fitness Coach</h1>
                <p className="text-slate-400 text-sm">AI-Powered Training & Nutrition.</p>
            </div>
            <div className="bg-slate-800 p-1 rounded-xl flex gap-1">
                {[
                    { id: 'overview', label: 'Overview', icon: Activity },
                    { id: 'workout', label: 'Workouts', icon: Dumbbell },
                    { id: 'meals', label: 'Meal Plan', icon: Utensils },
                    { id: 'macros', label: 'Macro Calc', icon: Calculator },
                ].map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                            activeTab === tab.id 
                            ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/25' 
                            : 'text-slate-400 hover:bg-slate-700 hover:text-white'
                        }`}
                    >
                        <tab.icon className="w-4 h-4" />
                        <span className="hidden md:inline">{tab.label}</span>
                    </button>
                ))}
            </div>
        </div>

        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Stats Row */}
                <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 flex items-center gap-4">
                        <div className="p-3 bg-orange-500/10 rounded-lg text-orange-500">
                            <Activity className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-slate-400 text-xs">Steps Today</p>
                            <h3 className="text-xl font-bold text-white">8,432</h3>
                        </div>
                    </div>
                     <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 flex items-center gap-4">
                        <div className="p-3 bg-blue-500/10 rounded-lg text-blue-500">
                            <Droplets className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-slate-400 text-xs">Water Intake</p>
                            <h3 className="text-xl font-bold text-white">1.8L</h3>
                        </div>
                    </div>
                    <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 flex items-center gap-4">
                        <div className="p-3 bg-purple-500/10 rounded-lg text-purple-500">
                            <Zap className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-slate-400 text-xs">Active Cals</p>
                            <h3 className="text-xl font-bold text-white">650</h3>
                        </div>
                    </div>
                    <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 flex items-center gap-4">
                        <div className="p-3 bg-emerald-500/10 rounded-lg text-emerald-500">
                            <Scale className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-slate-400 text-xs">Current Wgt</p>
                            <h3 className="text-xl font-bold text-white">75.2kg</h3>
                        </div>
                    </div>
                </div>

                {/* Chart */}
                <Card title="Calories In vs Out" className="lg:col-span-2">
                    <div className="h-[300px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={data}>
                                <defs>
                                    <linearGradient id="colorKcal" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3}/>
                                        <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                                    </linearGradient>
                                    <linearGradient id="colorBurn" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <XAxis dataKey="name" axisLine={false} tickLine={false} stroke="#64748b" />
                                <YAxis axisLine={false} tickLine={false} stroke="#64748b" />
                                <CartesianGrid vertical={false} stroke="#334155" strokeDasharray="3 3" />
                                <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '8px' }} />
                                <Area type="monotone" dataKey="kcal" stroke="#f43f5e" fillOpacity={1} fill="url(#colorKcal)" />
                                <Area type="monotone" dataKey="burn" stroke="#3b82f6" fillOpacity={1} fill="url(#colorBurn)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </Card>

                <Card title="Daily Goals">
                     <div className="space-y-4">
                         {[{l:'Protein', p: 70, c:'bg-blue-500'}, {l:'Sleep', p: 85, c:'bg-purple-500'}, {l:'Cardio', p: 40, c:'bg-orange-500'}].map(g => (
                             <div key={g.l}>
                                 <div className="flex justify-between text-sm mb-1">
                                     <span className="text-slate-300">{g.l}</span>
                                     <span className="text-slate-400">{g.p}%</span>
                                 </div>
                                 <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                                     <div className={`h-full rounded-full ${g.c}`} style={{width: `${g.p}%`}} />
                                 </div>
                             </div>
                         ))}
                         <div className="p-4 mt-4 bg-indigo-900/20 border border-indigo-500/30 rounded-xl">
                             <p className="text-sm text-indigo-200 italic">"Consistency is the bridge between goals and accomplishment."</p>
                         </div>
                     </div>
                </Card>
            </div>
        )}

        {/* MEALS TAB */}
        {activeTab === 'meals' && (
            <div className="flex flex-col md:flex-row gap-6">
                <Card className="w-full md:w-1/3 h-fit">
                    <h3 className="font-bold text-white mb-4">Meal Planner</h3>
                    <p className="text-sm text-slate-400 mb-4">Generate a balanced meal plan based on your current metrics and goals.</p>
                    <Button onClick={createPlan} disabled={loadingPlan} className="w-full">
                         {loadingPlan ? 'Generating...' : 'Generate New Plan'}
                    </Button>
                </Card>
                
                <Card className="flex-1">
                     {mealPlan ? (
                        <div className="space-y-6 animate-fade-in">
                            <div className="flex justify-between items-center border-b border-slate-700 pb-4">
                                <h2 className="text-xl font-bold text-white">{mealPlan.day} Plan</h2>
                                <Badge color="green">{mealPlan.calories} kcal</Badge>
                            </div>
                            <div className="space-y-4">
                                <div className="p-4 bg-slate-700/30 rounded-xl border border-slate-700">
                                    <div className="text-xs text-indigo-400 font-bold mb-1 uppercase flex items-center gap-2"><Utensils className="w-3 h-3"/> Breakfast</div>
                                    <p className="text-slate-200 font-medium text-lg">{mealPlan.breakfast}</p>
                                </div>
                                <div className="p-4 bg-slate-700/30 rounded-xl border border-slate-700">
                                    <div className="text-xs text-indigo-400 font-bold mb-1 uppercase flex items-center gap-2"><Utensils className="w-3 h-3"/> Lunch</div>
                                    <p className="text-slate-200 font-medium text-lg">{mealPlan.lunch}</p>
                                </div>
                                <div className="p-4 bg-slate-700/30 rounded-xl border border-slate-700">
                                    <div className="text-xs text-indigo-400 font-bold mb-1 uppercase flex items-center gap-2"><Utensils className="w-3 h-3"/> Dinner</div>
                                    <p className="text-slate-200 font-medium text-lg">{mealPlan.dinner}</p>
                                </div>
                            </div>
                        </div>
                    ) : (
                         <div className="flex flex-col items-center justify-center text-slate-500 text-center p-12">
                             <Utensils className="w-16 h-16 mb-4 opacity-20" />
                             <p className="text-lg">No active meal plan.</p>
                             <p>Click generate to get started.</p>
                         </div>
                    )}
                </Card>
            </div>
        )}

        {/* WORKOUT TAB */}
        {activeTab === 'workout' && (
            <div className="space-y-6">
                <Card>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
                        <div>
                            <label className="text-xs text-slate-400 block mb-1">Level</label>
                            <select value={wLevel} onChange={e => setWLevel(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-sm">
                                <option>Beginner</option><option>Intermediate</option><option>Advanced</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-xs text-slate-400 block mb-1">Goal</label>
                            <select value={wGoal} onChange={e => setWGoal(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-sm">
                                <option>Muscle Gain</option><option>Weight Loss</option><option>Endurance</option><option>Strength</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-xs text-slate-400 block mb-1">Equipment</label>
                            <select value={wEquipment} onChange={e => setWEquipment(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-sm">
                                <option>Full Gym</option><option>Dumbbells Only</option><option>Bodyweight</option><option>Home Gym</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-xs text-slate-400 block mb-1">Days/Week</label>
                            <select value={wDays} onChange={e => setWDays(parseInt(e.target.value))} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-sm">
                                <option value={3}>3 Days</option><option value={4}>4 Days</option><option value={5}>5 Days</option><option value={6}>6 Days</option>
                            </select>
                        </div>
                        <Button onClick={handleGenerateWorkout} disabled={wLoading} className="bg-indigo-600 hover:bg-indigo-500">
                            {wLoading ? 'Building Plan...' : 'Generate Routine'}
                        </Button>
                    </div>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {workoutPlan.length > 0 ? workoutPlan.map((day, idx) => (
                        <Card key={idx} className="border-t-4 border-t-indigo-500">
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="font-bold text-white text-lg">{day.day}</h3>
                                <Badge color="purple">{day.focus}</Badge>
                            </div>
                            <div className="space-y-3">
                                {day.exercises.map((ex, i) => (
                                    <div key={i} className="bg-slate-800/50 p-3 rounded-lg border border-slate-700/50">
                                        <div className="flex justify-between items-start">
                                            <h4 className="font-bold text-slate-200">{ex.name}</h4>
                                            <span className="text-xs font-mono text-indigo-300 bg-indigo-900/30 px-2 py-0.5 rounded">{ex.sets} x {ex.reps}</span>
                                        </div>
                                        {ex.notes && <p className="text-xs text-slate-500 mt-1 italic">{ex.notes}</p>}
                                    </div>
                                ))}
                            </div>
                        </Card>
                    )) : (
                        <div className="col-span-full text-center py-12 text-slate-500 bg-slate-800/30 rounded-xl">
                            <Dumbbell className="w-12 h-12 mx-auto mb-4 opacity-20" />
                            <p>No workout plan generated. Configure your settings above.</p>
                        </div>
                    )}
                </div>
            </div>
        )}

        {/* MACROS TAB */}
        {activeTab === 'macros' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <Card title="Calculator Inputs">
                     <div className="space-y-4">
                         <div className="grid grid-cols-2 gap-4">
                             <div>
                                 <label className="text-xs text-slate-400">Age</label>
                                 <input type="number" value={mAge} onChange={e => setMAge(parseInt(e.target.value))} className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white" />
                             </div>
                             <div>
                                 <label className="text-xs text-slate-400">Gender</label>
                                 <select value={mGender} onChange={e => setMGender(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white">
                                     <option>Male</option><option>Female</option>
                                 </select>
                             </div>
                             <div>
                                 <label className="text-xs text-slate-400">Weight (kg)</label>
                                 <input type="number" value={mWeight} onChange={e => setMWeight(parseInt(e.target.value))} className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white" />
                             </div>
                             <div>
                                 <label className="text-xs text-slate-400">Height (cm)</label>
                                 <input type="number" value={mHeight} onChange={e => setMHeight(parseInt(e.target.value))} className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white" />
                             </div>
                         </div>
                         <div>
                             <label className="text-xs text-slate-400">Activity Level</label>
                             <select value={mActivity} onChange={e => setMActivity(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white">
                                 <option>Sedentary</option><option>Lightly Active</option><option>Moderate</option><option>Very Active</option><option>Athlete</option>
                             </select>
                         </div>
                         <div>
                             <label className="text-xs text-slate-400">Goal</label>
                             <select value={mGoal} onChange={e => setMGoal(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white">
                                 <option>Lose Weight</option><option>Maintenance</option><option>Gain Muscle</option>
                             </select>
                         </div>
                         <Button onClick={handleCalculateMacros} disabled={mLoading} className="w-full">
                             {mLoading ? 'Calculating...' : 'Calculate Macros'}
                         </Button>
                     </div>
                 </Card>

                 <div className="flex items-center justify-center">
                     {macroPlan ? (
                         <Card className="w-full bg-gradient-to-br from-indigo-900/50 to-slate-900 border-indigo-500/30 text-center animate-fade-in">
                             <h3 className="text-2xl font-bold text-white mb-2">{macroPlan.calories} <span className="text-sm text-slate-400 font-normal">kcal/day</span></h3>
                             <p className="text-sm text-indigo-300 mb-6">{macroPlan.advice}</p>
                             
                             <div className="flex justify-center gap-4">
                                 <div className="p-4 bg-slate-800 rounded-xl w-24">
                                     <div className="text-xs text-slate-500 uppercase font-bold mb-1">Protein</div>
                                     <div className="text-xl font-bold text-emerald-400">{macroPlan.protein}</div>
                                 </div>
                                 <div className="p-4 bg-slate-800 rounded-xl w-24">
                                     <div className="text-xs text-slate-500 uppercase font-bold mb-1">Carbs</div>
                                     <div className="text-xl font-bold text-blue-400">{macroPlan.carbs}</div>
                                 </div>
                                 <div className="p-4 bg-slate-800 rounded-xl w-24">
                                     <div className="text-xs text-slate-500 uppercase font-bold mb-1">Fats</div>
                                     <div className="text-xl font-bold text-yellow-400">{macroPlan.fats}</div>
                                 </div>
                             </div>
                         </Card>
                     ) : (
                         <div className="text-center text-slate-500">
                             <Calculator className="w-16 h-16 mx-auto mb-4 opacity-20" />
                             <p>Enter your details to see your personalized macro split.</p>
                         </div>
                     )}
                 </div>
            </div>
        )}
    </div>
  );
}