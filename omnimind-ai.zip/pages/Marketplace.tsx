import React, { useEffect, useState } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { Star, MapPin, Calendar, Search, Sparkles, Filter } from 'lucide-react';
import { ProfessionalProfile } from '../types';
import { Backend } from '../services/backend';
import { recommendProfessionals } from '../services/geminiService';
import { Link } from 'react-router-dom';

export default function Marketplace() {
  const [pros, setPros] = useState<ProfessionalProfile[]>([]);
  const [filteredPros, setFilteredPros] = useState<ProfessionalProfile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [isAiSearching, setIsAiSearching] = useState(false);

  useEffect(() => {
    Backend.getProfessionals().then(data => {
        setPros(data);
        setFilteredPros(data);
    });
  }, []);

  const handleAiSearch = async () => {
    if (!searchQuery.trim()) {
        setFilteredPros(pros);
        return;
    }
    setIsAiSearching(true);
    const results = await recommendProfessionals(searchQuery, pros);
    setFilteredPros(results);
    setIsAiSearching(false);
  };

  const handleCategoryClick = (cat: string) => {
    setActiveCategory(cat);
    if (cat === 'All') {
        setFilteredPros(pros);
    } else {
        setFilteredPros(pros.filter(p => p.category.includes(cat)));
    }
  };

  const categories = ['All', 'Health & Medical', 'Fitness Trainers', 'Tutors/Instructors', 'Mechanics', 'Beauty & Salon'];

  return (
    <div className="space-y-6">
        {/* Header & Search */}
        <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
            <div className="mb-4">
                <h1 className="text-3xl font-bold text-white mb-2">Find a Professional</h1>
                <p className="text-slate-400">Book trusted experts for health, fitness, education, and more.</p>
            </div>
            
            <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative group">
                    <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                    <input 
                        type="text" 
                        placeholder="Describe what you need (e.g. 'I need a math tutor for calculus')"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl py-3 pl-12 pr-4 text-white focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAiSearch()}
                    />
                </div>
                <Button onClick={handleAiSearch} disabled={isAiSearching} className="bg-gradient-to-r from-indigo-600 to-purple-600">
                    {isAiSearching ? <Sparkles className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
                    <span className="ml-2">{isAiSearching ? 'AI Finding...' : 'AI Match'}</span>
                </Button>
            </div>
        </div>

        {/* Categories */}
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map(cat => (
                <button 
                    key={cat} 
                    onClick={() => handleCategoryClick(cat)}
                    className={`px-4 py-2 rounded-full border text-sm font-medium whitespace-nowrap transition-all ${
                        activeCategory === cat 
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-500/20' 
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700 hover:text-white'
                    }`}
                >
                    {cat}
                </button>
            ))}
        </div>

        {/* Pros Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPros.length > 0 ? (
                filteredPros.map(pro => (
                    <Link key={pro.id} to={`/professional/${pro.id}`}>
                        <Card className="h-full hover:border-indigo-500/50 transition-all cursor-pointer group relative overflow-hidden">
                            <div className="flex items-start gap-4">
                                <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-700">
                                    <img src={pro.imageUrl} alt={pro.businessName} className="w-full h-full object-cover" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <h3 className="font-bold text-white text-lg truncate group-hover:text-indigo-400 transition-colors">{pro.businessName}</h3>
                                    <p className="text-sm text-indigo-300 mb-1">{pro.category}</p>
                                    <div className="flex items-center gap-1">
                                        <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                                        <span className="text-sm text-slate-300 font-medium">{pro.rating}</span>
                                        <span className="text-xs text-slate-500">({pro.reviewCount} reviews)</span>
                                    </div>
                                </div>
                            </div>
                            
                            <p className="mt-4 text-sm text-slate-400 line-clamp-2 h-10">{pro.bio}</p>
                            
                            <div className="mt-4 flex items-center text-xs text-slate-500 gap-2">
                                <MapPin className="w-3.5 h-3.5" />
                                <span className="truncate">{pro.location}</span>
                            </div>

                            <div className="mt-4 pt-4 border-t border-slate-700 flex items-center justify-between">
                                <div>
                                    <span className="text-xs text-slate-500">Starting at</span>
                                    <div className="text-lg font-bold text-white">${Math.min(...pro.services.map(s => s.price))}</div>
                                </div>
                                <Button className="text-sm px-4 py-2">
                                    View Profile
                                </Button>
                            </div>
                        </Card>
                    </Link>
                ))
            ) : (
                <div className="col-span-full py-12 text-center text-slate-500">
                    <Search className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p className="text-lg font-medium">No professionals found.</p>
                    <p className="text-sm">Try adjusting your search or category.</p>
                </div>
            )}
        </div>
    </div>
  );
}