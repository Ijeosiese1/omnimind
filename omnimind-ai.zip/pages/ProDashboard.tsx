import React, { useEffect, useState } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { CalendarCheck, DollarSign, Clock, Check, X, UserCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Backend } from '../services/backend';
import { Appointment, ProfessionalProfile } from '../types';

export default function ProDashboard() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<ProfessionalProfile | null>(null);
  const [appts, setAppts] = useState<Appointment[]>([]);
  const [refresh, setRefresh] = useState(0);

  useEffect(() => {
    if (user) {
        Backend.getProfessionalByUserId(user.id).then(pro => {
            setProfile(pro || null);
            if (pro) {
                Backend.getAppointmentsForPro(pro.id).then(setAppts);
            }
        });
    }
  }, [user, refresh]);

  const handleStatus = async (id: string, status: 'confirmed' | 'rejected') => {
      await Backend.updateAppointmentStatus(id, status);
      setRefresh(prev => prev + 1);
  };

  const createProfile = async () => {
      if(!user) return;
      // Mock creation
      const newProfile: ProfessionalProfile = {
          id: '', userId: user.id,
          businessName: user.name + "'s Services",
          category: "General",
          bio: "I am a new professional on OmniMind.",
          location: "Remote",
          services: [{ id: 's1', name: 'Consultation', price: 50, duration: 30 }],
          rating: 5.0,
          reviewCount: 0,
          imageUrl: "https://picsum.photos/200",
          availability: ["09:00", "10:00", "11:00"]
      };
      await Backend.becomeProfessional(user.id, newProfile);
      window.location.reload();
  };

  if (!profile) {
      return (
          <div className="text-center py-20">
              <h1 className="text-3xl font-bold text-white mb-4">Become a Professional</h1>
              <p className="text-slate-400 mb-8 max-w-md mx-auto">Start offering your services on OmniMind today. Create your business profile and start accepting bookings.</p>
              <Button onClick={createProfile} className="px-8 py-4 text-lg">Create Business Profile</Button>
          </div>
      );
  }

  const earnings = appts.filter(a => a.status === 'completed' || a.status === 'confirmed').reduce((sum, a) => sum + a.price, 0);
  const pending = appts.filter(a => a.status === 'pending').length;

  return (
    <div className="space-y-6 animate-fade-in">
        <div className="flex justify-between items-end">
            <div>
                <h1 className="text-2xl font-bold text-white">Professional Dashboard</h1>
                <p className="text-slate-400">Welcome back, {profile.businessName}</p>
            </div>
            <div className="text-right">
                <p className="text-sm text-slate-400">Total Earnings</p>
                <h2 className="text-3xl font-bold text-emerald-400">${earnings}</h2>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Appointments List */}
            <div className="lg:col-span-2 space-y-4">
                <h3 className="font-bold text-white">Incoming Bookings</h3>
                {appts.length > 0 ? appts.map(appt => (
                    <Card key={appt.id} className={`border-l-4 ${appt.status === 'pending' ? 'border-l-yellow-500' : appt.status === 'confirmed' ? 'border-l-green-500' : 'border-l-slate-600'}`}>
                        <div className="flex justify-between items-start">
                            <div>
                                <div className="flex items-center gap-2 mb-1">
                                    <h4 className="font-bold text-white">{appt.customerName}</h4>
                                    <Badge color={appt.status === 'pending' ? 'yellow' : appt.status === 'confirmed' ? 'green' : 'blue'}>{appt.status}</Badge>
                                </div>
                                <p className="text-sm text-indigo-300">{appt.serviceName}</p>
                                <div className="flex gap-4 mt-2 text-sm text-slate-400">
                                    <span className="flex items-center gap-1"><CalendarCheck className="w-3 h-3"/> {appt.date}</span>
                                    <span className="flex items-center gap-1"><Clock className="w-3 h-3"/> {appt.time}</span>
                                </div>
                            </div>
                            <div className="text-right">
                                <span className="font-bold text-white text-lg">${appt.price}</span>
                            </div>
                        </div>
                        
                        {appt.status === 'pending' && (
                            <div className="flex gap-3 mt-4 pt-4 border-t border-slate-700">
                                <Button onClick={() => handleStatus(appt.id, 'confirmed')} className="flex-1 bg-emerald-600 hover:bg-emerald-500">
                                    <Check className="w-4 h-4 mr-2" /> Accept
                                </Button>
                                <Button onClick={() => handleStatus(appt.id, 'rejected')} variant="outline" className="flex-1 text-red-400 border-red-900/50 hover:bg-red-900/20">
                                    <X className="w-4 h-4 mr-2" /> Reject
                                </Button>
                            </div>
                        )}
                    </Card>
                )) : (
                    <div className="p-8 text-center bg-slate-800/30 rounded-xl text-slate-500">No bookings yet.</div>
                )}
            </div>

            {/* Stats & Quick Actions */}
            <div className="space-y-6">
                <Card className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 border-indigo-500/30">
                    <h3 className="font-bold text-white mb-4">Quick Stats</h3>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <span className="text-slate-300">Pending Requests</span>
                            <Badge color="yellow">{pending}</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-slate-300">Total Bookings</span>
                            <span className="text-white font-bold">{appts.length}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-slate-300">Rating</span>
                            <span className="text-yellow-400 font-bold flex items-center gap-1"><UserCheck className="w-4 h-4"/> {profile.rating}</span>
                        </div>
                    </div>
                </Card>

                <Card title="My Services">
                    <div className="space-y-2">
                        {profile.services.map(s => (
                            <div key={s.id} className="p-2 rounded bg-slate-800/50 flex justify-between items-center text-sm">
                                <span className="text-slate-300">{s.name}</span>
                                <span className="text-white font-bold">${s.price}</span>
                            </div>
                        ))}
                        <Button variant="outline" className="w-full mt-2 text-xs">Manage Services</Button>
                    </div>
                </Card>
            </div>
        </div>
    </div>
  );
}