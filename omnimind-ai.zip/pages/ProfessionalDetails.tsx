import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { Star, MapPin, Clock, CheckCircle2, ChevronLeft, CalendarCheck, CreditCard } from 'lucide-react';
import { Backend } from '../services/backend';
import { ProfessionalProfile, ServiceItem } from '../types';
import { useAuth } from '../context/AuthContext';

export default function ProfessionalDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [pro, setPro] = useState<ProfessionalProfile | null>(null);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [step, setStep] = useState(1); // 1: Select Service, 2: Select Date/Time, 3: Payment/Confirm
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (id) {
      Backend.getProfessionalById(id).then(data => {
          if (data) setPro(data);
      });
    }
  }, [id]);

  // Simple next 7 days generator
  const getNext7Days = () => {
      const dates = [];
      for(let i=0; i<7; i++) {
          const d = new Date();
          d.setDate(d.getDate() + i);
          dates.push(d.toISOString().split('T')[0]);
      }
      return dates;
  };

  const handleBook = async () => {
      if (!pro || !selectedService || !user) return;
      setLoading(true);
      try {
          await Backend.createAppointment({
              id: Date.now().toString(),
              professionalId: pro.id,
              professionalName: pro.businessName,
              customerId: user.id,
              customerName: user.name,
              serviceId: selectedService.id,
              serviceName: selectedService.name,
              price: selectedService.price,
              date: selectedDate,
              time: selectedTime,
              status: 'pending',
              createdAt: Date.now()
          });
          alert("Booking Request Sent! The professional will confirm shortly.");
          navigate('/'); // Redirect to home or appointments
      } catch (e) {
          console.error(e);
          alert("Failed to book.");
      } finally {
          setLoading(false);
      }
  };

  if (!pro) return <div className="p-10 text-center text-slate-500">Professional not found</div>;

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
        <Button variant="outline" onClick={() => navigate(-1)} className="mb-6">
            <ChevronLeft className="w-4 h-4 mr-2" /> Back to Marketplace
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left: Profile Info */}
            <div className="lg:col-span-2 space-y-6">
                {/* Header Card */}
                <Card className="relative overflow-hidden border-indigo-500/30">
                    <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-indigo-900 to-purple-900 opacity-50" />
                    <div className="relative z-10 pt-12 px-4">
                        <div className="flex flex-col sm:flex-row gap-4 items-start">
                            <img src={pro.imageUrl} alt={pro.businessName} className="w-24 h-24 rounded-2xl border-4 border-slate-800 object-cover shadow-xl" />
                            <div className="mt-2">
                                <h1 className="text-2xl font-bold text-white">{pro.businessName}</h1>
                                <p className="text-indigo-300 font-medium">{pro.category}</p>
                                <div className="flex items-center gap-4 mt-2 text-sm text-slate-400">
                                    <div className="flex items-center gap-1">
                                        <MapPin className="w-4 h-4" /> {pro.location}
                                    </div>
                                    <div className="flex items-center gap-1">
                                        <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" /> 
                                        <span className="text-white font-bold">{pro.rating}</span> ({pro.reviewCount})
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="mt-6">
                            <h3 className="text-lg font-semibold text-white mb-2">About</h3>
                            <p className="text-slate-300 leading-relaxed text-sm">{pro.bio}</p>
                        </div>
                    </div>
                </Card>

                {/* Services List */}
                {step === 1 && (
                    <Card title="Select a Service">
                        <div className="space-y-3">
                            {pro.services.map(service => (
                                <div 
                                    key={service.id} 
                                    onClick={() => setSelectedService(service)}
                                    className={`p-4 rounded-xl border cursor-pointer transition-all flex justify-between items-center ${
                                        selectedService?.id === service.id 
                                        ? 'bg-indigo-600/20 border-indigo-500' 
                                        : 'bg-slate-800/50 border-slate-700 hover:border-slate-500'
                                    }`}
                                >
                                    <div>
                                        <h4 className="font-bold text-white">{service.name}</h4>
                                        <p className="text-sm text-slate-400">{service.description}</p>
                                        <div className="flex items-center gap-2 mt-2 text-xs text-indigo-300">
                                            <Clock className="w-3 h-3" /> {service.duration} mins
                                        </div>
                                    </div>
                                    <div className="text-xl font-bold text-white">
                                        ${service.price}
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="mt-6 flex justify-end">
                            <Button disabled={!selectedService} onClick={() => setStep(2)}>
                                Continue to Date & Time
                            </Button>
                        </div>
                    </Card>
                )}

                {/* Date & Time Selection */}
                {step === 2 && (
                    <Card title="Select Availability">
                        <div className="mb-4">
                            <label className="block text-sm text-slate-400 mb-2">Date</label>
                            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                                {getNext7Days().map(date => (
                                    <button 
                                        key={date}
                                        onClick={() => setSelectedDate(date)}
                                        className={`flex flex-col items-center p-3 rounded-xl border min-w-[80px] transition-all ${
                                            selectedDate === date 
                                            ? 'bg-indigo-600 text-white border-indigo-500' 
                                            : 'bg-slate-800 text-slate-400 border-slate-700 hover:border-slate-500'
                                        }`}
                                    >
                                        <span className="text-xs font-medium">{new Date(date).toLocaleDateString('en-US', { weekday: 'short' })}</span>
                                        <span className="text-lg font-bold">{new Date(date).getDate()}</span>
                                    </button>
                                ))}
                            </div>
                        </div>

                        {selectedDate && (
                            <div>
                                <label className="block text-sm text-slate-400 mb-2">Available Slots</label>
                                <div className="grid grid-cols-3 gap-3">
                                    {pro.availability.map(time => (
                                        <button
                                            key={time}
                                            onClick={() => setSelectedTime(time)}
                                            className={`py-2 px-4 rounded-lg border text-sm font-medium transition-all ${
                                                selectedTime === time
                                                ? 'bg-indigo-600 text-white border-indigo-500'
                                                : 'bg-slate-800 text-slate-300 border-slate-700 hover:border-indigo-400'
                                            }`}
                                        >
                                            {time}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                         <div className="mt-8 flex justify-between">
                            <Button variant="secondary" onClick={() => setStep(1)}>Back</Button>
                            <Button disabled={!selectedDate || !selectedTime} onClick={() => setStep(3)}>
                                Continue to Payment
                            </Button>
                        </div>
                    </Card>
                )}

                 {/* Payment Confirmation */}
                 {step === 3 && selectedService && (
                     <Card title="Confirm & Pay">
                         <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 mb-6">
                             <h4 className="text-slate-400 text-sm mb-4 uppercase tracking-wider">Booking Summary</h4>
                             <div className="flex justify-between mb-2">
                                 <span className="text-white">{selectedService.name}</span>
                                 <span className="text-white font-medium">${selectedService.price}</span>
                             </div>
                             <div className="flex justify-between mb-2 text-sm text-slate-400">
                                 <span>Date & Time</span>
                                 <span>{selectedDate} at {selectedTime}</span>
                             </div>
                             <div className="flex justify-between mb-2 text-sm text-slate-400">
                                 <span>Duration</span>
                                 <span>{selectedService.duration} mins</span>
                             </div>
                             <div className="border-t border-slate-800 mt-4 pt-4 flex justify-between items-center">
                                 <span className="font-bold text-white">Total to Pay</span>
                                 <span className="font-bold text-xl text-indigo-400">${selectedService.price}</span>
                             </div>
                         </div>

                         <div className="space-y-3">
                             <button className="w-full p-4 rounded-xl border border-indigo-500 bg-indigo-500/10 flex items-center justify-between text-indigo-300">
                                 <div className="flex items-center gap-3">
                                     <CreditCard className="w-5 h-5" />
                                     <span className="font-medium">Direct Manual Transfer</span>
                                 </div>
                                 <CheckCircle2 className="w-5 h-5" />
                             </button>
                             <button className="w-full p-4 rounded-xl border border-slate-700 bg-slate-800/50 flex items-center gap-3 text-slate-400 opacity-50 cursor-not-allowed">
                                 <div className="w-5 h-5 bg-white rounded full" />
                                 <span className="font-medium">Apple Pay (Coming Soon)</span>
                             </button>
                         </div>

                         <div className="mt-8 flex justify-between">
                            <Button variant="secondary" onClick={() => setStep(2)}>Back</Button>
                            <Button onClick={handleBook} disabled={loading} className="w-1/2">
                                {loading ? 'Processing...' : 'Confirm Booking'}
                            </Button>
                        </div>
                     </Card>
                 )}
            </div>

            {/* Right: Booking Sticky Summary (Desktop) */}
            <div className="hidden lg:block">
                 <Card className="sticky top-6 bg-indigo-900/20 border-indigo-500/30">
                     <h3 className="font-bold text-white mb-4">Why Book with {pro.businessName.split(' ')[0]}?</h3>
                     <ul className="space-y-3 text-sm text-indigo-200">
                         <li className="flex gap-2"><CheckCircle2 className="w-4 h-4" /> Verified Professional</li>
                         <li className="flex gap-2"><CheckCircle2 className="w-4 h-4" /> {pro.reviewCount}+ Happy Customers</li>
                         <li className="flex gap-2"><CheckCircle2 className="w-4 h-4" /> Secure Payment Protection</li>
                         <li className="flex gap-2"><CheckCircle2 className="w-4 h-4" /> Free Cancellation (24h)</li>
                     </ul>
                 </Card>
            </div>
        </div>
    </div>
  );
}