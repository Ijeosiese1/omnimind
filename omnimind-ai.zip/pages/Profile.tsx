import React, { useState, useEffect, useRef } from 'react';
import { Card, Badge } from '../components/ui/Widgets';
import { Crown, MessageSquare, Send, Lock, Loader2, Bot } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { SupportMessage } from '../types';
import { generateChatResponse } from '../services/geminiService';

export default function Profile() {
  const { user } = useAuth();
  
  // Chat State
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [showChat, setShowChat] = useState(false);
  const [isAiThinking, setIsAiThinking] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
      if(user && messages.length === 0) {
          setMessages([{
              id: 'welcome',
              senderId: 'ai_support',
              receiverId: user.id,
              senderName: 'OmniBot Support',
              text: `Hello ${user.name}! I am the AI Support for OmniMind, developed by Bamanosi Ijeosiese Ayomide. Ask me anything about the app features like Life OS, Study Hub, or Creative Studio!`,
              timestamp: Date.now(),
              read: true
          }]);
      }
  }, [user]);

  useEffect(() => {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, showChat]);

  const handleSendMessage = async () => {
      if (!newMessage.trim() || !user) return;
      
      const userMsg: SupportMessage = {
          id: Date.now().toString(),
          senderId: user.id,
          receiverId: 'ai_support',
          senderName: user.name,
          text: newMessage,
          timestamp: Date.now(),
          read: false
      };
      
      setMessages(prev => [...prev, userMsg]);
      setNewMessage('');
      setIsAiThinking(true);

      try {
          const history = messages.map(m => ({
              role: m.senderId === 'ai_support' ? 'model' : 'user',
              text: m.text
          }));

          const systemInstruction = `
            You are the official AI Support Agent for OmniMind AI, a super-app developed by Bamanosi Ijeosiese Ayomide.
            
            The app contains these modules:
            1. Life OS: Dashboard, Todo List, Financial Tracker, Journal, Calendar.
            2. AI Assistant: General chat, coding help, translation.
            3. Study Hub: Flashcards, Quiz Generator, AI Tutor, Past Questions.
            4. Creative Studio: AI Image Generator, Logo Maker, Poster Designer, Toolchain mode.
            5. Fitness Coach: Meal Plans, Workout Plans, Macro Calculator.
            6. Article Writer: AI blog and article generator with SEO.
            7. Project Writer: Academic and Business project structure generator.
            8. Prompt Engine: Tool to refine and generate AI prompts.

            Your goal is to help the user navigate and use these features. Be polite, concise, and helpful.
            If asked about the developer, always credit Bamanosi Ijeosiese Ayomide.
          `;

          const responseText = await generateChatResponse(
              history,
              userMsg.text,
              null,
              systemInstruction,
              'gemini-2.5-flash'
          );

          const aiMsg: SupportMessage = {
              id: (Date.now() + 1).toString(),
              senderId: 'ai_support',
              receiverId: user.id,
              senderName: 'OmniBot Support',
              text: responseText,
              timestamp: Date.now(),
              read: true
          };
          setMessages(prev => [...prev, aiMsg]);

      } catch (error) {
          const errorMsg: SupportMessage = {
              id: (Date.now() + 1).toString(),
              senderId: 'ai_support',
              receiverId: user.id,
              senderName: 'OmniBot Support',
              text: "I'm having trouble connecting to the support server right now. Please try again later.",
              timestamp: Date.now(),
              read: true
          };
          setMessages(prev => [...prev, errorMsg]);
      } finally {
          setIsAiThinking(false);
      }
  };

  if (!user) return null;

  return (
    <div className="space-y-6 max-w-3xl mx-auto animate-fade-in relative pb-20">
       {/* Chat Bubble */}
       <div className="fixed bottom-20 right-4 md:right-6 z-50">
            {!showChat ? (
                <button 
                    onClick={() => setShowChat(true)}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white p-4 rounded-full shadow-2xl border border-indigo-400 flex items-center gap-2 group transition-all hover:scale-105"
                >
                    <MessageSquare className="w-6 h-6 group-hover:animate-bounce" />
                    <span className="font-bold hidden md:inline">AI Support</span>
                </button>
            ) : (
                <div className="bg-slate-900 border border-slate-700 w-[90vw] md:w-96 h-[500px] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-200">
                    <div className="p-4 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                            <h4 className="font-bold text-white text-sm">OmniBot Support</h4>
                        </div>
                        <button onClick={() => setShowChat(false)}><Lock className="w-4 h-4 text-slate-400 hover:text-white" /></button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar bg-slate-900/50">
                        {messages.map(m => (
                            <div key={m.id} className={`flex flex-col ${m.senderId === user.id ? 'items-end' : 'items-start'}`}>
                                <div className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed shadow-sm ${
                                    m.senderId === user.id 
                                    ? 'bg-indigo-600 text-white rounded-tr-none' 
                                    : 'bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700'
                                }`}>
                                    {m.text}
                                </div>
                                <span className="text-[9px] text-slate-500 mt-1 ml-1">{new Date(m.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                            </div>
                        ))}
                        {isAiThinking && (
                            <div className="flex items-start gap-2">
                                <div className="bg-slate-800 p-2 rounded-xl rounded-tl-none border border-slate-700">
                                    <Loader2 className="w-3 h-3 animate-spin text-indigo-400" />
                                </div>
                            </div>
                        )}
                        <div ref={chatEndRef} />
                    </div>
                    <div className="p-3 bg-slate-800 border-t border-slate-700 flex gap-2">
                        <input 
                            value={newMessage}
                            onChange={e => setNewMessage(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                            placeholder="Ask about OmniMind..."
                            className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:border-indigo-500 focus:outline-none"
                        />
                        <button 
                            onClick={handleSendMessage} 
                            disabled={!newMessage.trim() || isAiThinking}
                            className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl disabled:opacity-50 transition-colors"
                        >
                            <Send className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            )}
       </div>

       <div className="text-center mb-8 pt-4">
            <div className="w-24 h-24 bg-slate-800 rounded-full mx-auto mb-4 flex items-center justify-center border-4 border-emerald-500 shadow-[0_0_30px_rgba(16,185,129,0.3)]">
                <span className="text-3xl font-bold text-emerald-400">{user.name.charAt(0)}</span>
            </div>
            <h1 className="text-2xl font-bold text-white">{user.name}</h1>
            <p className="text-slate-400">Guest User • Full Access</p>
       </div>

       <Card title="Access Status">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                <div className="flex items-center gap-3 text-left">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 shadow-lg shadow-emerald-500/20">
                        <Crown className="w-6 h-6 text-white" />
                    </div>
                    <div>
                        <h3 className="font-bold text-white">All Features Unlocked</h3>
                        <p className="text-sm text-slate-400">Enjoy OmniMind for free.</p>
                    </div>
                </div>
                <Badge color="green" className="px-4 py-1">ACTIVE</Badge>
            </div>

            <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-5">
                <h4 className="font-bold text-white mb-3 text-sm uppercase tracking-wider">Included Features</h4>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-slate-400">
                    <li className="flex items-center gap-2"><Bot className="w-4 h-4 text-indigo-400" /> Unlimited AI Generations</li>
                    <li className="flex items-center gap-2"><Bot className="w-4 h-4 text-indigo-400" /> Advanced Toolchain Access</li>
                    <li className="flex items-center gap-2"><Bot className="w-4 h-4 text-indigo-400" /> Image Generation</li>
                    <li className="flex items-center gap-2"><Bot className="w-4 h-4 text-indigo-400" /> Web Builder & Code Export</li>
                    <li className="flex items-center gap-2"><Bot className="w-4 h-4 text-indigo-400" /> No Login Required</li>
                </ul>
            </div>
       </Card>
    </div>
  );
}