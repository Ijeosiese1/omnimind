
import React, { useState, useEffect, useRef } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { 
    Briefcase, FileText, Book, CheckCircle2, 
    ChevronRight, Wand2, Save, Download, Layers, Zap, Sparkles,
    Paperclip, Upload, File as FileIcon
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Backend } from '../services/backend';
import { generateProjectTopics, generateProjectChapter, generateProjectStructureFromAttachment } from '../services/geminiService';
import { AcademicProject } from '../types';

export default function ProjectWriter() {
  const { user } = useAuth();
  const [projects, setProjects] = useState<AcademicProject[]>([]);
  const [activeProject, setActiveProject] = useState<AcademicProject | null>(null);
  
  // Creation Wizard
  const [step, setStep] = useState(1);
  const [newField, setNewField] = useState('');
  const [newTopic, setNewTopic] = useState('');
  const [newType, setNewType] = useState<'academic' | 'business' | 'technical'>('academic');
  const [suggestedTopics, setSuggestedTopics] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{name: string, base64: string} | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Editor
  const [currentChapterIndex, setCurrentChapterIndex] = useState(0);
  const [mode, setMode] = useState<'standard' | 'advanced'>('standard');

  useEffect(() => {
      if (user) Backend.getProjects(user.id).then(setProjects);
  }, [user]);

  const handleGenerateTopics = async () => {
      if (!newField) return;
      setLoading(true);
      const topics = await generateProjectTopics(newField, newType);
      setSuggestedTopics(topics);
      setLoading(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const base64 = (reader.result as string).split(',')[1];
              setAttachedFile({ name: file.name, base64 });
          };
          reader.readAsDataURL(file);
      }
  };

  const handleStartProject = async (title?: string) => {
      if (!user) return;
      const finalTitle = title || newTopic;
      if (!finalTitle) {
          alert("Please enter a project topic or select one.");
          return;
      }

      setLoading(true);
      
      let initialChapters: {title: string, content: string}[] = [];

      if (attachedFile) {
          // Parse structure from file
          initialChapters = await generateProjectStructureFromAttachment(attachedFile.base64, `Create a structure for a ${newType} project titled "${finalTitle}" about ${newField}`);
      } 
      
      // Fallback if file parsing failed or no file
      if (initialChapters.length === 0) {
          if (newType === 'academic') {
              initialChapters = [
                  { title: 'Chapter 1: Introduction', content: '' },
                  { title: 'Chapter 2: Literature Review', content: '' },
                  { title: 'Chapter 3: Methodology', content: '' },
                  { title: 'Chapter 4: Data Analysis', content: '' },
                  { title: 'Chapter 5: Conclusion', content: '' }
              ];
          } else if (newType === 'business') {
              initialChapters = [
                  { title: 'Executive Summary', content: '' },
                  { title: 'Market Analysis', content: '' },
                  { title: 'Financial Projections', content: '' },
                  { title: 'Strategy', content: '' }
              ];
          } else {
               initialChapters = [
                  { title: 'System Analysis', content: '' },
                  { title: 'System Design', content: '' },
                  { title: 'Implementation', content: '' },
                  { title: 'Testing', content: '' }
              ];
          }
      }

      const newProject: AcademicProject = {
          id: Date.now().toString(),
          userId: user.id,
          title: finalTitle,
          type: newType,
          field: newField || 'General',
          chapters: initialChapters,
          status: 'draft',
          createdAt: Date.now()
      };
      
      await Backend.saveProject(newProject);
      setProjects([...projects, newProject]);
      setActiveProject(newProject);
      setCurrentChapterIndex(0);
      setStep(1); // Reset for next time
      setNewField('');
      setNewTopic('');
      setSuggestedTopics([]);
      setAttachedFile(null);
      setLoading(false);
  };

  const handleWriteChapter = async () => {
      if (!activeProject) return;
      setLoading(true);
      const chapter = activeProject.chapters[currentChapterIndex];
      const context = currentChapterIndex > 0 ? activeProject.chapters[currentChapterIndex - 1].content.substring(0, 500) : "Start of project.";
      
      const content = await generateProjectChapter(activeProject.title, chapter.title, context, mode);
      
      const updatedChapters = [...activeProject.chapters];
      updatedChapters[currentChapterIndex].content = content;
      
      const updatedProject = { ...activeProject, chapters: updatedChapters };
      setActiveProject(updatedProject);
      await Backend.saveProject(updatedProject);
      setLoading(false);
  };

  if (!activeProject) {
      return (
          <div className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center">
                  <div>
                      <h1 className="text-2xl font-bold text-white">AI Project Writer</h1>
                      <p className="text-slate-400">Academic, Business & Technical Documentation.</p>
                  </div>
              </div>

              {/* Wizard */}
              <Card title="Start New Project" className="bg-gradient-to-br from-slate-800 to-slate-900 border-indigo-500/30">
                  <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-4">
                              <div>
                                  <label className="text-xs text-slate-400 block mb-1 font-bold uppercase tracking-wider">Project Type</label>
                                  <div className="flex gap-2">
                                      {['academic', 'business', 'technical'].map(t => (
                                          <button 
                                              key={t}
                                              onClick={() => setNewType(t as any)}
                                              className={`flex-1 py-2 rounded-lg border capitalize text-sm transition-all ${newType === t ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-500/20' : 'bg-slate-900 text-slate-400 border-slate-700'}`}
                                          >
                                              {t}
                                          </button>
                                      ))}
                                  </div>
                              </div>
                              
                              <div>
                                  <label className="text-xs text-slate-400 block mb-1 font-bold uppercase tracking-wider">Specific Project Topic</label>
                                  <input 
                                      value={newTopic} 
                                      onChange={e => setNewTopic(e.target.value)}
                                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white placeholder:text-slate-600 focus:border-indigo-500 focus:outline-none"
                                      placeholder="e.g. Impact of AI on Healthcare"
                                  />
                              </div>

                              <div>
                                  <label className="text-xs text-slate-400 block mb-1 font-bold uppercase tracking-wider">Field/Industry (Optional)</label>
                                  <div className="flex gap-2">
                                      <input 
                                          value={newField} 
                                          onChange={e => setNewField(e.target.value)}
                                          className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 text-white placeholder:text-slate-600"
                                          placeholder="e.g. Computer Science"
                                      />
                                      <Button onClick={handleGenerateTopics} disabled={loading || !newField} variant="secondary">
                                          {loading ? '...' : 'Suggest'}
                                      </Button>
                                  </div>
                              </div>
                          </div>

                          <div className="bg-slate-900/50 rounded-xl border border-slate-700 p-4 flex flex-col">
                               <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                                   <Layers className="w-4 h-4 text-indigo-400" /> Explicit Structure Control
                               </h4>
                               <p className="text-xs text-slate-400 mb-4">Upload a syllabus, guide, or document to strictly follow a specific project structure.</p>
                               
                               <div className="mt-auto">
                                    <input 
                                        type="file" 
                                        ref={fileInputRef} 
                                        className="hidden" 
                                        accept="image/*,.txt,.pdf" 
                                        onChange={handleFileUpload} 
                                    />
                                    <div className="flex gap-2">
                                        <Button onClick={() => fileInputRef.current?.click()} variant="outline" className="flex-1 border-dashed">
                                            <Paperclip className="w-4 h-4 mr-2" /> 
                                            {attachedFile ? 'Change File' : 'Attach Structure'}
                                        </Button>
                                    </div>
                                    {attachedFile && (
                                        <div className="mt-2 flex items-center gap-2 bg-indigo-900/30 border border-indigo-500/30 rounded-lg p-2">
                                            <FileIcon className="w-4 h-4 text-indigo-400" />
                                            <span className="text-xs text-indigo-200 truncate">{attachedFile.name}</span>
                                            <button onClick={() => setAttachedFile(null)} className="ml-auto text-indigo-400 hover:text-white"><Upload className="w-3 h-3 rotate-45" /></button>
                                        </div>
                                    )}
                               </div>
                          </div>
                      </div>
                      
                      {/* Main Action */}
                      <div className="pt-4 border-t border-slate-700">
                          <Button onClick={() => handleStartProject()} className="w-full py-4 text-base font-bold bg-gradient-to-r from-indigo-600 to-purple-600 shadow-xl shadow-indigo-500/20" disabled={loading || (!newTopic && !newField)}>
                              {loading ? <><Sparkles className="w-5 h-5 animate-spin mr-2" /> Analyzing & Structuring...</> : <><Zap className="w-5 h-5 mr-2" /> Initialize Project</>}
                          </Button>
                      </div>

                      {suggestedTopics.length > 0 && (
                          <div className="mt-4 pt-4 border-t border-slate-700 animate-fade-in">
                              <h4 className="text-sm font-bold text-white mb-2">Or Select a Suggested Topic:</h4>
                              <div className="space-y-2">
                                  {suggestedTopics.map(t => (
                                      <div key={t} onClick={() => handleStartProject(t)} className="p-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer flex justify-between items-center group transition-colors">
                                          <span className="text-slate-200 text-sm">{t}</span>
                                          <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-white" />
                                      </div>
                                  ))}
                              </div>
                          </div>
                      )}
                  </div>
              </Card>

              {/* Project List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {projects.map(p => (
                      <Card key={p.id} className="cursor-pointer hover:border-indigo-500 group" onClick={() => { setActiveProject(p); setCurrentChapterIndex(0); }}>
                          <div className="flex justify-between items-start mb-2">
                              <Badge color={p.type === 'academic' ? 'blue' : p.type === 'business' ? 'green' : 'yellow'}>{p.type}</Badge>
                              <span className="text-xs text-slate-500">{new Date(p.createdAt).toLocaleDateString()}</span>
                          </div>
                          <h3 className="font-bold text-white mb-1">{p.title}</h3>
                          <p className="text-sm text-slate-400">{p.field}</p>
                          <div className="mt-4 flex gap-2">
                              {p.chapters.map((_, i) => (
                                  <div key={i} className={`h-1 flex-1 rounded-full ${p.chapters[i].content ? 'bg-emerald-500' : 'bg-slate-700'}`} />
                              ))}
                          </div>
                      </Card>
                  ))}
              </div>
          </div>
      );
  }

  return (
      <div className="h-[calc(100vh-2rem)] flex flex-col animate-fade-in">
           <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-4">
                  <Button variant="outline" onClick={() => setActiveProject(null)}>Back</Button>
                  <div>
                      <h2 className="text-xl font-bold text-white truncate max-w-md">{activeProject.title}</h2>
                      <p className="text-xs text-slate-400 capitalize">{activeProject.type} Project</p>
                  </div>
              </div>
              <div className="flex items-center gap-2">
                    <div className="p-2 bg-slate-900 rounded-lg border border-slate-700 flex items-center gap-2 mr-2">
                        <div className="text-xs font-medium text-slate-300 flex items-center gap-1">
                            {mode === 'advanced' ? <Zap className="w-3 h-3 text-yellow-400" /> : <Sparkles className="w-3 h-3 text-slate-400" />}
                            {mode === 'advanced' ? 'Advanced' : 'Standard'}
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" checked={mode === 'advanced'} onChange={() => setMode(mode === 'standard' ? 'advanced' : 'standard')} />
                            <div className="w-7 h-4 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-indigo-600"></div>
                        </label>
                    </div>
                  <Button variant="secondary"><Download className="w-4 h-4 mr-2" /> Export PDF</Button>
              </div>
          </div>

          <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-6 overflow-hidden">
              {/* Sidebar Chapters */}
              <div className="lg:col-span-1 bg-slate-800/50 border border-slate-700 rounded-2xl p-4 overflow-y-auto">
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Structure</h3>
                  <div className="space-y-2">
                      {activeProject.chapters.map((chap, idx) => (
                          <button 
                              key={idx}
                              onClick={() => setCurrentChapterIndex(idx)}
                              className={`w-full text-left p-3 rounded-xl text-sm transition-colors flex items-center gap-2 ${currentChapterIndex === idx ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
                          >
                              {chap.content ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <div className="w-4 h-4 rounded-full border border-slate-500 shrink-0" />}
                              <span className="truncate">{chap.title}</span>
                          </button>
                      ))}
                  </div>
              </div>

              {/* Editor */}
              <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col">
                  <div className="p-4 border-b border-slate-800 flex justify-between items-center">
                      <h3 className="font-bold text-white">{activeProject.chapters[currentChapterIndex].title}</h3>
                      <Button size="sm" onClick={handleWriteChapter} disabled={loading}>
                          {loading ? 'Writing...' : 'Auto-Write Chapter'} <Wand2 className="w-3 h-3 ml-2" />
                      </Button>
                  </div>
                  <div className="flex-1 p-6 overflow-y-auto">
                      {activeProject.chapters[currentChapterIndex].content ? (
                          <textarea 
                              value={activeProject.chapters[currentChapterIndex].content}
                              onChange={(e) => {
                                  const newChapters = [...activeProject.chapters];
                                  newChapters[currentChapterIndex].content = e.target.value;
                                  setActiveProject({...activeProject, chapters: newChapters});
                              }}
                              className="w-full h-full bg-transparent text-slate-300 resize-none focus:outline-none font-serif leading-loose text-lg"
                          />
                      ) : (
                          <div className="h-full flex flex-col items-center justify-center text-slate-600">
                              <FileText className="w-16 h-16 opacity-20 mb-4" />
                              <p>Chapter is empty.</p>
                              <p className="text-sm">Click 'Auto-Write' to generate content based on your project topic.</p>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      </div>
  );
}
