
import React, { useState } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { Terminal, Sparkles, Copy, Share2, Zap, CheckCircle2, Layers, Globe, Briefcase, PenTool, Code, User, Settings, Rocket } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { generatePromptTemplate } from '../services/geminiService';
import { Backend } from '../services/backend';

const CATEGORIES = [
    "Writing", "Business", "Social Media", "Content Creation", "Coding", "Research", "Lyrics", "Email", "Editing", "Idea Gen"
];

const TONES = ["Formal", "Funny", "Friendly", "Dramatic", "Persuasive", "Empathetic", "Assertive", "Witty"];
const FORMATS = ["List", "Paragraph", "Script", "Table", "Bullet Points", "Code Block", "Email Format", "Essay"];

export default function PromptGenerator() {
  const { user } = useAuth();
  const [mode, setMode] = useState<'standard' | 'advanced'>('standard');
  const [goal, setGoal] = useState('');
  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  // Standard Mode State
  const [category, setCategory] = useState('Writing');

  // Advanced Mode State
  const [role, setRole] = useState('');
  const [tone, setTone] = useState('Professional');
  const [format, setFormat] = useState('Paragraph');
  const [constraints, setConstraints] = useState('');

  const handleGenerate = async () => {
      if (!goal) return;
      setIsGenerating(true);
      const prompt = await generatePromptTemplate(
          goal, 
          mode, 
          mode === 'standard' ? { category } : { role, tone, format, constraints }
      );
      setGeneratedPrompt(prompt);
      if(user) {
          Backend.logEvent(user.id, user.name, 'PromptGen', `Generated ${mode} prompt`);
      }
      setIsGenerating(false);
  };

  return (
    <div className="max-w-4xl mx-auto animate-fade-in space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-white mb-2 flex items-center justify-center gap-3">
                <Terminal className="w-8 h-8 text-emerald-500" /> 
                Prompt Engine
            </h1>
            <p className="text-slate-400 max-w-lg mx-auto">Create high-quality, professional prompts for any AI model instantly.</p>
        </div>

        {/* Mode Switcher */}
        <div className="flex justify-center mb-6">
            <div className="bg-slate-800 p-1 rounded-xl flex border border-slate-700">
                <button 
                    onClick={() => setMode('standard')}
                    className={`px-6 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${mode === 'standard' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                    <Sparkles className="w-4 h-4" /> Standard
                </button>
                <button 
                    onClick={() => setMode('advanced')}
                    className={`px-6 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${mode === 'advanced' ? 'bg-purple-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                    <Zap className="w-4 h-4" /> Advanced
                </button>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Input Panel */}
            <Card className={`border-t-4 ${mode === 'standard' ? 'border-t-emerald-500' : 'border-t-purple-500'}`}>
                <h2 className="text-xl font-bold text-white mb-4">
                    {mode === 'standard' ? 'Beginner Builder' : 'Pro Engineer'}
                </h2>
                
                {mode === 'standard' ? (
                    <div className="space-y-4">
                        <div>
                            <label className="text-sm text-slate-400 block mb-2">Category</label>
                            <div className="flex flex-wrap gap-2">
                                {CATEGORIES.map(c => (
                                    <button 
                                        key={c}
                                        onClick={() => setCategory(c)}
                                        className={`px-3 py-1.5 rounded-lg text-xs border transition-all ${category === c ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'}`}
                                    >
                                        {c}
                                    </button>
                                ))}
                            </div>
                        </div>
                        <div>
                            <label className="text-sm text-slate-400 block mb-2">What is your goal?</label>
                            <textarea 
                                value={goal}
                                onChange={e => setGoal(e.target.value)}
                                className="w-full h-32 bg-slate-900 border border-slate-700 rounded-xl p-4 text-white placeholder:text-slate-600 focus:border-emerald-500 outline-none resize-none"
                                placeholder="e.g. I want to write a YouTube script about motivation..."
                            />
                        </div>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div>
                            <label className="text-sm text-slate-400 block mb-2">Goal / Task</label>
                            <textarea 
                                value={goal}
                                onChange={e => setGoal(e.target.value)}
                                className="w-full h-24 bg-slate-900 border border-slate-700 rounded-xl p-4 text-white placeholder:text-slate-600 focus:border-purple-500 outline-none resize-none"
                                placeholder="e.g. Create a 5,000 word ebook on finance..."
                            />
                        </div>
                        <div>
                            <label className="text-sm text-slate-400 block mb-2">Expert Role</label>
                            <input 
                                value={role}
                                onChange={e => setRole(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:border-purple-500 outline-none"
                                placeholder="e.g. Senior Financial Advisor"
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-sm text-slate-400 block mb-2">Tone</label>
                                <select value={tone} onChange={e => setTone(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:border-purple-500 outline-none">
                                    {TONES.map(t => <option key={t}>{t}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-sm text-slate-400 block mb-2">Format</label>
                                <select value={format} onChange={e => setFormat(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:border-purple-500 outline-none">
                                    {FORMATS.map(f => <option key={f}>{f}</option>)}
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="text-sm text-slate-400 block mb-2">Constraints (Optional)</label>
                            <input 
                                value={constraints}
                                onChange={e => setConstraints(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:border-purple-500 outline-none"
                                placeholder="e.g. No jargon, under 200 words"
                            />
                        </div>
                    </div>
                )}

                <Button 
                    onClick={handleGenerate} 
                    disabled={isGenerating || !goal} 
                    className={`w-full mt-6 py-4 text-lg ${mode === 'standard' ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-purple-600 hover:bg-purple-500'}`}
                >
                    {isGenerating ? 'Engineering...' : 'Generate Prompt'}
                </Button>
            </Card>

            {/* Output Panel */}
            <Card className="bg-slate-800 flex flex-col relative">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-white">Optimized Prompt</h3>
                    {generatedPrompt && (
                        <button 
                            onClick={() => navigator.clipboard.writeText(generatedPrompt)}
                            className="flex items-center gap-1 text-xs bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded-lg transition-colors"
                        >
                            <Copy className="w-3 h-3" /> Copy
                        </button>
                    )}
                </div>
                
                <div className="flex-1 bg-slate-900 rounded-xl p-6 border border-slate-700 font-mono text-sm text-slate-300 leading-relaxed overflow-y-auto">
                    {generatedPrompt ? (
                        generatedPrompt
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-600 opacity-50">
                            <Terminal className="w-12 h-12 mb-4" />
                            <p>Your prompt will appear here.</p>
                        </div>
                    )}
                </div>
            </Card>
        </div>

        {/* Feature Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
            <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 flex items-center gap-3">
                <div className="p-2 bg-indigo-500/20 rounded-lg text-indigo-400"><Layers className="w-5 h-5" /></div>
                <div>
                    <h4 className="font-bold text-white text-sm">Structured Output</h4>
                    <p className="text-xs text-slate-400">Clean, usable formats.</p>
                </div>
            </div>
            <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 flex items-center gap-3">
                <div className="p-2 bg-pink-500/20 rounded-lg text-pink-400"><User className="w-5 h-5" /></div>
                <div>
                    <h4 className="font-bold text-white text-sm">Expert Roles</h4>
                    <p className="text-xs text-slate-400">Act as a professional.</p>
                </div>
            </div>
            <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400"><Rocket className="w-5 h-5" /></div>
                <div>
                    <h4 className="font-bold text-white text-sm">Ready to Scale</h4>
                    <p className="text-xs text-slate-400">Copy & Paste workflow.</p>
                </div>
            </div>
        </div>
    </div>
  );
}
