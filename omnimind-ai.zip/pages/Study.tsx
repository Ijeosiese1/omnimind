
import React, { useState, useEffect, useRef } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { 
    LayoutDashboard, PenTool, Layers, HelpCircle, 
    BookOpen, Search, RotateCw, Mic, Share2, Download,
    ChevronRight, Play, Timer, Pause, RotateCcw,
    GraduationCap, BrainCircuit, Trophy, Flame,
    ArrowRight, CheckCircle2, Sparkles, Briefcase,
    X, MoreVertical, Plus, Paperclip, Trash2
} from 'lucide-react';
import { 
    solveHomework, 
    generateStudyNotes, 
    generateFlashcards, 
    generateQuiz,
    generatePastQuestions
} from '../services/geminiService';
import { Backend } from '../services/backend';
import { Deck, Quiz, PastQuestion } from '../types';
import { useAuth } from '../context/AuthContext';

type Tab = 'dashboard' | 'tutor' | 'library' | 'flashcards' | 'quiz';
type StudyLevel = 'High School' | 'Undergraduate' | 'Graduate' | 'Professional';

// --- SUB-COMPONENTS ---

const FocusTimer = () => {
    const [timeLeft, setTimeLeft] = useState(25 * 60);
    const [isActive, setIsActive] = useState(false);
    const [mode, setMode] = useState<'focus' | 'break'>('focus');

    useEffect(() => {
        let interval: any;
        if (isActive && timeLeft > 0) {
            interval = setInterval(() => setTimeLeft(t => t - 1), 1000);
        } else if (timeLeft === 0) {
            setIsActive(false);
            // Play sound or notification here
        }
        return () => clearInterval(interval);
    }, [isActive, timeLeft]);

    const toggleTimer = () => setIsActive(!isActive);
    const resetTimer = () => {
        setIsActive(false);
        setTimeLeft(mode === 'focus' ? 25 * 60 : 5 * 60);
    };
    const switchMode = () => {
        const newMode = mode === 'focus' ? 'break' : 'focus';
        setMode(newMode);
        setIsActive(false);
        setTimeLeft(newMode === 'focus' ? 25 * 60 : 5 * 60);
    };

    const formatTime = (seconds: number) => {
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    };

    return (
        <Card className="bg-gradient-to-br from-indigo-900/50 to-slate-900 border-indigo-500/30">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-white flex items-center gap-2">
                    <Timer className="w-5 h-5 text-indigo-400" /> Focus Zone
                </h3>
                <Badge color={mode === 'focus' ? 'blue' : 'green'}>{mode.toUpperCase()}</Badge>
            </div>
            <div className="text-center py-4">
                <div className="text-5xl font-mono font-bold text-white tracking-wider mb-4 tabular-nums">
                    {formatTime(timeLeft)}
                </div>
                <div className="flex justify-center gap-3">
                    <button 
                        onClick={toggleTimer}
                        className={`p-3 rounded-full transition-all ${isActive ? 'bg-slate-700 text-slate-300' : 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30 hover:scale-105'}`}
                    >
                        {isActive ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
                    </button>
                    <button onClick={resetTimer} className="p-3 rounded-full bg-slate-800 text-slate-400 hover:bg-slate-700 border border-slate-700">
                        <RotateCcw className="w-5 h-5" />
                    </button>
                </div>
                <button onClick={switchMode} className="text-xs text-slate-500 mt-4 hover:text-indigo-400 underline">
                    Switch to {mode === 'focus' ? 'Break' : 'Focus'}
                </button>
            </div>
        </Card>
    );
};

export default function StudyHub() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [studyLevel, setStudyLevel] = useState<StudyLevel>('Undergraduate');

  // --- STATES ---
  
  // Tutor
  const [question, setQuestion] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [solution, setSolution] = useState<string | null>(null);
  const [isSolving, setIsSolving] = useState(false);
  const [tutorField, setTutorField] = useState('General');

  // Notes & Library
  const [noteContent, setNoteContent] = useState('');
  const [noteAttachment, setNoteAttachment] = useState<string | null>(null);
  const [noteAttachmentName, setNoteAttachmentName] = useState('');
  const [noteType, setNoteType] = useState<'summary' | 'bullet' | 'full'>('full');
  const [generatedNotes, setGeneratedNotes] = useState('');
  const [isGeneratingNotes, setIsGeneratingNotes] = useState(false);
  const [pastQuestions, setPastQuestions] = useState<PastQuestion[]>([]);
  const [libraryFilter, setLibraryFilter] = useState<'notes' | 'pq'>('notes');
  const noteFileInputRef = useRef<HTMLInputElement>(null);
  
  // Past Question Filters
  const [pqSubject, setPqSubject] = useState('Mathematics');
  const [pqExam, setPqExam] = useState('WAEC');
  const [pqYear, setPqYear] = useState('2023');
  const [isFetchingPQ, setIsFetchingPQ] = useState(false);

  // Flashcards
  const [flashcardTopic, setFlashcardTopic] = useState('');
  const [activeDeck, setActiveDeck] = useState<Deck | null>(null);
  const [userDecks, setUserDecks] = useState<Deck[]>([]);
  const [isGeneratingCards, setIsGeneratingCards] = useState(false);
  const [flippedCardId, setFlippedCardId] = useState<string | null>(null);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [studyMode, setStudyMode] = useState(false);

  // Quiz
  const [quizTopic, setQuizTopic] = useState('');
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [quizScore, setQuizScore] = useState<number | null>(null);
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false);

  // --- EFFECTS ---
  useEffect(() => {
      if (activeTab === 'library' && pastQuestions.length === 0) {
          // Initial load from backend or mock, can be replaced by auto-generate later
          Backend.getPastQuestions('All', 'All').then(setPastQuestions);
      }
      if (user) {
          Backend.getUserDecks(user.id).then(setUserDecks);
      }
  }, [activeTab, user]);

  // --- HANDLERS ---

  const handleSolve = async () => {
    if (!question && !imageFile) return;
    setIsSolving(true);
    setSolution(null);

    let base64Image = null;
    if (imageFile) {
        const reader = new FileReader();
        reader.readAsDataURL(imageFile);
        await new Promise((resolve) => { reader.onload = resolve; });
        base64Image = (reader.result as string).split(',')[1];
    }

    // Append context to prompt
    const contextPrompt = `[Level: ${studyLevel}, Field: ${tutorField}] ${question}`;
    const result = await solveHomework(base64Image, contextPrompt, true);
    setSolution(result);
    setIsSolving(false);
  };

  const handleNoteFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const result = reader.result as string;
              setNoteAttachment(result.split(',')[1]);
              setNoteAttachmentName(file.name);
          };
          reader.readAsDataURL(file);
      }
  };

  const handleGenerateNotes = async () => {
      if (!noteContent && !noteAttachment) return;
      setIsGeneratingNotes(true);
      const result = await generateStudyNotes(noteContent, noteType, noteAttachment || undefined);
      setGeneratedNotes(result);
      setIsGeneratingNotes(false);
  };

  const handleFetchPastQuestions = async () => {
      setIsFetchingPQ(true);
      // Call Gemini service to generate questions
      const questions = await generatePastQuestions(pqSubject, pqExam, pqYear);
      setPastQuestions(questions);
      setIsFetchingPQ(false);
  };

  const handleCreateDeck = async () => {
      if (!flashcardTopic || !user) return;
      setIsGeneratingCards(true);
      const cards = await generateFlashcards(flashcardTopic, 8); // Generate more cards for advanced users
      const newDeck: Deck = {
          id: Date.now().toString(),
          userId: user.id,
          title: flashcardTopic,
          cards,
          createdAt: Date.now()
      };
      await Backend.saveDeck(newDeck);
      setUserDecks(prev => [...prev, newDeck]);
      setIsGeneratingCards(false);
      setFlashcardTopic('');
  };

  const startStudying = (deck: Deck) => {
      setActiveDeck(deck);
      setCurrentCardIndex(0);
      setStudyMode(true);
      setFlippedCardId(null);
  };

  const handleCreateQuiz = async () => {
      if (!quizTopic) return;
      setIsGeneratingQuiz(true);
      const quiz = await generateQuiz(quizTopic);
      setActiveQuiz(quiz);
      setQuizAnswers(new Array(quiz?.questions.length || 0).fill(-1));
      setQuizScore(null);
      setIsGeneratingQuiz(false);
  };

  // --- SUB-COMPONENTS ---

  const NavButton = ({ id, label, icon: Icon }: any) => (
      <button
        onClick={() => setActiveTab(id)}
        className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-medium transition-all duration-200 group ${
            activeTab === id 
            ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/25 translate-x-1' 
            : 'text-slate-400 hover:bg-slate-800 hover:text-white'
        }`}
      >
          <Icon className={`w-5 h-5 ${activeTab === id ? 'text-white' : 'text-slate-500 group-hover:text-indigo-400'}`} />
          <span className="flex-1 text-left">{label}</span>
          {activeTab === id && <ChevronRight className="w-4 h-4 opacity-50" />}
      </button>
  );

  const currentCard = activeDeck?.cards[currentCardIndex];

  return (
    <div className="flex flex-col md:flex-row gap-8 animate-fade-in min-h-[calc(100vh-6rem)]">
        
        {/* SIDEBAR NAVIGATION */}
        <div className="hidden md:flex flex-col gap-6 w-72 shrink-0">
            <div className="px-2">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                    <GraduationCap className="w-8 h-8 text-indigo-500" />
                    Study Hub
                </h2>
                <p className="text-xs text-slate-500 mt-1 ml-10">Advanced Learning OS</p>
            </div>

            <div className="space-y-2">
                <NavButton id="dashboard" label="Overview" icon={LayoutDashboard} />
                <NavButton id="tutor" label="AI Tutor & Solver" icon={BrainCircuit} />
                <NavButton id="library" label="Resource Library" icon={BookOpen} />
                <NavButton id="flashcards" label="Flashcards" icon={Layers} />
                <NavButton id="quiz" label="Quiz Mode" icon={HelpCircle} />
            </div>

            <FocusTimer />
        </div>

        {/* MAIN CONTENT AREA */}
        <div className="flex-1 min-w-0 space-y-6">
            
            {/* Mobile Nav */}
            <div className="md:hidden flex overflow-x-auto pb-4 gap-2 scrollbar-hide">
                {[
                    { id: 'dashboard', icon: LayoutDashboard },
                    { id: 'tutor', icon: BrainCircuit },
                    { id: 'library', icon: BookOpen },
                    { id: 'flashcards', icon: Layers },
                    { id: 'quiz', icon: HelpCircle },
                ].map((item) => (
                     <button
                        key={item.id}
                        onClick={() => setActiveTab(item.id as Tab)}
                        className={`p-3 rounded-xl ${activeTab === item.id ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'}`}
                    >
                        <item.icon className="w-5 h-5" />
                    </button>
                ))}
            </div>

            {/* --- DASHBOARD TAB --- */}
            {activeTab === 'dashboard' && (
                <div className="space-y-6">
                    <header className="flex justify-between items-end">
                        <div>
                            <h1 className="text-3xl font-bold text-white">Good {new Date().getHours() < 12 ? 'Morning' : new Date().getHours() < 18 ? 'Afternoon' : 'Evening'}, {user?.name.split(' ')[0]}</h1>
                            <p className="text-slate-400 mt-1">Ready to achieve your goals today?</p>
                        </div>
                        <div className="text-right hidden sm:block">
                            <div className="text-sm text-slate-500 uppercase font-bold tracking-wider">Current Level</div>
                            <select 
                                value={studyLevel}
                                onChange={(e) => setStudyLevel(e.target.value as any)}
                                className="bg-transparent border-none text-indigo-400 font-bold text-lg text-right focus:outline-none cursor-pointer"
                            >
                                {['High School', 'Undergraduate', 'Graduate', 'Professional'].map(l => <option key={l} value={l}>{l}</option>)}
                            </select>
                        </div>
                    </header>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                         <Card className="relative overflow-hidden group border-0 ring-1 ring-white/10 bg-gradient-to-b from-slate-800 to-slate-900">
                             <div className="absolute top-0 right-0 p-8 bg-indigo-500/10 rounded-full blur-2xl -mr-4 -mt-4" />
                             <div className="relative z-10">
                                 <div className="flex items-center gap-3 mb-4">
                                     <div className="p-2.5 bg-indigo-500/20 rounded-lg text-indigo-400"><Flame className="w-5 h-5" /></div>
                                     <h3 className="font-bold text-slate-200">Study Streak</h3>
                                 </div>
                                 <div className="text-4xl font-bold text-white mb-1">12 <span className="text-lg font-medium text-slate-500">days</span></div>
                                 <div className="flex gap-1 mt-3">
                                     {[1,1,1,1,0,0,0].map((d,i) => (
                                         <div key={i} className={`h-1.5 flex-1 rounded-full ${d ? 'bg-indigo-500' : 'bg-slate-700'}`} />
                                     ))}
                                 </div>
                             </div>
                         </Card>

                         <Card className="relative overflow-hidden group border-0 ring-1 ring-white/10 bg-gradient-to-b from-slate-800 to-slate-900">
                             <div className="absolute top-0 right-0 p-8 bg-emerald-500/10 rounded-full blur-2xl -mr-4 -mt-4" />
                             <div className="relative z-10">
                                 <div className="flex items-center gap-3 mb-4">
                                     <div className="p-2.5 bg-emerald-500/20 rounded-lg text-emerald-400"><Layers className="w-5 h-5" /></div>
                                     <h3 className="font-bold text-slate-200">Mastery</h3>
                                 </div>
                                 <div className="text-4xl font-bold text-white mb-1">85<span className="text-lg font-medium text-slate-500">%</span></div>
                                 <p className="text-xs text-slate-400 mt-2">Based on recent quiz scores</p>
                             </div>
                         </Card>

                         <div className="md:hidden">
                             <FocusTimer />
                         </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <div className="flex justify-between items-center">
                                <h3 className="text-lg font-bold text-white">Recent Decks</h3>
                                <button onClick={() => setActiveTab('flashcards')} className="text-sm text-indigo-400 hover:text-indigo-300">View All</button>
                            </div>
                            {userDecks.slice(0, 3).map(deck => (
                                <div key={deck.id} onClick={() => startStudying(deck)} className="flex items-center justify-between p-4 bg-slate-800 border border-slate-700 rounded-xl cursor-pointer hover:border-indigo-500 transition-all group">
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400 group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                                            <Layers className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-white">{deck.title}</h4>
                                            <p className="text-xs text-slate-400">{deck.cards.length} cards</p>
                                        </div>
                                    </div>
                                    <ChevronRight className="w-5 h-5 text-slate-600 group-hover:text-white" />
                                </div>
                            ))}
                            {userDecks.length === 0 && (
                                <div className="p-6 border border-dashed border-slate-700 rounded-xl text-center text-slate-500">
                                    No decks created yet.
                                </div>
                            )}
                        </div>

                        <Card title="Recommended Actions">
                            <div className="grid grid-cols-2 gap-3">
                                <button onClick={() => setActiveTab('tutor')} className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:bg-slate-800 hover:border-purple-500 transition-all text-left">
                                    <BrainCircuit className="w-6 h-6 text-purple-400 mb-2" />
                                    <div className="font-bold text-slate-200 text-sm">Ask AI Tutor</div>
                                    <div className="text-[10px] text-slate-500">Solve complex problems</div>
                                </button>
                                <button onClick={() => setActiveTab('quiz')} className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 hover:bg-slate-800 hover:border-emerald-500 transition-all text-left">
                                    <HelpCircle className="w-6 h-6 text-emerald-400 mb-2" />
                                    <div className="font-bold text-slate-200 text-sm">Take a Quiz</div>
                                    <div className="text-[10px] text-slate-500">Test your knowledge</div>
                                </button>
                            </div>
                        </Card>
                    </div>
                </div>
            )}

            {/* --- TUTOR TAB --- */}
            {activeTab === 'tutor' && (
                <div className="space-y-6 animate-fade-in">
                     <div className="flex justify-between items-start">
                         <div>
                             <h1 className="text-2xl font-bold text-white">AI Tutor & Solver</h1>
                             <p className="text-slate-400">Get step-by-step explanations for any problem.</p>
                         </div>
                         <div className="flex gap-2">
                             <select 
                                value={tutorField} 
                                onChange={(e) => setTutorField(e.target.value)} 
                                className="bg-slate-800 border border-slate-700 text-slate-200 text-sm rounded-lg px-3 py-2 focus:outline-none"
                             >
                                 <option>General</option>
                                 <option>Mathematics</option>
                                 <option>Computer Science</option>
                                 <option>Physics</option>
                                 <option>Chemistry</option>
                                 <option>Business/Law</option>
                                 <option>Medicine</option>
                             </select>
                         </div>
                     </div>

                     <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                         <Card className="flex flex-col">
                            <div className="mb-4">
                                <div className="flex items-center gap-2 mb-2">
                                    <Badge color="blue">{studyLevel}</Badge>
                                    <Badge color="green">{tutorField}</Badge>
                                </div>
                                <textarea 
                                    className="w-full h-40 bg-slate-900 border border-slate-700 rounded-xl p-4 text-slate-200 placeholder:text-slate-600 focus:border-indigo-500 focus:outline-none resize-none text-lg leading-relaxed"
                                    placeholder={`Enter your ${tutorField.toLowerCase()} question here...`}
                                    value={question}
                                    onChange={(e) => setQuestion(e.target.value)}
                                />
                            </div>
                            <div className="flex items-center gap-4 mt-auto">
                                <label className="cursor-pointer flex-1">
                                    <input type="file" accept="image/*" className="hidden" onChange={e => e.target.files && setImageFile(e.target.files[0])} />
                                    <div className={`h-12 rounded-xl border border-dashed flex items-center justify-center gap-2 transition-colors ${imageFile ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400' : 'border-slate-600 bg-slate-800/50 text-slate-400 hover:border-indigo-500 hover:text-indigo-400'}`}>
                                        <PenTool className="w-4 h-4" />
                                        <span className="text-sm font-medium">{imageFile ? "Image Attached" : "Upload Problem Image"}</span>
                                    </div>
                                </label>
                                <Button onClick={handleSolve} disabled={isSolving} className="flex-1 h-12 text-base">
                                    {isSolving ? <Sparkles className="w-4 h-4 animate-spin" /> : 'Solve & Explain'}
                                </Button>
                            </div>
                         </Card>
                         
                         <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 overflow-y-auto max-h-[600px] shadow-inner">
                             {solution ? (
                                 <div className="prose prose-invert prose-lg max-w-none">
                                     <h3 className="text-indigo-400 font-bold mb-4 flex items-center gap-2">
                                         <CheckCircle2 className="w-6 h-6" /> Solution
                                     </h3>
                                     <div className="whitespace-pre-wrap leading-loose text-slate-300">{solution}</div>
                                 </div>
                             ) : (
                                 <div className="h-full flex flex-col items-center justify-center text-slate-600 opacity-50">
                                     <BrainCircuit className="w-16 h-16 mb-4" />
                                     <p className="text-lg">AI Solution Space</p>
                                     <p className="text-sm">Ask a question to see the magic happen.</p>
                                 </div>
                             )}
                         </div>
                     </div>
                </div>
            )}

            {/* --- FLASHCARDS TAB --- */}
            {activeTab === 'flashcards' && (
                <div className="space-y-6 animate-fade-in relative">
                    {studyMode && activeDeck ? (
                        // FULL SCREEN STUDY MODE
                        <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-xl flex flex-col items-center justify-center p-6">
                            <button 
                                onClick={() => setStudyMode(false)} 
                                className="absolute top-6 right-6 p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white"
                            >
                                <X className="w-6 h-6" />
                            </button>

                            <div className="w-full max-w-3xl space-y-8">
                                <div className="flex justify-between items-center text-white">
                                    <div>
                                        <h2 className="text-2xl font-bold">{activeDeck.title}</h2>
                                        <p className="text-slate-400">Card {currentCardIndex + 1} of {activeDeck.cards.length}</p>
                                    </div>
                                    <Badge color="blue">Study Mode</Badge>
                                </div>

                                {/* Progress Bar */}
                                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                    <div 
                                        className="h-full bg-indigo-500 transition-all duration-500 ease-out"
                                        style={{ width: `${((currentCardIndex + 1) / activeDeck.cards.length) * 100}%` }}
                                    />
                                </div>

                                {/* THE FLIPPABLE CARD */}
                                <div 
                                    className="relative h-[400px] w-full perspective-1000 cursor-pointer group" 
                                    onClick={() => setFlippedCardId(flippedCardId ? null : 'flip')}
                                >
                                    <div className={`relative w-full h-full transition-transform duration-500 transform-style-3d ${flippedCardId ? 'rotate-y-180' : ''}`}>
                                        {/* Front */}
                                        <div className="absolute inset-0 backface-hidden bg-slate-900 border border-slate-700 rounded-3xl p-10 flex flex-col items-center justify-center text-center shadow-2xl group-hover:border-indigo-500/50 transition-colors">
                                            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-6">Question</span>
                                            <p className="text-3xl font-medium text-white leading-relaxed">{currentCard.front}</p>
                                            <div className="absolute bottom-6 text-xs text-slate-500 flex items-center gap-2">
                                                <RotateCw className="w-3 h-3" /> Click to flip
                                            </div>
                                        </div>

                                        {/* Back */}
                                        <div className="absolute inset-0 backface-hidden rotate-y-180 bg-indigo-900/20 border border-indigo-500/50 rounded-3xl p-10 flex flex-col items-center justify-center text-center shadow-2xl backdrop-blur-sm">
                                            <span className="text-xs font-bold text-indigo-300 uppercase tracking-widest mb-6">Answer</span>
                                            <p className="text-2xl font-medium text-white leading-relaxed">{currentCard.back}</p>
                                        </div>
                                    </div>
                                </div>

                                {/* Controls */}
                                <div className="flex justify-center gap-6">
                                    <Button 
                                        variant="secondary" 
                                        onClick={(e) => { e.stopPropagation(); setCurrentCardIndex(Math.max(0, currentCardIndex - 1)); setFlippedCardId(null); }}
                                        disabled={currentCardIndex === 0}
                                        className="w-32"
                                    >
                                        Previous
                                    </Button>
                                    <Button 
                                        onClick={(e) => { e.stopPropagation(); setCurrentCardIndex(Math.min(activeDeck.cards.length - 1, currentCardIndex + 1)); setFlippedCardId(null); }}
                                        disabled={currentCardIndex === activeDeck.cards.length - 1}
                                        className="w-32 bg-white text-slate-900 hover:bg-slate-200"
                                    >
                                        Next
                                    </Button>
                                </div>
                            </div>
                        </div>
                    ) : (
                        // DECK LIST VIEW
                        <>
                            <div className="flex justify-between items-end">
                                <div>
                                    <h1 className="text-2xl font-bold text-white">Flashcards</h1>
                                    <p className="text-slate-400">Master any topic with spaced repetition.</p>
                                </div>
                                <Card className="p-1.5 flex bg-slate-800 border-slate-700">
                                    <input 
                                        className="bg-transparent border-none text-sm text-white px-3 focus:outline-none w-48"
                                        placeholder="New Deck Topic..."
                                        value={flashcardTopic}
                                        onChange={e => setFlashcardTopic(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && handleCreateDeck()}
                                    />
                                    <Button size="sm" onClick={handleCreateDeck} disabled={isGeneratingCards}>
                                        {isGeneratingCards ? <Sparkles className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                                    </Button>
                                </Card>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {userDecks.map((deck, idx) => (
                                    <div 
                                        key={deck.id} 
                                        onClick={() => startStudying(deck)}
                                        className="group relative h-48 bg-slate-800 rounded-2xl p-6 border border-slate-700 hover:border-indigo-500 cursor-pointer transition-all hover:-translate-y-1 hover:shadow-2xl hover:shadow-indigo-500/20 flex flex-col justify-between overflow-hidden"
                                    >
                                        {/* Stack Effect Visuals */}
                                        <div className="absolute top-0 right-0 -mt-3 -mr-3 w-full h-full bg-slate-700/20 rounded-2xl border border-slate-600/20 z-[-1] transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
                                        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-full h-full bg-slate-700/10 rounded-2xl border border-slate-600/10 z-[-2] transition-transform group-hover:translate-x-2 group-hover:-translate-y-2" />
                                        
                                        <div>
                                            <div className="flex justify-between items-start mb-4">
                                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-lg">
                                                    {deck.title.charAt(0).toUpperCase()}
                                                </div>
                                                <MoreVertical className="w-5 h-5 text-slate-600 hover:text-white" />
                                            </div>
                                            <h3 className="text-lg font-bold text-white line-clamp-1">{deck.title}</h3>
                                            <p className="text-sm text-slate-400">{deck.cards.length} Cards</p>
                                        </div>

                                        <div className="flex items-center text-indigo-400 text-sm font-bold uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                                            Start Studying <ArrowRight className="w-4 h-4 ml-2" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </>
                    )}
                </div>
            )}

             {/* --- LIBRARY & NOTES TAB --- */}
             {activeTab === 'library' && (
                <div className="space-y-6 animate-fade-in">
                    <div className="flex justify-between items-center">
                        <h1 className="text-2xl font-bold text-white">Resource Library</h1>
                        <div className="flex bg-slate-800 p-1 rounded-lg">
                            <button onClick={() => setLibraryFilter('notes')} className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${libraryFilter === 'notes' ? 'bg-slate-700 text-white shadow' : 'text-slate-400'}`}>Smart Notes</button>
                            <button onClick={() => setLibraryFilter('pq')} className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${libraryFilter === 'pq' ? 'bg-slate-700 text-white shadow' : 'text-slate-400'}`}>Past Questions</button>
                        </div>
                    </div>

                    {libraryFilter === 'notes' && (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <Card title="Generate New Notes">
                                <div className="mb-4 relative">
                                    <textarea 
                                        className="w-full h-48 bg-slate-900 border border-slate-700 rounded-xl p-4 text-slate-200 text-sm resize-none focus:border-indigo-500 focus:outline-none pb-10"
                                        placeholder="Paste lecture text, article content, or rough notes here..."
                                        value={noteContent}
                                        onChange={(e) => setNoteContent(e.target.value)}
                                    />
                                    {/* Attach Button inside Textarea area */}
                                    <div className="absolute bottom-3 left-3 flex items-center gap-2">
                                        <input 
                                            type="file" 
                                            ref={noteFileInputRef} 
                                            className="hidden" 
                                            accept="image/*,.txt" 
                                            onChange={handleNoteFileUpload} 
                                        />
                                        <button 
                                            onClick={() => noteFileInputRef.current?.click()}
                                            className="flex items-center gap-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-600 transition-colors"
                                        >
                                            <Paperclip className="w-3 h-3" /> Attach
                                        </button>
                                        {noteAttachment && (
                                            <div className="flex items-center gap-2 bg-indigo-900/30 text-indigo-300 px-2 py-1 rounded text-xs border border-indigo-500/30">
                                                <span className="truncate max-w-[100px]">{noteAttachmentName || 'Image'}</span>
                                                <button onClick={() => { setNoteAttachment(null); setNoteAttachmentName(''); }}><Trash2 className="w-3 h-3 hover:text-red-400" /></button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                                
                                <div className="flex gap-4">
                                    <div className="flex-1 flex bg-slate-900 rounded-lg p-1 border border-slate-700">
                                        {['summary', 'bullet', 'full'].map(t => (
                                            <button 
                                                key={t} 
                                                onClick={() => setNoteType(t as any)}
                                                className={`flex-1 capitalize text-xs py-1.5 rounded ${noteType === t ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
                                            >
                                                {t}
                                            </button>
                                        ))}
                                    </div>
                                    <Button onClick={handleGenerateNotes} disabled={isGeneratingNotes || (!noteContent && !noteAttachment)}>
                                        {isGeneratingNotes ? 'Processing...' : 'Generate'}
                                    </Button>
                                </div>
                            </Card>
                            <Card className="bg-slate-900 border-slate-800 overflow-hidden flex flex-col">
                                <div className="flex justify-between items-center mb-4 pb-4 border-b border-slate-800">
                                    <h3 className="font-bold text-white">Output</h3>
                                    <button onClick={() => navigator.clipboard.writeText(generatedNotes)} className="text-slate-400 hover:text-white"><Share2 className="w-4 h-4" /></button>
                                </div>
                                <div className="flex-1 overflow-y-auto max-h-[400px] prose prose-invert prose-sm max-w-none custom-scrollbar">
                                    {generatedNotes ? <div className="whitespace-pre-wrap">{generatedNotes}</div> : <div className="text-slate-600 text-center mt-10">Generated notes will appear here.</div>}
                                </div>
                            </Card>
                        </div>
                    )}

                    {libraryFilter === 'pq' && (
                        <div className="space-y-6">
                             {/* Filters & AI Fetch */}
                             <Card className="bg-slate-800/50 border-slate-700">
                                 <div className="flex flex-wrap gap-4 items-end">
                                     <div className="flex-1 min-w-[140px]">
                                         <label className="text-xs text-slate-400 block mb-1">Subject</label>
                                         <select value={pqSubject} onChange={e => setPqSubject(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white">
                                             {['Mathematics', 'English', 'Physics', 'Chemistry', 'Biology', 'Economics', 'Government', 'Literature', 'Computer Science'].map(s => <option key={s}>{s}</option>)}
                                         </select>
                                     </div>
                                     <div className="flex-1 min-w-[120px]">
                                         <label className="text-xs text-slate-400 block mb-1">Exam Body</label>
                                         <select value={pqExam} onChange={e => setPqExam(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white">
                                             {['WAEC', 'JAMB', 'NECO', 'SAT', 'GCSE', 'IGCSE'].map(e => <option key={e}>{e}</option>)}
                                         </select>
                                     </div>
                                     <div className="flex-1 min-w-[100px]">
                                         <label className="text-xs text-slate-400 block mb-1">Year</label>
                                         <select value={pqYear} onChange={e => setPqYear(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white">
                                             {[2024, 2023, 2022, 2021, 2020, 2019, 2018].map(y => <option key={y}>{y}</option>)}
                                         </select>
                                     </div>
                                     <Button onClick={handleFetchPastQuestions} disabled={isFetchingPQ} className="h-[38px] px-6">
                                         {isFetchingPQ ? <Sparkles className="w-4 h-4 animate-spin" /> : 'Load Questions from Net'}
                                     </Button>
                                 </div>
                             </Card>

                             <div className="space-y-4">
                                 {pastQuestions.length > 0 ? pastQuestions.map(pq => (
                                     <div key={pq.id} className="bg-slate-800 border border-slate-700 rounded-xl p-6 hover:border-slate-600 transition-colors">
                                         <div className="flex gap-2 mb-2">
                                             <Badge color="blue">{pq.examBody}</Badge>
                                             <Badge color="green">{pq.year}</Badge>
                                             <span className="text-slate-400 text-sm ml-auto font-mono">{pq.subject}</span>
                                         </div>
                                         <p className="text-white font-medium mb-4 text-lg">{pq.question}</p>
                                         <details className="group">
                                             <summary className="text-indigo-400 text-sm cursor-pointer font-bold flex items-center gap-2 select-none">
                                                 <Play className="w-3 h-3 group-open:rotate-90 transition-transform" /> Reveal Answer
                                             </summary>
                                             <div className="mt-3 p-4 bg-slate-900/80 rounded-lg border border-slate-700/50 animate-fade-in">
                                                 <p className="text-emerald-400 font-bold text-lg mb-2">{pq.solution}</p>
                                                 <p className="text-sm text-slate-400 italic">{pq.explanation}</p>
                                             </div>
                                         </details>
                                     </div>
                                 )) : (
                                     <div className="text-center text-slate-500 py-10 border border-dashed border-slate-700 rounded-xl">
                                         No questions loaded. Use the filters above to fetch past questions.
                                     </div>
                                 )}
                             </div>
                        </div>
                    )}
                </div>
            )}

            {/* --- QUIZ TAB --- */}
            {activeTab === 'quiz' && (
                <div className="space-y-6 animate-fade-in">
                    <h1 className="text-2xl font-bold text-white">Knowledge Check</h1>
                    {!activeQuiz ? (
                        <Card className="max-w-xl mx-auto text-center py-10">
                            <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-6" />
                            <h2 className="text-xl font-bold text-white mb-2">Ready to test yourself?</h2>
                            <p className="text-slate-400 mb-6">Generate a quick 5-question quiz on any topic to verify your mastery.</p>
                            <div className="flex gap-2">
                                <input 
                                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white focus:border-indigo-500 outline-none"
                                    placeholder="Enter Topic (e.g., Calculus, European History)"
                                    value={quizTopic}
                                    onChange={e => setQuizTopic(e.target.value)}
                                />
                                <Button onClick={handleCreateQuiz} disabled={isGeneratingQuiz}>Start</Button>
                            </div>
                        </Card>
                    ) : (
                        <Card>
                            <div className="flex justify-between items-center mb-6">
                                <h2 className="text-xl font-bold text-white">Quiz: {activeQuiz.topic}</h2>
                                {quizScore !== null && <Badge color="green">Score: {quizScore}/{activeQuiz.questions.length}</Badge>}
                            </div>
                            <div className="space-y-8">
                                {activeQuiz.questions.map((q, idx) => (
                                    <div key={q.id} className="space-y-3">
                                        <p className="text-lg font-medium text-white"><span className="text-slate-500 mr-2">{idx+1}.</span>{q.question}</p>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pl-6">
                                            {q.options.map((opt, oIdx) => {
                                                let btnClass = "bg-slate-900 border-slate-700 hover:bg-slate-800";
                                                if (quizScore !== null) {
                                                    if (oIdx === q.correctAnswer) btnClass = "bg-emerald-500/20 border-emerald-500 text-emerald-300";
                                                    else if (quizAnswers[idx] === oIdx) btnClass = "bg-red-500/20 border-red-500 text-red-300";
                                                    else btnClass = "opacity-50 border-slate-800";
                                                } else if (quizAnswers[idx] === oIdx) {
                                                    btnClass = "bg-indigo-600 text-white border-indigo-500";
                                                }

                                                return (
                                                    <button 
                                                        key={oIdx}
                                                        disabled={quizScore !== null}
                                                        onClick={() => {
                                                            const newAns = [...quizAnswers];
                                                            newAns[idx] = oIdx;
                                                            setQuizAnswers(newAns);
                                                        }}
                                                        className={`p-3 rounded-lg border text-left text-sm transition-all ${btnClass}`}
                                                    >
                                                        <span className="font-bold mr-2 text-xs opacity-50">{String.fromCharCode(65+oIdx)}</span>
                                                        {opt}
                                                    </button>
                                                );
                                            })}
                                        </div>
                                        {quizScore !== null && (
                                            <div className="pl-6 text-xs text-slate-400 italic">
                                                Explanation: {q.explanation}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                            {quizScore === null && (
                                <div className="mt-8 text-right">
                                    <Button onClick={() => {
                                        let score = 0;
                                        activeQuiz.questions.forEach((q, i) => { if (quizAnswers[i] === q.correctAnswer) score++; });
                                        setQuizScore(score);
                                    }} disabled={quizAnswers.includes(-1)}>
                                        Submit Quiz
                                    </Button>
                                </div>
                            )}
                            {quizScore !== null && (
                                <div className="mt-8 text-right">
                                    <Button variant="secondary" onClick={() => { setActiveQuiz(null); setQuizTopic(''); }}>Take Another</Button>
                                </div>
                            )}
                        </Card>
                    )}
                </div>
            )}

        </div>
    </div>
  );
}
