import React, { useEffect, useState } from 'react';
import { Card, Button, Badge } from '../components/ui/Widgets';
import { Calendar, Clock, MapPin, User, XCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Backend } from '../services/backend';
import { Appointment } from '../types';

export default function UserAppointments() {
  const { user } = useAuth();
  const [appts, setAppts] = useState<Appointment[]>([]);
  const [refresh, setRefresh] = useState(0);

  useEffect(() => {
    if (user) {
      Backend.getAppointmentsForUser(user.id).then(setAppts);
    }
  }, [user, refresh]);

  const handleCancel = async (id: string) => {
      if (confirm("Are you sure you want to cancel this appointment?")) {
          await Backend.updateAppointmentStatus(id, 'cancelled');
          setRefresh(prev => prev + 1);
      }
  };

  return (
    <div className="space-y-6">
        <div>
            <h1 className="text-2xl font-bold text-white">My Appointments</h1>
            <p className="text-slate-400">Manage your bookings and schedule.</p>
        </div>

        <div className="space-y-4">
            {appts.length > 0 ? appts.map(appt => (
                <Card key={appt.id} className="flex flex-col md:flex-row md:items-center gap-6 border-l-4 border-l-indigo-500">
                    <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-bold text-white">{appt.serviceName}</h3>
                            <Badge color={
                                appt.status === 'confirmed' ? 'green' : 
                                appt.status === 'pending' ? 'yellow' : 
                                appt.status === 'cancelled' ? 'red' : 'blue'
                            }>
                                {appt.status.toUpperCase()}
                            </Badge>
                        </div>
                        <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-sm text-slate-400">
                            <div className="flex items-center gap-1">
                                <User className="w-4 h-4" /> with {appt.professionalName}
                            </div>
                            <div className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" /> {appt.date}
                            </div>
                            <div className="flex items-center gap-1">
                                <Clock className="w-4 h-4" /> {appt.time}
                            </div>
                        </div>
                    </div>
                    
                    <div className="flex items-center gap-4 border-t border-slate-700 pt-4 md:pt-0 md:border-t-0 md:border-l md:pl-6">
                         <div className="text-right mr-4">
                             <span className="block text-xs text-slate-500">Price</span>
                             <span className="block text-xl font-bold text-white">${appt.price}</span>
                         </div>
                         {(appt.status === 'pending' || appt.status === 'confirmed') && (
                             <Button variant="outline" onClick={() => handleCancel(appt.id)} className="text-red-400 hover:text-red-300 hover:bg-red-900/20 border-red-900/50">
                                 Cancel
                             </Button>
                         )}
                    </div>
                </Card>
            )) : (
                <div className="text-center py-12 text-slate-500 bg-slate-800/30 rounded-2xl border border-slate-700">
                    <Calendar className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p>You have no scheduled appointments.</p>
                </div>
            )}
        </div>
    </div>
  );
}