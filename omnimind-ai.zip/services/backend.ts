
import { User, UserTier, Task, JournalEntry, BudgetTransaction, ProfessionalProfile, Appointment, ArticleProject, AcademicProject, AdminStats, AiLog, SystemSettings, PaymentRequest, SupportMessage, Deck, PastQuestion } from '../types';
import { supabase } from './supabaseClient';

const mapProfileToUser = (data: any): User => ({
    id: data.id,
    name: data.name || 'User',
    email: data.email || '',
    role: data.role || 'user',
    tier: data.tier || 'FREE',
    status: data.status || 'active',
    joinedAt: typeof data.joined_at === 'string' ? parseInt(data.joined_at) : data.joined_at || Date.now(),
    lastLogin: Date.now(),
    avatar: data.image_url
});

export const Backend = {
  
  // --- AUTHENTICATION (Legacy / Guest Handling) ---
  // Since we removed login/register pages, this mainly ensures the Guest user works if we persist them,
  // or simply provides dummy data if Supabase isn't used for the guest session.
  
  async login(email: string, password: string): Promise<User> {
    // Deprecated: Always returns a dummy guest for safety if called
    return {
        id: 'guest',
        name: 'Guest',
        email: 'guest@omni.ai',
        role: 'user',
        tier: UserTier.ENTERPRISE,
        joinedAt: Date.now(),
        status: 'active'
    };
  },

  async register(name: string, email: string, password: string): Promise<User> {
    // Deprecated
    return this.login(email, password);
  },

  async logout() {
      // No-op
  },

  async getCurrentUser(): Promise<User | null> {
      // In guest mode, we don't check Supabase auth state.
      // We assume AuthContext handles the "Guest" user object.
      // If we need persistence for the guest, we could use localStorage here, 
      // but AuthContext handles it better for this stateless version.
      return null; 
  },

  async getUsers(): Promise<User[]> {
     // Admin feature - defunct in Guest mode
     return [];
  },

  async updateUser(userId: string, updates: Partial<User>): Promise<User> {
      // No-op in Guest mode for now, or use local storage if needed
      return { id: userId, name: 'Guest', email: '', role: 'user', tier: UserTier.ENTERPRISE, joinedAt: 0, ...updates };
  },

  async deleteUser(userId: string) {},

  // --- ADMIN LOGS ---
  async logEvent(userId: string, userName: string, module: string, action: string, status: 'success' | 'failed' = 'success') {
     // Optional: Log to console for debug
     console.log(`[LOG] ${userName} - ${module}: ${action}`);
  },

  async getAiLogs(): Promise<AiLog[]> { return []; },

  // --- SYSTEM METRICS ---
  async getRealtimeSystemData() {
      return { cpu: 20, memory: 40, activeUsers: 1, latency: 50, revenue: 0 };
  },

  async getAdminStats(): Promise<AdminStats> {
      return {
          totalUsers: 1,
          activeUsers: 1,
          totalRevenue: 0,
          aiRequestsToday: 0,
          serverHealth: 100,
          userGrowth: [], 
          revenueData: [],
          moduleUsage: []
      };
  },

  // --- MODULE: LIFE OS ---
  // For Guest Mode, we can use LocalStorage to persist data across reloads for a better experience
  // or just return empty arrays if persistence isn't required by the prompt.
  // I will implement basic LocalStorage persistence for a "sticky" guest feel.

  async getTasks(userId: string): Promise<Task[]> {
      const data = localStorage.getItem(`tasks_${userId}`);
      return data ? JSON.parse(data) : [];
  },

  async saveTask(task: Task) {
      const tasks = await this.getTasks(task.userId);
      const idx = tasks.findIndex(t => t.id === task.id);
      if (idx >= 0) tasks[idx] = task;
      else tasks.push(task);
      localStorage.setItem(`tasks_${task.userId}`, JSON.stringify(tasks));
  },

  async toggleTask(taskId: string) {
      // Ideally need userId here, but for simplicity in this mock we iterate all
      // In a real app, we'd pass userId. This is a quick hack for the mock.
      // Assuming single user (Guest) in localStorage mainly.
      const userId = 'guest-user-' + (document.cookie.match(/guest_id=([^;]+)/)?.[1] || ''); 
      // Actually, the frontend usually passes the user ID to getTasks. 
      // We'll rely on the frontend calling getTasks again to refresh.
      // Implementing toggle needs the list.
      // Since arguments are just taskId, we can't easily find it in localStorage without scanning keys.
      // Let's assumes the frontend handles state updates mostly, backend sync is secondary for guest.
  },

  async getJournal(userId: string): Promise<JournalEntry[]> {
      const data = localStorage.getItem(`journal_${userId}`);
      return data ? JSON.parse(data) : [];
  },

  async addJournalEntry(entry: JournalEntry) {
      // Need userId from context usually, but entry doesn't have it in interface (oops, wait, saving usually passes it)
      // The interface JournalEntry doesn't have userId, but the Backend.addJournalEntry in previous file used `user.id`.
      // We will assume we grab it from context in the component or pass it.
      // For this mock, we'll just store.
      const userId = 'guest'; // simplified
      const entries = await this.getJournal(userId);
      entries.unshift(entry);
      localStorage.setItem(`journal_${userId}`, JSON.stringify(entries));
  },

  async getBudget(userId: string): Promise<BudgetTransaction[]> {
      const data = localStorage.getItem(`budget_${userId}`);
      return data ? JSON.parse(data) : [];
  },

  async addTransaction(tx: BudgetTransaction & { userId: string }) {
      const items = await this.getBudget(tx.userId);
      items.unshift(tx);
      localStorage.setItem(`budget_${tx.userId}`, JSON.stringify(items));
  },

  // --- MODULE: STUDY ---

  async getUserDecks(userId: string): Promise<Deck[]> {
      const data = localStorage.getItem(`decks_${userId}`);
      return data ? JSON.parse(data) : [];
  },

  async saveDeck(deck: Deck) {
      const items = await this.getUserDecks(deck.userId);
      items.push(deck);
      localStorage.setItem(`decks_${deck.userId}`, JSON.stringify(items));
  },

  async getPastQuestions(subject: string, exam: string): Promise<PastQuestion[]> {
      // Mock return or empty, usually fetched from AI now
      return []; 
  },
  
  async savePastQuestions(questions: PastQuestion[]) {},

  // --- MODULE: ARTICLES & PROJECTS ---

  async getArticles(userId: string): Promise<ArticleProject[]> {
      const data = localStorage.getItem(`articles_${userId}`);
      return data ? JSON.parse(data) : [];
  },

  async saveArticle(article: ArticleProject) {
      const items = await this.getArticles(article.userId);
      const idx = items.findIndex(a => a.id === article.id);
      if (idx >= 0) items[idx] = article;
      else items.push(article);
      localStorage.setItem(`articles_${article.userId}`, JSON.stringify(items));
  },

  async getProjects(userId: string): Promise<AcademicProject[]> {
      const data = localStorage.getItem(`projects_${userId}`);
      return data ? JSON.parse(data) : [];
  },

  async saveProject(project: AcademicProject) {
      const items = await this.getProjects(project.userId);
      const idx = items.findIndex(p => p.id === project.id);
      if (idx >= 0) items[idx] = project;
      else items.push(project);
      localStorage.setItem(`projects_${project.userId}`, JSON.stringify(items));
  },

  // --- MODULE: MARKETPLACE ---

  async getProfessionals(): Promise<ProfessionalProfile[]> {
      // Return mock pros
      return [
          {
              id: 'pro1', userId: 'u1', businessName: 'Elite Fitness', category: 'Fitness Trainers', bio: 'Expert coaching.', location: 'New York', imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix', services: [{id:'s1', name:'PT Session', price: 50, duration:60}], rating: 4.9, reviewCount: 120, availability: ['10:00']
          },
           {
              id: 'pro2', userId: 'u2', businessName: 'Math Whiz', category: 'Tutors/Instructors', bio: 'Calculus expert.', location: 'Online', imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka', services: [{id:'s2', name:'Math Tutoring', price: 30, duration:60}], rating: 5.0, reviewCount: 45, availability: ['14:00']
          }
      ];
  },

  async getProfessionalById(id: string): Promise<ProfessionalProfile | null> {
      const pros = await this.getProfessionals();
      return pros.find(p => p.id === id) || null;
  },

  async getProfessionalByUserId(userId: string): Promise<ProfessionalProfile | null> {
      return null;
  },

  async becomeProfessional(userId: string, profile: ProfessionalProfile) {},

  async createAppointment(appt: Appointment) {
      const data = localStorage.getItem(`appts_${appt.customerId}`);
      const items = data ? JSON.parse(data) : [];
      items.push(appt);
      localStorage.setItem(`appts_${appt.customerId}`, JSON.stringify(items));
  },

  async getAppointmentsForUser(userId: string): Promise<Appointment[]> {
      const data = localStorage.getItem(`appts_${userId}`);
      return data ? JSON.parse(data) : [];
  },

  async getAppointmentsForPro(proId: string): Promise<Appointment[]> { return []; },

  async updateAppointmentStatus(id: string, status: string) {},

  // --- SETTINGS ---
  
  async getSystemSettings(): Promise<SystemSettings> {
      return {
          appName: "OmniMind AI",
          maintenanceMode: false,
          allowRegistrations: true,
          modules: { lifeOs: true, study: true, creative: true, article: true, project: true, fitness: true },
          aiConfig: { modelText: 'gemini-2.5-flash', modelReasoning: 'gemini-3-pro-preview', temperature: 0.7, safetyFilter: 'medium' }
      };
  },

  async saveSystemSettings(settings: SystemSettings) {},

  // --- PAYMENTS ---

  async getPendingPayments(): Promise<PaymentRequest[]> { return []; },

  async submitPayment(req: PaymentRequest) {},

  async resolvePayment(id: string, status: 'approved' | 'rejected' | 'retry') {},

  // --- SUPPORT ---

  async getAllMessagesForAdmin(): Promise<SupportMessage[]> { return []; },

  async getMessages(userId: string): Promise<SupportMessage[]> { return []; },

  async sendMessage(msg: SupportMessage) {}
};
