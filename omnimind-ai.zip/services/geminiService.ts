
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { Flashcard, Quiz, ScheduleItem, ProfessionalProfile, BudgetTransaction, PastQuestion, Character, WorkoutDay, MacroPlan } from "../types";

const apiKey = process.env.API_KEY;
const ai = new GoogleGenAI({ apiKey: apiKey || 'dummy_key' });

export const models = {
  text: 'gemini-2.5-flash',           // Standard Assistant
  fast: 'gemini-flash-lite-latest',   // High speed tasks
  reasoning: 'gemini-3-pro-preview',  // Advanced Assistant
  vision: 'gemini-2.5-flash', 
  image: 'imagen-4.0-generate-001',
};

// Helper for safe JSON parsing
const cleanAndParseJSON = (text: string | undefined, fallback: any) => {
    if (!text) return fallback;
    try {
        // Remove markdown code fences if present
        let clean = text.replace(/```json\s*/g, "").replace(/```\s*/g, "");
        
        // Locate the first '{' and the last '}' to extract the JSON object or '[' ']' for arrays
        const firstBrace = clean.indexOf('{');
        const firstBracket = clean.indexOf('[');
        
        if (firstBrace !== -1 || firstBracket !== -1) {
            // Simple heuristic to find the JSON start
            const start = (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) ? firstBrace : firstBracket;
            // Find end
            const lastBrace = clean.lastIndexOf('}');
            const lastBracket = clean.lastIndexOf(']');
            const end = Math.max(lastBrace, lastBracket);

            if (end > start) {
                clean = clean.substring(start, end + 1);
            }
        }

        return JSON.parse(clean);
    } catch (e) {
        console.warn("JSON parse failed:", e);
        return fallback;
    }
};

// ==========================================
// UNIVERSAL CREATOR PANEL TOOLS
// ==========================================

export type CreativeToolType = 
    'logo' | 'poster' | 'ebook_cover' | 'thumbnail' | 
    'business_card' | 'social_post' | 'landing_page';

export async function runCreativeTool(tool: CreativeToolType, inputs: any): Promise<any> {
    const inputStr = JSON.stringify(inputs);
    
    try {
        // --- VISUAL TOOLS (Generate Image) ---
        if (['logo', 'poster', 'ebook_cover', 'thumbnail'].includes(tool)) {
            // 1. Enhance the prompt for the image model
            const enhancementPrompt = `
                Act as a master art director. Create a highly detailed, professional image generation prompt for a ${tool}.
                User Inputs: ${inputStr}.
                Output ONLY the prompt string, nothing else.
            `;
            const enhancementRes = await ai.models.generateContent({
                model: models.fast,
                contents: enhancementPrompt
            });
            const imagePrompt = enhancementRes.text || "";

            // 2. Generate Image
            const imageRes = await ai.models.generateImages({
                model: models.image,
                prompt: imagePrompt,
                config: { 
                    numberOfImages: 1, 
                    aspectRatio: tool === 'ebook_cover' ? '3:4' : tool === 'thumbnail' ? '16:9' : tool === 'poster' ? '3:4' : '1:1' 
                }
            });
            
            const base64 = imageRes.generatedImages?.[0]?.image?.imageBytes;
            return {
                type: 'image',
                url: base64 ? `data:image/jpeg;base64,${base64}` : null,
                prompt: imagePrompt
            };
        }

        // --- TEXT & CODE TOOLS ---
        
        if (tool === 'landing_page') {
            const prompt = `
                Act as a Senior Web Developer & UI/UX Designer.
                Create a modern, high-converting landing page for: ${inputStr}.
                Return JSON with structure:
                {
                    "html": "Full HTML5 string with Tailwind CSS classes embedded",
                    "metaDescription": "SEO description",
                    "sections": ["Hero", "Features", "Testimonials", "Contact"]
                }
            `;
            const result = await ai.models.generateContent({
                model: models.reasoning,
                contents: prompt,
                config: { responseMimeType: "application/json" }
            });
            return { type: 'code', ...cleanAndParseJSON(result.text, {}) };
        }

        if (tool === 'social_post') {
            const prompt = `
                Act as a Social Media Manager. Create a post for: ${inputStr}.
                Return JSON:
                {
                    "platform": "${inputs.platform}",
                    "caption": "Engaging caption with emojis",
                    "hashtags": ["#tag1", "#tag2"],
                    "imagePrompt": "Description for an image to go with this post"
                }
            `;
            const result = await ai.models.generateContent({
                model: models.text,
                contents: prompt,
                config: { responseMimeType: "application/json" }
            });
            const data = cleanAndParseJSON(result.text, {});
            
            // Generate image for the post
            let imageUrl = null;
            if (data.imagePrompt) {
                try {
                    const imgRes = await ai.models.generateImages({
                        model: models.image,
                        prompt: data.imagePrompt,
                        config: { numberOfImages: 1, aspectRatio: '1:1' }
                    });
                    const b64 = imgRes.generatedImages?.[0]?.image?.imageBytes;
                    if (b64) imageUrl = `data:image/jpeg;base64,${b64}`;
                } catch (e) { console.error("Social image failed", e); }
            }

            return { type: 'social', ...data, imageUrl };
        }

        if (tool === 'business_card') {
             const prompt = `
                Act as a Brand Designer. Create data for a business card: ${inputStr}.
                Return JSON:
                {
                    "layout": "modern",
                    "front": { "name": "...", "title": "...", "company": "..." },
                    "back": { "slogan": "...", "website": "..." },
                    "colorHex": "#000000",
                    "fontStyle": "Sans-serif"
                }
            `;
             const result = await ai.models.generateContent({
                model: models.text,
                contents: prompt,
                config: { responseMimeType: "application/json" }
            });
            return { type: 'data', ...cleanAndParseJSON(result.text, {}) };
        }

    } catch (e) {
        console.error("Creative Tool Error:", e);
        return { error: "Failed to generate content." };
    }
}

export async function runToolchain(userRequest: string): Promise<any[]> {
    // 1. Break down the request
    const plannerPrompt = `
        The user wants: "${userRequest}".
        Available tools: logo, poster, ebook_cover, thumbnail, business_card, social_post, landing_page.
        Return JSON array of tools to run with their inputs:
        {
            "plan": [
                { "tool": "logo", "inputs": { "name": "..." } },
                { "tool": "landing_page", "inputs": { "businessName": "..." } }
            ]
        }
    `;
    
    try {
        const planRes = await ai.models.generateContent({
            model: models.reasoning,
            contents: plannerPrompt,
            config: { responseMimeType: "application/json" }
        });
        const plan = cleanAndParseJSON(planRes.text, { plan: [] }).plan;

        const results = [];
        for (const step of plan) {
            const res = await runCreativeTool(step.tool, step.inputs);
            results.push({ tool: step.tool, result: res });
        }
        return results;

    } catch (e) {
        return [];
    }
}

// --- EXISTING FUNCTIONS (Kept for other modules) ---

export async function generateRefinedPrompt(
    input: string, 
    targetType: 'image' | 'video' | 'code' | 'text', 
    mode: 'standard' | 'advanced',
    targetModel: string = 'Generic'
): Promise<string> {
    const systemRole = mode === 'advanced' 
        ? `You are a world-class Prompt Engineer specializing in optimizing prompts for the "${targetModel}" model.`
        : `You are a helpful assistant that improves prompts.`;

    const prompt = `Refine this prompt for ${targetModel} (${targetType}): "${input}"`;
    
    try {
        const result = await ai.models.generateContent({
            model: models.text,
            contents: prompt,
            config: { systemInstruction: systemRole }
        });
        return result.text || input;
    } catch (e) { return input; }
}

export async function generateChatResponse(
  history: { role: string; text: string; attachment?: string }[],
  message: string,
  attachment?: string | null,
  systemInstruction?: string,
  modelName?: string
): Promise<string> {
  try {
    const contents = history.map(h => {
        const parts: any[] = [];
        if (h.attachment) {
            const mimeType = h.attachment.startsWith('JVBER') ? 'application/pdf' : 'image/jpeg';
            parts.push({ inlineData: { mimeType, data: h.attachment } });
        }
        parts.push({ text: h.text });
        return { role: h.role, parts };
    });

    const currentParts: any[] = [];
    if (attachment) {
        const mimeType = attachment.startsWith('JVBER') ? 'application/pdf' : 'image/jpeg';
        currentParts.push({ inlineData: { mimeType, data: attachment } });
    }
    currentParts.push({ text: message });
    contents.push({ role: 'user', parts: currentParts });

    const result = await ai.models.generateContent({
      model: modelName || models.text,
      contents: contents,
      config: { systemInstruction }
    });
    
    return result.text || "I couldn't generate a response.";
  } catch (error) {
    console.error("API Error:", error);
    return "I'm having trouble connecting right now. Please try again.";
  }
}

export async function generateBookOutline(title: string, genre: string, tone: string): Promise<any> {
    try {
        const prompt = `Create book outline for "${title}" (${genre}). Tone: ${tone}. JSON: { "synopsis": "...", "chapters": [{"title": "...", "summary": "..."}] }`;
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        return cleanAndParseJSON(result.text, { synopsis: "", chapters: [] });
    } catch (e) { return { synopsis: "", chapters: [] }; }
}

export async function generateBookCharacters(title: string, genre: string): Promise<Character[]> {
    const prompt = `Create 3 characters for "${title}" (${genre}). JSON: { "characters": [{ "name": "...", "role": "...", "description": "..." }] }`;
    try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        const parsed = cleanAndParseJSON(result.text, { characters: [] });
        return parsed.characters || [];
    } catch (e) { return []; }
}

export async function generateChapterContent(bookTitle: string, chapterTitle: string, chapterSummary: string, mode: string, length: string): Promise<string> {
    const prompt = `Write chapter "${chapterTitle}" for "${bookTitle}". Summary: ${chapterSummary}. Mode: ${mode}. Length: ${length}. Use Markdown.`;
    const result = await ai.models.generateContent({ model: models.text, contents: prompt });
    return result.text || "Failed.";
}

export async function generateImage(prompt: string, aspectRatio: string = '1:1', style?: string): Promise<string | null> {
    try {
        let finalPrompt = style ? `${style} style. ${prompt}` : prompt;
        const result = await ai.models.generateImages({
            model: models.image,
            prompt: finalPrompt,
            config: { numberOfImages: 1, aspectRatio, outputMimeType: 'image/jpeg' }
        });
        const base64 = result.generatedImages?.[0]?.image?.imageBytes;
        return base64 ? `data:image/jpeg;base64,${base64}` : null;
    } catch (e) { return null; }
}

export async function enhancePrompt(basePrompt: string): Promise<string> {
    return generateRefinedPrompt(basePrompt, 'image', 'advanced', 'Generic');
}

export async function solveHomework(imageBase64: string | null, textQuestion: string, showSteps: boolean = true): Promise<string> {
    try {
        const parts: any[] = [];
        if (imageBase64) parts.push({ inlineData: { mimeType: 'image/jpeg', data: imageBase64 } });
        parts.push({ text: textQuestion + (showSteps ? " Show steps." : "") });
        const result = await ai.models.generateContent({
            model: imageBase64 ? models.vision : models.reasoning,
            contents: { parts }
        });
        return result.text || "Could not solve.";
    } catch (e) { return "Error."; }
}

export async function generateMealPlan(goal: string): Promise<any> {
     try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: `Meal plan for ${goal}. JSON: { "day": "Mon", "breakfast": "...", "lunch": "...", "dinner": "...", "calories": 2000 }`,
            config: { responseMimeType: "application/json" }
        });
        return cleanAndParseJSON(result.text, {});
    } catch (e) { return null; }
}

export async function generateWorkoutPlan(level: string, goal: string, equipment: string, days: number): Promise<WorkoutDay[]> {
    try {
        const prompt = `Workout plan: ${days} days, ${level}, ${goal}, ${equipment}. JSON: { "schedule": [ { "day": "...", "focus": "...", "exercises": [] } ] }`;
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        const parsed = cleanAndParseJSON(result.text, { schedule: [] });
        return parsed.schedule || [];
    } catch (e) { return []; }
}

export async function calculateMacros(age: number, weight: number, height: number, gender: string, activity: string, goal: string): Promise<MacroPlan | null> {
     try {
        const prompt = `Macros for: ${age}yo, ${weight}kg, ${height}cm, ${gender}, ${activity}, ${goal}. JSON: { "calories": 0, "protein": "0g", "carbs": "0g", "fats": "0g", "advice": "..." }`;
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        return cleanAndParseJSON(result.text, null);
    } catch (e) { return null; }
}

export async function generateFlashcards(content: string, count: number = 5): Promise<Flashcard[]> {
     try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: `Create ${count} flashcards for: "${content}". JSON Schema: { "cards": [ { "front": "Q", "back": "A" } ] }`,
            config: { responseMimeType: "application/json" }
        });
        const parsed = cleanAndParseJSON(result.text, { cards: [] });
        return parsed.cards || [];
    } catch (e) { return []; }
}

export async function generateQuiz(topic: string): Promise<Quiz | null> {
     try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: `5 question quiz on "${topic}". JSON: { "topic": "${topic}", "questions": [ { "question": "...", "options": [], "correctAnswer": 0, "explanation": "..." } ] }`,
            config: { responseMimeType: "application/json" }
        });
        return cleanAndParseJSON(result.text, null);
    } catch (e) { return null; }
}

export async function generateStudyNotes(content: string, type: string, attachment?: string): Promise<string> {
    let prompt = `Create ${type} study notes. Markdown.`;
    const parts: any[] = [{ text: prompt + "\n\n" + content }];
    if (attachment) parts.unshift({ inlineData: { mimeType: 'image/jpeg', data: attachment } });
    try {
        const result = await ai.models.generateContent({
            model: attachment ? models.vision : models.text,
            contents: { parts }
        });
        return result.text || "Failed.";
    } catch (e) { return "Error."; }
}

export async function generatePastQuestions(subject: string, examBody: string, year: string): Promise<PastQuestion[]> {
    try {
        const prompt = `
            Generate 5 past examination questions for:
            Subject: ${subject}
            Exam Body: ${examBody}
            Year context: Around ${year}
            
            Return JSON format:
            {
                "questions": [
                    {
                        "question": "The actual question text",
                        "solution": "The correct answer/option",
                        "explanation": "Brief explanation of why"
                    }
                ]
            }
        `;
        
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        
        const parsed = cleanAndParseJSON(result.text, { questions: [] });
        
        return (parsed.questions || []).map((q: any) => ({
            id: Date.now().toString() + Math.random(),
            subject,
            year: parseInt(year),
            examBody,
            question: q.question,
            solution: q.solution,
            explanation: q.explanation
        }));

    } catch (e) {
        console.error("Failed to generate past questions", e);
        return [];
    }
}

export async function generateDaySchedule(tasks: string[], userContext: string): Promise<ScheduleItem[]> {
     try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: `Schedule tasks: ${tasks.join(', ')}. Context: ${userContext}. JSON: { "schedule": [ { "time": "...", "title": "...", "category": "work" } ] }`,
            config: { responseMimeType: "application/json" }
        });
        const parsed = cleanAndParseJSON(result.text, { schedule: [] });
        return (parsed.schedule || []).map((s: any, i: number) => ({ ...s, id: Date.now() + i, isAiGenerated: true }));
    } catch (e) { return []; }
}

export async function breakDownTask(taskTitle: string): Promise<string[]> {
     try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: `Break down "${taskTitle}" into 3 steps. JSON: { "steps": [] }`,
            config: { responseMimeType: "application/json" }
        });
        return cleanAndParseJSON(result.text, { steps: [] }).steps || [];
    } catch (e) { return []; }
}

export async function generateCreativeWriting(format: string, recipient: string, topic: string, tone: string, length: string): Promise<string> {
    const prompt = `Write ${format} to ${recipient} about ${topic}. Tone: ${tone}. Length: ${length}.`;
    const result = await ai.models.generateContent({ model: models.text, contents: prompt });
    return result.text || "Failed.";
}

export async function analyzeJournalMood(entry: string): Promise<string> {
    const result = await ai.models.generateContent({ model: models.text, contents: `Analyze mood: ${entry}` });
    return result.text || "OK";
}

export async function analyzeFinancials(transactions: BudgetTransaction[]): Promise<any> {
     try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: `Analyze: ${JSON.stringify(transactions.slice(0, 5))}. JSON: { "financialHealthScore": 80, "analysis": "...", "spendingLeaks": [], "tips": [] }`,
            config: { responseMimeType: "application/json" }
        });
        return cleanAndParseJSON(result.text, {});
    } catch (e) { return null; }
}

export async function recommendProfessionals(query: string, profiles: ProfessionalProfile[]): Promise<ProfessionalProfile[]> {
     try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: `Match "${query}" to these pros: ${JSON.stringify(profiles.map(p => ({ id: p.id, bio: p.bio })))}. JSON: { "ids": [] }`,
            config: { responseMimeType: "application/json" }
        });
        const ids = cleanAndParseJSON(result.text, { ids: [] }).ids || [];
        return ids.map((id: string) => profiles.find(p => p.id === id)).filter(Boolean) as ProfessionalProfile[];
    } catch (e) { return profiles; }
}

export async function generateArticleResearch(topic: string): Promise<string> {
    const result = await ai.models.generateContent({ model: models.text, contents: `Research "${topic}". Summary, trends.` });
    return result.text || "Failed.";
}

export async function generateFullArticle(topic: string, tone: string, length: string, type: string, mode: string): Promise<string> {
    const prompt = `Write ${length} ${type} on "${topic}". Tone: ${tone}. Mode: ${mode}. Markdown.`;
    const result = await ai.models.generateContent({ model: models.text, contents: prompt });
    return result.text || "Failed.";
}

export async function generateSEOAnalysis(content: string): Promise<any> {
     try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: `SEO Analyze: ${content.substring(0, 500)}. JSON: { "keywords": [], "metaTitle": "", "metaDescription": "" }`,
            config: { responseMimeType: "application/json" }
        });
        return cleanAndParseJSON(result.text, {});
    } catch (e) { return {}; }
}

export async function generateArticleImage(prompt: string): Promise<string | null> {
    return generateImage(prompt, "16:9");
}

export async function generateProjectTopics(field: string, type: string): Promise<string[]> {
     try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: `5 ${type} project topics for ${field}. JSON: { "topics": [] }`,
            config: { responseMimeType: "application/json" }
        });
        return cleanAndParseJSON(result.text, { topics: [] }).topics || [];
    } catch (e) { return []; }
}

export async function generateProjectChapter(topic: string, chapter: string, context: string, mode: string): Promise<string> {
    const prompt = `Write chapter "${chapter}" for "${topic}". Context: ${context}. Mode: ${mode}.`;
    const result = await ai.models.generateContent({ model: models.text, contents: prompt });
    return result.text || "Failed.";
}

export async function generateProjectStructureFromAttachment(base64: string, promptText: string): Promise<any[]> {
    return [ { title: "Introduction", content: "" }, { title: "Body", content: "" }, { title: "Conclusion", content: "" } ];
}

export async function generatePromptTemplate(
    goal: string,
    mode: 'standard' | 'advanced',
    options?: { category?: string, role?: string, tone?: string, format?: string, constraints?: string }
): Promise<string> {
    let systemInstruction = "";
    let prompt = "";

    if (mode === 'standard') {
        systemInstruction = "You are an expert Prompt Engineer. Output ONLY the refined prompt.";
        prompt = `User Goal: "${goal}". Category: ${options?.category || 'General'}. Create a clear, helpful prompt. Return ONLY the prompt text.`;
    } else {
        systemInstruction = "You are a Master Prompt Engineer. Create a highly sophisticated prompt.";
        prompt = `User Goal: "${goal}". Role: ${options?.role}. Tone: ${options?.tone}. Format: ${options?.format}. Constraints: ${options?.constraints}. Return ONLY the prompt text.`;
    }

    try {
        const result = await ai.models.generateContent({
            model: models.text,
            contents: prompt,
            config: { systemInstruction }
        });
        return result.text || "Could not generate prompt.";
    } catch (e) {
        return "Error generating prompt.";
    }
}

export async function interpretLifeTask(userProblem: string): Promise<{
    plan: string[];
    suggestedPros: string[];
    autoEmail?: string;
}> {
    const prompt = `
    Act as a "Universal Problem Solver" (UPS-AI). 
    The user has a problem: "${userProblem}".
    Return JSON: { "plan": ["step 1", "step 2"], "suggestedPros": ["Pro Type"], "autoEmail": "Draft email..." }
    `;

    try {
        const result = await ai.models.generateContent({
            model: models.fast,
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        return cleanAndParseJSON(result.text, { plan: ["Analyze problem", "Take action"], suggestedPros: [], autoEmail: "" });
    } catch (e) {
        return { plan: ["Analyze problem", "Take action"], suggestedPros: [], autoEmail: "" };
    }
}
