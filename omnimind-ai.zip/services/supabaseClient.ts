
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://qlziecooykdulvcbroxf.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFsemllY29veWtkdWx2Y2Jyb3hmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM3Mjk1NzcsImV4cCI6MjA3OTMwNTU3N30.k1Elp1MQLgNkYmSSuVocDqOI1KsKJcEZRF4I2v1SbtQ';

export const supabase = createClient(supabaseUrl, supabaseKey);
