

export enum UserTier {
  FREE = 'FREE',
  PREMIUM = 'PREMIUM', // This is PRO
  ENTERPRISE = 'ENTERPRISE'
}

export enum AppModule {
  DASHBOARD = 'DASHBOARD',
  ASSISTANT = 'ASSISTANT',
  STUDY = 'STUDY',
  CREATIVE = 'CREATIVE',
  FITNESS = 'FITNESS',
  PROMPT = 'PROMPT'
}

export type UserRole = 'user' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  tier: UserTier;
  avatar?: string;
  joinedAt: number;
  status?: 'active' | 'suspended' | 'banned';
  lastLogin?: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  attachment?: string; // Base64 string for images
  isError?: boolean;
}

// --- PAYMENT & SUPPORT TYPES ---

// Legacy type kept for type safety in old files, but not actively used
export interface PaymentRequest {
    id: string;
    userId: string;
    userName: string;
    amount: string;
    plan: UserTier;
    receiptUrl: string; // Base64 Data URI
    status: 'pending' | 'approved' | 'rejected' | 'retry';
    date: number;
}

export interface SupportMessage {
    id: string;
    senderId: string; // 'admin' or userId
    receiverId: string; // 'admin' or userId
    senderName: string;
    text: string;
    timestamp: number;
    read: boolean;
}

// --- EXISTING TYPES BELOW ---

export interface Character {
  id: string;
  name: string;
  role: string; // Protagonist, Antagonist, etc.
  description: string;
  avatarUrl?: string;
}

export interface BookProject {
  id: string;
  userId: string;
  title: string;
  genre: string;
  tone: string;
  synopsis?: string;
  chapters: BookChapter[];
  characters?: Character[];
  coverPrompt?: string;
  coverImage?: string;
  status: 'draft' | 'completed';
  createdAt: number;
}

export interface BookChapter {
  id: string;
  title: string;
  content: string;
}

// --- LIFE ASSISTANT TYPES ---

export interface Task {
  id: string;
  userId: string;
  title: string;
  completed: boolean;
  category: 'work' | 'personal' | 'study' | 'finance' | 'health';
  priority: 'high' | 'medium' | 'low';
  deadline?: number;
}

export interface ScheduleItem {
  id: string;
  time: string;
  title: string;
  category: 'work' | 'personal' | 'study' | 'fitness';
  isAiGenerated: boolean;
}

export interface JournalEntry {
  id: string;
  date: number; // timestamp
  text: string;
  mood: 'happy' | 'calm' | 'stressed' | 'sad' | 'energetic';
  aiFeedback?: string;
}

export interface BudgetTransaction {
  id: string;
  title: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  date: number;
}

export interface MealPlan {
  day: string;
  breakfast: string;
  lunch: string;
  dinner: string;
  calories: number;
}

export interface WorkoutDay {
    day: string;
    focus: string;
    exercises: { name: string; sets: string; reps: string; notes?: string }[];
}

export interface MacroPlan {
    calories: number;
    protein: string;
    carbs: string;
    fats: string;
    advice: string;
}

// --- MARKETPLACE TYPES ---

export interface ServiceItem {
  id: string;
  name: string;
  description?: string;
  price: number;
  duration: number; // in minutes
}

export interface ProfessionalProfile {
  id: string;
  userId: string;
  businessName: string;
  category: string;
  bio: string;
  location: string;
  imageUrl: string;
  services: ServiceItem[];
  rating: number;
  reviewCount: number;
  availability: string[];
}

export interface Appointment {
  id: string;
  professionalId: string;
  professionalName: string;
  customerId: string;
  customerName: string;
  serviceId: string;
  serviceName: string;
  price: number;
  date: string;
  time: string;
  status: 'pending' | 'confirmed' | 'rejected' | 'completed' | 'cancelled';
  createdAt: number;
}

// --- STUDY MODULE TYPES ---

export interface Flashcard {
  id: string;
  front: string;
  back: string;
}

export interface Deck {
  id: string;
  userId: string;
  title: string;
  cards: Flashcard[];
  createdAt: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number; // index
  explanation: string;
}

export interface Quiz {
  id: string;
  topic: string;
  questions: QuizQuestion[];
  createdAt: number;
}

export interface PastQuestion {
  id: string;
  subject: string;
  year: number;
  examBody: string; // WAEC, JAMB, SAT, etc.
  question: string;
  solution: string;
  explanation?: string;
}

// --- ARTICLE WRITER (MODULE 4) ---
export interface ArticleProject {
  id: string;
  userId: string;
  title: string;
  content: string;
  type: 'article' | 'blog' | 'script' | 'social';
  seo?: {
    keywords: string[];
    metaTitle: string;
    metaDescription: string;
  };
  imageUrl?: string;
  researchNotes?: string;
  createdAt: number;
}

// --- PROJECT WRITER (MODULE 5) ---
export interface AcademicProject {
  id: string;
  userId: string;
  title: string;
  type: 'academic' | 'business' | 'technical';
  field: string;
  chapters: { title: string; content: string }[];
  status: 'draft' | 'completed';
  createdAt: number;
}

// --- PROMPT GENERATOR TYPES ---
export interface PromptProject {
  id: string;
  userId: string;
  goal: string;
  mode: 'standard' | 'advanced';
  category: string;
  generatedPrompt: string;
  createdAt: number;
  settings?: {
      role?: string;
      tone?: string;
      format?: string;
      constraints?: string;
  }
}

// --- ADMIN DASHBOARD TYPES ---

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalRevenue: number;
  aiRequestsToday: number;
  serverHealth: number; // 0-100 (Latency based)
  userGrowth: { date: string; count: number }[];
  revenueData: { month: string; amount: number }[];
  moduleUsage: { name: string; value: number }[];
}

export interface AiLog {
  id: string;
  userId: string;
  userName: string;
  module: string;
  prompt: string; // truncated
  model: string;
  tokens: number;
  timestamp: number;
  status: 'success' | 'failed' | 'flagged';
}

export interface SystemSettings {
  appName: string;
  maintenanceMode: boolean;
  allowRegistrations: boolean;
  modules: {
    lifeOs: boolean;
    study: boolean;
    creative: boolean;
    article: boolean;
    project: boolean;
    fitness: boolean;
  };
  aiConfig: {
    modelText: string;
    modelReasoning: string;
    temperature: number;
    safetyFilter: 'low' | 'medium' | 'high';
  };
}
